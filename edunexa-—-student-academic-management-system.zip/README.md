# EduNexa — Intelligent Student Academic Management System

EduNexa is a full-stack, enterprise-grade Student Academic Management System designed for college and university environments. Built with **React 19, TypeScript, Tailwind CSS, Express, and a persistent SQLite relational database**, it centralizes student academic records, faculty course management, attendance tracking, continuous evaluations, marks computation, assignment submission lifecycles, and academic alerts.

---

## 1. Quick Demonstration Credentials

EduNexa comes automatically initialized with a persistent database seeded with **3 fictional faculty teachers, 25 fictional student accounts, 5 academic subjects, 30+ days of attendance logs, assessments, grades, and 10 coursework assignments**.

For demonstration and testing purposes, use the **1-Click "Demo Accounts" Switcher** in the top navigation bar, or enter the credentials below on the login screen:

### Faculty / Teacher Accounts
| Name | Username | Password | Assigned Subjects | Department |
| :--- | :--- | :--- | :--- | :--- |
| **Prof. Alan Turing** | `prof.turing` | `Teacher@123` | CS101, MATH201 | Computer Science & Mathematics |
| **Dr. Rosalind Franklin** | `dr.franklin` | `Teacher@123` | CHEM105, BIO110 | Life Sciences & Chemistry |
| **Prof. Richard Feynman** | `prof.feynman` | `Teacher@123` | PHYS102 | Applied Physics |

### Featured Student Accounts (Sample of 25)
| Name | Username | Password | Student ID | Class | Key Demonstration Note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Liam Davis** | `liam.davis` | `Student@123` | `STU-2026-001` | Year 1 - Class A | High attendance (~92%), active assignments |
| **Sophia Chen** | `sophia.chen` | `Student@123` | `STU-2026-002` | Year 1 - Class A | Top honors student (GPA 3.9), graded submissions |
| **Jackson Martinez** | `jackson.martinez` | `Student@123` | `STU-2026-005` | Year 1 - Class A | **Attendance Warning Demo (<75% alert banner active)** |
| **Harper Garcia** | `harper.garcia` | `Student@123` | `STU-2026-014` | Year 1 - Class B | Enrolled in Chemistry & Cellular Biology track |
| **Aiden Rodriguez** | `aiden.rodriguez` | `Student@123` | `STU-2026-017` | Year 1 - Class B | **Academic Intervention Demo (Low attendance & marks)** |

*(All 25 students from `STU-2026-001` through `STU-2026-025` share the default password `Student@123`).*

---

## 2. Relational Database Schema & Entities

The system uses a persistent SQLite database (`data/edunexa.sqlite`) with relational integrity, foreign key constraints, and performance indexes:

1. **`users`**: Authentication table (`user_id`, `username`, `password_hash`, `role`, `account_status`, `created_at`).
2. **`teachers`**: Faculty profiles (`teacher_id`, `user_id`, `name`, `email`, `department`, `designation`, `qualification`, `bio`).
3. **`students`**: Student records (`student_id`, `user_id`, `name`, `email`, `class`, `enrollment_date`, `phone`, `address`, `guardian_name`, `guardian_phone`, `bio`, `account_status`).
4. **`subjects`**: Academic courses (`subject_id`, `subject_name`, `subject_code`, `maximum_marks`, `teacher_id`, `class`).
5. **`enrolments`**: Course enrollment links (`student_id`, `subject_id`, `class`, `academic_session`, `status`).
6. **`attendance`**: Daily lecture logs (`student_id`, `subject_id`, `class`, `date`, `session_name`, `status`, `recorded_by_teacher_id`, `remarks`).
7. **`assessments`**: Exams and quizzes (`assessment_id`, `assessment_name`, `subject_id`, `date`, `maximum_marks`, `weightage`, `term`).
8. **`grades`**: Student marks (`student_id`, `assessment_id`, `obtained_marks`, `calculated_percentage`, `grade`, `teacher_remarks`, `updated_at`).
9. **`assignments`**: Coursework tasks (`assignment_id`, `title`, `description`, `subject_id`, `teacher_id`, `creation_date`, `due_date`, `total_marks`, `publication_status`).
10. **`submissions`**: Student submissions (`submission_id`, `assignment_id`, `student_id`, `submission_date`, `answer_text`, `file_name`, `file_url`, `status`, `marks`, `feedback`, `graded_at`, `graded_by`).
11. **`notifications`**: Targeted alerts (`recipient_user_id`, `title`, `message`, `type`, `creation_date`, `is_read`).
12. **`activity_logs`**: System audit trail (`action`, `actor_name`, `actor_role`, `timestamp`, `details`, `record_ref`).

---

## 3. Academic Calculation Rules & Formulas

All metrics, summaries, and warning indicators are calculated dynamically from verified database records:

### Attendance Percentage Formula
$$\text{Attendance Rate} = \left(\frac{\text{Present Sessions} + (0.5 \times \text{Late Sessions})}{\text{Total Sessions} - \text{Excused Sessions}}\right) \times 100$$
- **Excused Leaves**: Medical/approved absence slips are excluded from the denominator.
- **Attendance Warning**: Any student with attendance below **75%** triggers an automatic system warning flag on both faculty and student dashboards.

### Assessment Percentage Formula
$$\text{Assessment \%} = \left(\frac{\text{Marks Obtained}}{\text{Maximum Marks}}\right) \times 100$$

### Configurable Grade Scale Thresholds
- **A+**: $\ge 90\%$ (GPA 4.0)
- **A**: $\ge 80\%$ (GPA 3.8)
- **B**: $\ge 70\%$ (GPA 3.0)
- **C**: $\ge 60\%$ (GPA 2.0)
- **D**: $\ge 50\%$ (GPA 1.0)
- **F**: $< 50\%$ (GPA 0.0)

### Overall Academic Percentage & Cumulative GPA
- Overall Academic % is the sum of total obtained marks divided by total maximum marks across all evaluated assessments, multiplied by 100.
- Cumulative GPA is the weighted average on a standard 4.0 scale.

---

## 4. Key Functional Features

### Teacher Portal
- **Dashboard Analytics**: Real-time KPI tiles, 30-day attendance trend chart, course grade distribution bars, and attention alert lists.
- **Student Directory**: Multi-criteria search, class/subject filters, enrollment modal, permitted editing, account deactivation with preserved records, and complete student dossier viewer.
- **Attendance Manager**: Select subject & date, bulk "Mark All Present/Absent", Present/Late/Absent/Excused status toggles, teacher notes, and instant upsert database saving.
- **Marks & Gradebook**: Examination matrix with real-time numeric bounds validation ($0 \le \text{Marks} \le \text{Max}$), automated percentage and letter grade calculation, teacher remarks, and class averages.
- **Assignment Lifecycle**: Create assignments (published or draft), view student turn-ins, evaluate written answers and attachments, assign scores, return written feedback.
- **Reports & Data Export**: Download live CSV spreadsheets directly from database records (Student Directory CSV, Gradebook CSV, Attendance History CSV).

### Student Portal
- **Personalized Overview**: Term summary, cumulative GPA, standing grade, subject cards, and active warning alerts.
- **Attendance Tracker**: Overall rate, Present/Late/Absent/Excused breakdown counters, subject-wise breakdown, formula transparency banner, and date-filtered chronological logs.
- **Official Transcript**: Subject-wise examination marks, percentages, letter grades, faculty feedback, and printable transcript view.
- **Assignment Submissions**: Status tabs (Pending, Submitted, Graded, Overdue), submission drawer with text answer and attachment simulation, late submission detection, and evaluated feedback review.
- **Profile Management**: Immutable academic attributes (ID, Class, Registrar status) and editable personal contacts (phone, address, emergency contact, bio).

---

## 5. Component Integrations

### A. Voice-Powered Orb (`/components/ui/voice-powered-orb.tsx`)
The `VoicePoweredOrb` WebGL shader component and button primitives are integrated in:
- `/components/ui/voice-powered-orb.tsx` (and mirrored in `/src/components/ui/voice-powered-orb.tsx`)
- `/components/ui/button.tsx` (shadcn button primitive)
- `/components/ui/voice-orb-demo.tsx` (interactive showcase demo)
- `/lib/utils.ts` (`cn` helper using `clsx` and `tailwind-merge`)
- Dependencies installed: `ogl`, `@radix-ui/react-slot`, `class-variance-authority`, `clsx`, `tailwind-merge`.
- To interact with the live Voice-Powered Orb, click **"Voice Orb"** in the navigation bar or footer.

### B. Finance Bento (`/components/ui/finance-bento.tsx`)
- `/components/ui/finance-bento.tsx` & `/components/ui/demo.tsx`
- Click **"Bento Analytics"** in the navigation bar or footer to view this component.

### Why the `/components/ui` Directory is Essential
In shadcn/ui and modern React project architectures, `/components/ui` serves as the standard directory for atomic, reusable primitives (buttons, inputs, dialogs, charts, bentos, webgl canvases). Placing reusable visual components here ensures:
1. **Separation of Concerns**: Generic presentational primitives stay isolated from application-specific business logic.
2. **Path Alias Consistency**: `@/components/ui/*` imports resolve seamlessly across Vite, Next.js, and TypeScript without brittle relative paths (`../../..`).
3. **shadcn CLI Compatibility**: Adding or updating shadcn components automatically routes new primitives into this folder.

---

## 6. Automated Verification Test Results

All 14 required verification tests were executed against the live application:

| # | Test Scenario | Result | Details |
| :--- | :--- | :--- | :--- |
| 1 | Teacher login with demo credentials | **PASSED** | `prof.turing` authenticated, returned JWT & Teacher role |
| 2 | Student login with demo credentials | **PASSED** | `liam.davis` authenticated, returned JWT & Student role |
| 3 | Invalid password rejection | **PASSED** | Rejected with HTTP 401: "Invalid username or password" |
| 4 | Student blocked from teacher routes | **PASSED** | HTTP 403: "Access denied. Requires teacher permission" |
| 5 | Students isolated from other students | **PASSED** | Backend enforces `req.user.profileId` scoping on all queries |
| 6 | Teacher attendance marking | **PASSED** | Saved and verified in database table `attendance` |
| 7 | Marks & grade validation | **PASSED** | Enforces $0 \le \text{Marks} \le \text{Max}$, computes grade linear scale |
| 8 | Student assignment submission | **PASSED** | Submitted solution stored with timestamp and status |
| 9 | Teacher evaluation & feedback | **PASSED** | Teacher graded submission, updated status, notified student |
| 10 | Data persistence across restart | **PASSED** | `data/edunexa.sqlite` holds 430 KB of persistent SQLite data |
| 11 | 25 Student accounts preloaded | **PASSED** | Exactly 25 students, 3 teachers, 5 subjects seeded idempotently |
| 12 | CSV Reports export | **PASSED** | Streaming CSV endpoints generate live database tables |
| 13 | Search, filters, and pagination | **PASSED** | Instant multi-parameter filtering across all tables |
| 14 | Error handling & validation | **PASSED** | Clear user-facing error banners and input validation |
