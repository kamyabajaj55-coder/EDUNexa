import bcrypt from 'bcryptjs';
import { Database } from 'sql.js';
import { execute, queryOne, saveDb } from './db.js';

export async function seedDatabase(db: Database): Promise<void> {
  const existingUsers = queryOne<{ count: number }>(db, 'SELECT count(*) as count FROM users');
  if (existingUsers && existingUsers.count > 0) {
    console.log(`[EduNexa Seeder] Database already populated with ${existingUsers.count} users. Skipping seeding.`);
    return;
  }

  console.log('[EduNexa Seeder] Seeding initial database with 25 students, 3 teachers, 5 subjects, attendance, grades, and assignments...');

  const teacherPasswordHash = bcrypt.hashSync('Teacher@123', 10);
  const studentPasswordHash = bcrypt.hashSync('Student@123', 10);

  // 1. Teachers
  const teachers = [
    {
      userId: 'usr-t1',
      username: 'prof.turing',
      name: 'Prof. Alan Turing',
      email: 'alan.turing@edunexa.edu',
      department: 'Computer Science & Mathematics',
      designation: 'Senior Faculty & Dept Head',
      qualification: 'Ph.D. in Computer Science & Applied Mathematics, Cambridge',
      bio: 'Pioneering researcher in theoretical computer science, cryptography, and discrete mathematics algorithms.'
    },
    {
      userId: 'usr-t2',
      username: 'dr.franklin',
      name: 'Dr. Rosalind Franklin',
      email: 'rosalind.franklin@edunexa.edu',
      department: 'Life Sciences & Chemistry',
      designation: 'Associate Professor',
      qualification: 'Ph.D. in Physical Chemistry, Cambridge',
      bio: 'Expert crystallographer and molecular biologist dedicated to cellular research and organic analytical chemistry.'
    },
    {
      userId: 'usr-t3',
      username: 'prof.feynman',
      name: 'Prof. Richard Feynman',
      email: 'richard.feynman@edunexa.edu',
      department: 'Applied Physics',
      designation: 'Professor of Physics',
      qualification: 'Ph.D. in Theoretical Physics, Princeton',
      bio: 'Enthusiastic educator focused on mechanics, quantum electrodynamics, and hands-on laboratory experimentation.'
    }
  ];

  for (let i = 0; i < teachers.length; i++) {
    const t = teachers[i];
    const teacherId = `TCH-00${i + 1}`;
    execute(db, `
      INSERT INTO users (user_id, username, password_hash, role, account_status, created_at)
      VALUES (?, ?, ?, 'teacher', 'active', '2026-08-15 09:00:00')
    `, [t.userId, t.username, teacherPasswordHash]);

    execute(db, `
      INSERT INTO teachers (teacher_id, user_id, name, email, department, designation, qualification, bio)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [teacherId, t.userId, t.name, t.email, t.department, t.designation, t.qualification, t.bio]);
  }

  // 2. Subjects
  const subjects = [
    { id: 'SUB-CS101', name: 'Introduction to Computer Science', code: 'CS101', maxMarks: 100, teacherId: 'TCH-001', class: 'Year 1 - Class A' },
    { id: 'SUB-MATH201', name: 'Discrete Mathematics & Calculus', code: 'MATH201', maxMarks: 100, teacherId: 'TCH-001', class: 'Year 1 - Class A' },
    { id: 'SUB-PHYS102', name: 'General Physics & Mechanics', code: 'PHYS102', maxMarks: 100, teacherId: 'TCH-003', class: 'Year 1 - Class A' },
    { id: 'SUB-CHEM105', name: 'Organic & Analytical Chemistry', code: 'CHEM105', maxMarks: 100, teacherId: 'TCH-002', class: 'Year 1 - Class B' },
    { id: 'SUB-BIO110', name: 'Cellular Biology & Genetics', code: 'BIO110', maxMarks: 100, teacherId: 'TCH-002', class: 'Year 1 - Class B' }
  ];

  for (const s of subjects) {
    execute(db, `
      INSERT INTO subjects (subject_id, subject_name, subject_code, maximum_marks, teacher_id, class)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [s.id, s.name, s.code, s.maxMarks, s.teacherId, s.class]);
  }

  // 3. 25 Fictional Students
  const rawStudents = [
    { name: 'Liam Davis', class: 'Year 1 - Class A', email: 'liam.davis@student.edunexa.edu', phone: '+1 (555) 234-1101', guardian: 'Robert Davis' },
    { name: 'Sophia Chen', class: 'Year 1 - Class A', email: 'sophia.chen@student.edunexa.edu', phone: '+1 (555) 234-1102', guardian: 'Mei Chen' },
    { name: 'Noah Patel', class: 'Year 1 - Class A', email: 'noah.patel@student.edunexa.edu', phone: '+1 (555) 234-1103', guardian: 'Rajesh Patel' },
    { name: 'Emma Wilson', class: 'Year 1 - Class A', email: 'emma.wilson@student.edunexa.edu', phone: '+1 (555) 234-1104', guardian: 'Sarah Wilson' },
    { name: 'Jackson Martinez', class: 'Year 1 - Class A', email: 'jackson.martinez@student.edunexa.edu', phone: '+1 (555) 234-1105', guardian: 'Elena Martinez' },
    { name: 'Olivia Taylor', class: 'Year 1 - Class A', email: 'olivia.taylor@student.edunexa.edu', phone: '+1 (555) 234-1106', guardian: 'James Taylor' },
    { name: 'Lucas Anderson', class: 'Year 1 - Class A', email: 'lucas.anderson@student.edunexa.edu', phone: '+1 (555) 234-1107', guardian: 'Laura Anderson' },
    { name: 'Mia Thomas', class: 'Year 1 - Class A', email: 'mia.thomas@student.edunexa.edu', phone: '+1 (555) 234-1108', guardian: 'David Thomas' },
    { name: 'Ethan Jackson', class: 'Year 1 - Class A', email: 'ethan.jackson@student.edunexa.edu', phone: '+1 (555) 234-1109', guardian: 'Amanda Jackson' },
    { name: 'Ava White', class: 'Year 1 - Class A', email: 'ava.white@student.edunexa.edu', phone: '+1 (555) 234-1110', guardian: 'Kevin White' },
    { name: 'Oliver Harris', class: 'Year 1 - Class A', email: 'oliver.harris@student.edunexa.edu', phone: '+1 (555) 234-1111', guardian: 'Patricia Harris' },
    { name: 'Isabella Martin', class: 'Year 1 - Class A', email: 'isabella.martin@student.edunexa.edu', phone: '+1 (555) 234-1112', guardian: 'Carlos Martin' },
    { name: 'Mason Thompson', class: 'Year 1 - Class A', email: 'mason.thompson@student.edunexa.edu', phone: '+1 (555) 234-1113', guardian: 'Nancy Thompson' },
    { name: 'Harper Garcia', class: 'Year 1 - Class B', email: 'harper.garcia@student.edunexa.edu', phone: '+1 (555) 234-1114', guardian: 'Luis Garcia' },
    { name: 'Elijah Robinson', class: 'Year 1 - Class B', email: 'elijah.robinson@student.edunexa.edu', phone: '+1 (555) 234-1115', guardian: 'Jessica Robinson' },
    { name: 'Evelyn Clark', class: 'Year 1 - Class B', email: 'evelyn.clark@student.edunexa.edu', phone: '+1 (555) 234-1116', guardian: 'Brian Clark' },
    { name: 'Aiden Rodriguez', class: 'Year 1 - Class B', email: 'aiden.rodriguez@student.edunexa.edu', phone: '+1 (555) 234-1117', guardian: 'Maria Rodriguez' },
    { name: 'Abigail Lewis', class: 'Year 1 - Class B', email: 'abigail.lewis@student.edunexa.edu', phone: '+1 (555) 234-1118', guardian: 'Gary Lewis' },
    { name: 'Logan Lee', class: 'Year 1 - Class B', email: 'logan.lee@student.edunexa.edu', phone: '+1 (555) 234-1119', guardian: 'Min-Jun Lee' },
    { name: 'Emily Walker', class: 'Year 1 - Class B', email: 'emily.walker@student.edunexa.edu', phone: '+1 (555) 234-1120', guardian: 'Donna Walker' },
    { name: 'Lucas Hall', class: 'Year 1 - Class B', email: 'lucas.hall@student.edunexa.edu', phone: '+1 (555) 234-1121', guardian: 'Paul Hall' },
    { name: 'Charlotte Allen', class: 'Year 1 - Class B', email: 'charlotte.allen@student.edunexa.edu', phone: '+1 (555) 234-1122', guardian: 'Debra Allen' },
    { name: 'Henry Young', class: 'Year 1 - Class B', email: 'henry.young@student.edunexa.edu', phone: '+1 (555) 234-1123', guardian: 'George Young' },
    { name: 'Amelia King', class: 'Year 1 - Class B', email: 'amelia.king@student.edunexa.edu', phone: '+1 (555) 234-1124', guardian: 'Rebecca King' },
    { name: 'Alexander Wright', class: 'Year 1 - Class B', email: 'alexander.wright@student.edunexa.edu', phone: '+1 (555) 234-1125', guardian: 'Edward Wright' }
  ];

  const studentIds: string[] = [];

  for (let i = 0; i < rawStudents.length; i++) {
    const s = rawStudents[i];
    const num = String(i + 1).padStart(3, '0');
    const studentId = `STU-2026-${num}`;
    studentIds.push(studentId);
    const userId = `usr-s${i + 1}`;
    const username = s.name.toLowerCase().replace(/\s+/g, '.');

    execute(db, `
      INSERT INTO users (user_id, username, password_hash, role, account_status, created_at)
      VALUES (?, ?, ?, 'student', 'active', '2026-08-20 10:00:00')
    `, [userId, username, studentPasswordHash]);

    execute(db, `
      INSERT INTO students (student_id, user_id, name, email, class, enrollment_date, phone, address, guardian_name, guardian_phone, bio, account_status)
      VALUES (?, ?, ?, ?, ?, '2026-08-25', ?, ?, ?, ?, ?, 'active')
    `, [
      studentId,
      userId,
      s.name,
      s.email,
      s.class,
      s.phone,
      `${100 + i * 4} University Heights Blvd, Apt ${i + 10}`,
      s.guardian,
      `+1 (555) 888-${String(2000 + i)}`,
      `Undergraduate student majoring in Computer Science & Natural Sciences with deep interest in software engineering and research.`
    ]);

    // Enrolments: Enroll Class A in CS101, MATH201, PHYS102; Class B in CHEM105, BIO110, MATH201
    const enrolledSubjects = s.class.includes('Class A')
      ? ['SUB-CS101', 'SUB-MATH201', 'SUB-PHYS102']
      : ['SUB-CHEM105', 'SUB-BIO110', 'SUB-MATH201'];

    for (const subId of enrolledSubjects) {
      execute(db, `
        INSERT INTO enrolments (student_id, subject_id, class, academic_session, status)
        VALUES (?, ?, ?, '2026-2027', 'enrolled')
      `, [studentId, subId, s.class]);
    }
  }

  // 4. Attendance history for at least 30 distinct calendar dates across September & October 2026
  console.log('[EduNexa Seeder] Generating 30+ days of attendance logs...');
  const attendanceDates: string[] = [];
  const baseDate = new Date(2026, 8, 1); // Sept 1, 2026
  for (let dayOffset = 0; dayOffset < 48; dayOffset++) {
    const cur = new Date(baseDate.getTime() + dayOffset * 24 * 60 * 60 * 1000);
    const dayOfWeek = cur.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Skip weekends
      const yyyy = cur.getFullYear();
      const mm = String(cur.getMonth() + 1).padStart(2, '0');
      const dd = String(cur.getDate()).padStart(2, '0');
      attendanceDates.push(`${yyyy}-${mm}-${dd}`);
      if (attendanceDates.length >= 32) break;
    }
  }

  // Seed attendance records for CS101 (Prof Turing), CHEM105 (Dr Franklin), and PHYS102 (Prof Feynman)
  for (let sIdx = 0; sIdx < studentIds.length; sIdx++) {
    const sId = studentIds[sIdx];
    const isClassA = sIdx < 13;
    const primarySubject = isClassA ? 'SUB-CS101' : 'SUB-CHEM105';
    const teacherId = isClassA ? 'TCH-001' : 'TCH-002';

    attendanceDates.forEach((dateStr, dIdx) => {
      // Create realistic attendance profile:
      // Most students have 85-95% attendance; a few (e.g. index 4, 17) have lower attendance to trigger warning flags (<75%)
      let status: 'Present' | 'Absent' | 'Late' | 'Excused' = 'Present';
      const pseudoRand = (sIdx * 37 + dIdx * 19) % 100;

      if (sIdx === 4 || sIdx === 17) {
        // Warning flag students
        if (pseudoRand < 35) status = 'Absent';
        else if (pseudoRand < 48) status = 'Late';
        else if (pseudoRand < 55) status = 'Excused';
        else status = 'Present';
      } else {
        if (pseudoRand < 4) status = 'Absent';
        else if (pseudoRand < 9) status = 'Late';
        else if (pseudoRand < 12) status = 'Excused';
        else status = 'Present';
      }

      execute(db, `
        INSERT OR IGNORE INTO attendance (student_id, subject_id, class, date, session_name, status, recorded_by_teacher_id, remarks)
        VALUES (?, ?, ?, ?, 'Morning Session', ?, ?, ?)
      `, [
        sId,
        primarySubject,
        isClassA ? 'Year 1 - Class A' : 'Year 1 - Class B',
        dateStr,
        status,
        teacherId,
        status === 'Late' ? 'Arrived 15 min late due to transit' : status === 'Excused' ? 'Medical leave slip provided' : null
      ]);
    });
  }

  // 5. Assessments
  console.log('[EduNexa Seeder] Creating assessments and student grades...');
  const assessments = [
    { id: 'ASM-CS101-MID', name: 'CS101 Midterm Examination', subjectId: 'SUB-CS101', date: '2026-09-28', maxMarks: 100, weightage: 30, term: 'Fall 2026' },
    { id: 'ASM-CS101-QZ1', name: 'CS101 Algorithms & Syntax Quiz', subjectId: 'SUB-CS101', date: '2026-09-12', maxMarks: 25, weightage: 15, term: 'Fall 2026' },
    { id: 'ASM-CS101-PRC', name: 'CS101 Terminal Project Evaluation', subjectId: 'SUB-CS101', date: '2026-10-18', maxMarks: 50, weightage: 25, term: 'Fall 2026' },

    { id: 'ASM-MTH-MID', name: 'MATH201 Calculus & Logic Midterm', subjectId: 'SUB-MATH201', date: '2026-09-30', maxMarks: 100, weightage: 35, term: 'Fall 2026' },
    { id: 'ASM-MTH-QZ1', name: 'MATH201 Matrices & Vectors Quiz', subjectId: 'SUB-MATH201', date: '2026-09-15', maxMarks: 50, weightage: 15, term: 'Fall 2026' },

    { id: 'ASM-PHY-MID', name: 'PHYS102 Classical Mechanics Exam', subjectId: 'SUB-PHYS102', date: '2026-10-02', maxMarks: 100, weightage: 35, term: 'Fall 2026' },
    { id: 'ASM-PHY-LAB', name: 'PHYS102 Kinematics Lab Practical', subjectId: 'SUB-PHYS102', date: '2026-09-20', maxMarks: 50, weightage: 20, term: 'Fall 2026' },

    { id: 'ASM-CHM-MID', name: 'CHEM105 Organic Mechanisms Midterm', subjectId: 'SUB-CHEM105', date: '2026-09-29', maxMarks: 100, weightage: 35, term: 'Fall 2026' },
    { id: 'ASM-CHM-LAB', name: 'CHEM105 Qualitative Analysis Lab', subjectId: 'SUB-CHEM105', date: '2026-09-22', maxMarks: 50, weightage: 20, term: 'Fall 2026' },

    { id: 'ASM-BIO-MID', name: 'BIO110 Genetics & DNA Midterm', subjectId: 'SUB-BIO110', date: '2026-10-01', maxMarks: 100, weightage: 35, term: 'Fall 2026' }
  ];

  for (const a of assessments) {
    execute(db, `
      INSERT INTO assessments (assessment_id, assessment_name, subject_id, date, maximum_marks, weightage, term)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [a.id, a.name, a.subjectId, a.date, a.maxMarks, a.weightage, a.term]);
  }

  // Helper grading formula
  function calculateGrade(percentage: number): string {
    if (percentage >= 90) return 'A+';
    if (percentage >= 80) return 'A';
    if (percentage >= 70) return 'B';
    if (percentage >= 60) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
  }

  // Insert grades for enrolled students
  for (let sIdx = 0; sIdx < studentIds.length; sIdx++) {
    const sId = studentIds[sIdx];
    const isClassA = sIdx < 13;
    const applicableAssessments = isClassA
      ? assessments.filter(a => ['SUB-CS101', 'SUB-MATH201', 'SUB-PHYS102'].includes(a.subjectId))
      : assessments.filter(a => ['SUB-CHEM105', 'SUB-BIO110', 'SUB-MATH201'].includes(a.subjectId));

    for (const asm of applicableAssessments) {
      // Deterministic realistic scores
      const seedVal = (sIdx * 17 + asm.name.length * 23) % 45;
      const basePercentage = Math.min(98, Math.max(48, 62 + seedVal));
      const obtained = Math.round((basePercentage / 100) * asm.maxMarks * 10) / 10;
      const percentage = Math.round((obtained / asm.maxMarks) * 1000) / 10;
      const grade = calculateGrade(percentage);

      let remark = 'Solid grasp of foundational principles.';
      if (percentage >= 90) remark = 'Exemplary problem analysis and meticulous execution.';
      else if (percentage >= 80) remark = 'Consistently strong performance with thorough explanations.';
      else if (percentage >= 70) remark = 'Good effort; focus on proof derivations and edge cases.';
      else if (percentage < 60) remark = 'Academic support recommended. Review review lecture modules.';

      execute(db, `
        INSERT OR IGNORE INTO grades (student_id, assessment_id, obtained_marks, calculated_percentage, grade, teacher_remarks, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, '2026-10-20 14:30:00')
      `, [sId, asm.id, obtained, percentage, grade, remark]);
    }
  }

  // 6. At least 10 Assignments with varied deadlines and statuses
  console.log('[EduNexa Seeder] Creating 10 assignments...');
  const assignments = [
    {
      id: 'ASN-CS101-01',
      title: 'Assignment 1: Sorting Algorithm Complexity & Benchmarking',
      description: 'Implement QuickSort and MergeSort in Python or TypeScript. Benchmark their runtime across arrays of 100, 10,000, and 1,000,000 elements. Plot time curves and provide a 2-page analytical report.',
      subjectId: 'SUB-CS101',
      teacherId: 'TCH-001',
      created: '2026-09-05',
      due: '2026-09-20 23:59:00',
      totalMarks: 50,
      status: 'published'
    },
    {
      id: 'ASN-CS101-02',
      title: 'Assignment 2: Binary Search Trees & Balanced AVL Rotations',
      description: 'Build a self-balancing binary search tree. Demonstrate insertion, deletion, and rotation triggers with unit tests covering left-left, right-right, and double rotation scenarios.',
      subjectId: 'SUB-CS101',
      teacherId: 'TCH-001',
      created: '2026-09-22',
      due: '2026-10-10 23:59:00',
      totalMarks: 50,
      status: 'published'
    },
    {
      id: 'ASN-CS101-03',
      title: 'Assignment 3: Graph Traversal, Dijkstra & Minimum Spanning Trees',
      description: 'Model a city transit network using adjacency lists. Implement Dijkstra’s shortest path algorithm and Prim’s or Kruskal’s MST algorithm. Submit annotated source and test suite.',
      subjectId: 'SUB-CS101',
      teacherId: 'TCH-001',
      created: '2026-10-15',
      due: '2026-11-05 23:59:00',
      totalMarks: 60,
      status: 'published'
    },
    {
      id: 'ASN-MTH201-01',
      title: 'Problem Set 1: Propositional Logic & Mathematical Induction',
      description: 'Solve the 8 problem proofs in Chapter 2, including weak and strong induction on Fibonacci sequences and graph coloring planar inequalities.',
      subjectId: 'SUB-MATH201',
      teacherId: 'TCH-001',
      created: '2026-09-08',
      due: '2026-09-24 23:59:00',
      totalMarks: 40,
      status: 'published'
    },
    {
      id: 'ASN-MTH201-02',
      title: 'Problem Set 2: Eigenvalues, Vector Spaces & Matrix Decompositions',
      description: 'Determine characteristic polynomials, calculate eigenvalues/eigenvectors, and diagonalize 3x3 symmetric matrices with geometric interpretations.',
      subjectId: 'SUB-MATH201',
      teacherId: 'TCH-001',
      created: '2026-10-05',
      due: '2026-10-25 23:59:00',
      totalMarks: 50,
      status: 'published'
    },
    {
      id: 'ASN-PHYS102-01',
      title: 'Physics Lab 1: Projectile Motion & Aerodynamic Drag Simulation',
      description: 'Record launch velocity angles using laser photogates. Calculate predicted range and verify experimental impact variances with projectile kinematics formulas.',
      subjectId: 'SUB-PHYS102',
      teacherId: 'TCH-003',
      created: '2026-09-10',
      due: '2026-09-25 23:59:00',
      totalMarks: 40,
      status: 'published'
    },
    {
      id: 'ASN-PHYS102-02',
      title: 'Physics Lab 2: Rotational Inertia & Conservation of Angular Momentum',
      description: 'Calculate moments of inertia for solid cylinders, spheres, and hollow discs rolling down an inclined plane. Compare energy dissipation metrics.',
      subjectId: 'SUB-PHYS102',
      teacherId: 'TCH-003',
      created: '2026-10-08',
      due: '2026-10-30 23:59:00',
      totalMarks: 50,
      status: 'published'
    },
    {
      id: 'ASN-CHM105-01',
      title: 'Chemistry Report 1: Esterification Reaction & Infrared Spectroscopy',
      description: 'Analyze synthesized isoamyl acetate using FTIR spectroscopy. Identify key carbonyl stretch peaks (~1740 cm⁻¹) and calculate theoretical percentage yield.',
      subjectId: 'SUB-CHEM105',
      teacherId: 'TCH-002',
      created: '2026-09-12',
      due: '2026-09-27 23:59:00',
      totalMarks: 45,
      status: 'published'
    },
    {
      id: 'ASN-CHM105-02',
      title: 'Chemistry Report 2: Acid-Base Titration Curves & Buffer Capacities',
      description: 'Plot pH versus titrant volume for weak acid/strong base pairs. Determine the pKa value and identify optimal buffering zones.',
      subjectId: 'SUB-CHEM105',
      teacherId: 'TCH-002',
      created: '2026-10-04',
      due: '2026-10-28 23:59:00',
      totalMarks: 50,
      status: 'published'
    },
    {
      id: 'ASN-BIO110-01',
      title: 'Bio Project 1: Mendelian Inheritance & Chi-Square Genetic Analysis',
      description: 'Conduct monohybrid and dihybrid cross simulations on Drosophila melanogaster. Formulate null hypotheses and perform Chi-square goodness-of-fit testing.',
      subjectId: 'SUB-BIO110',
      teacherId: 'TCH-002',
      created: '2026-09-15',
      due: '2026-09-30 23:59:00',
      totalMarks: 50,
      status: 'published'
    },
    {
      id: 'ASN-BIO110-02',
      title: 'Bio Project 2: CRISPR/Cas9 Gene Editing Mechanisms & Ethics (Draft)',
      description: 'Review modern guide RNA synthesis protocols and evaluate off-target genomic cleavage risk mitigation strategies.',
      subjectId: 'SUB-BIO110',
      teacherId: 'TCH-002',
      created: '2026-10-20',
      due: '2026-11-15 23:59:00',
      totalMarks: 50,
      status: 'draft'
    }
  ];

  for (const asn of assignments) {
    execute(db, `
      INSERT INTO assignments (assignment_id, title, description, subject_id, teacher_id, creation_date, due_date, total_marks, publication_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [asn.id, asn.title, asn.description, asn.subjectId, asn.teacherId, asn.created, asn.due, asn.totalMarks, asn.status]);
  }

  // 7. Submissions for assignments with feedback and evaluations
  console.log('[EduNexa Seeder] Creating assignment submissions and teacher feedback...');
  // For the first past assignments (ASN-CS101-01, ASN-CS101-02, ASN-MTH201-01, ASN-CHM105-01, ASN-BIO110-01):
  // Let students submit and teacher grade them!
  const pastAssignments = [
    { id: 'ASN-CS101-01', total: 50, teacher: 'Prof. Alan Turing' },
    { id: 'ASN-CS101-02', total: 50, teacher: 'Prof. Alan Turing' },
    { id: 'ASN-MTH201-01', total: 40, teacher: 'Prof. Alan Turing' },
    { id: 'ASN-CHM105-01', total: 45, teacher: 'Dr. Rosalind Franklin' },
    { id: 'ASN-BIO110-01', total: 50, teacher: 'Dr. Rosalind Franklin' }
  ];

  let subCounter = 1;
  for (let sIdx = 0; sIdx < studentIds.length; sIdx++) {
    const sId = studentIds[sIdx];
    const isClassA = sIdx < 13;

    // Pick 2-3 past assignments relevant to their class
    const targetAsns = isClassA
      ? pastAssignments.filter(a => a.id.startsWith('ASN-CS101') || a.id.startsWith('ASN-MTH'))
      : pastAssignments.filter(a => a.id.startsWith('ASN-CHM') || a.id.startsWith('ASN-BIO'));

    for (const asn of targetAsns) {
      const subId = `SUBM-2026-${String(subCounter++).padStart(4, '0')}`;
      const isGraded = sIdx % 4 !== 3; // 75% graded, 25% pending evaluation
      const earned = Math.round(asn.total * (0.75 + (sIdx % 5) * 0.05) * 10) / 10;
      const status = isGraded ? 'Graded' : 'Submitted';

      execute(db, `
        INSERT OR IGNORE INTO submissions (submission_id, assignment_id, student_id, submission_date, answer_text, file_name, file_url, status, marks, feedback, graded_at, graded_by)
        VALUES (?, ?, ?, '2026-09-18 20:15:00', ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        subId,
        asn.id,
        sId,
        `Comprehensive solution implementation attached. Code properly documented with time complexity justifications and empirical benchmark graphs. Tested on Node 20 / Python 3.12 with all test suites passing.`,
        `edunexa_solution_${sId.toLowerCase()}_${asn.id.toLowerCase()}.pdf`,
        `/uploads/sample-solutions/${asn.id.toLowerCase()}.pdf`,
        status,
        isGraded ? earned : null,
        isGraded ? `Well-structured submission. Detailed algorithmic complexity analysis and clean code architecture. Keep up the high standard!` : null,
        isGraded ? '2026-09-22 11:20:00' : null,
        isGraded ? asn.teacher : null
      ]);
    }
  }

  // 8. Notifications
  console.log('[EduNexa Seeder] Creating notifications...');
  const sampleNotifications = [
    {
      title: 'Welcome to EduNexa Academic Portal',
      message: 'Your academic workspace for Fall 2026 is officially active. Review your registered courses and attendance guidelines.',
      type: 'announcement',
      date: '2026-09-01 08:00:00'
    },
    {
      title: 'New Assignment Published: CS101 Graph Traversal',
      message: 'Prof. Alan Turing has published Assignment 3 on Graph Traversals and Dijkstra. Deadline is Nov 05, 2026.',
      type: 'assignment',
      date: '2026-10-15 10:30:00'
    },
    {
      title: 'Graded: CS101 Binary Search Trees',
      message: 'Your submission for Assignment 2 has been evaluated. Review teacher feedback and awarded score.',
      type: 'grade',
      date: '2026-10-14 16:45:00'
    },
    {
      title: 'Midterm Gradebook Published',
      message: 'Subject-wise mid-term assessment marks and official percentage distributions have been released.',
      type: 'grade',
      date: '2026-10-10 09:15:00'
    }
  ];

  // Distribute notifications to teachers and student accounts
  for (const t of teachers) {
    execute(db, `
      INSERT INTO notifications (recipient_user_id, title, message, type, creation_date, is_read)
      VALUES (?, 'Faculty Attendance Review Required', 'Please ensure all daily lecture attendance rosters for Week 7 are submitted.', 'alert', '2026-10-21 08:30:00', 0)
    `, [t.userId]);
  }

  for (let i = 0; i < studentIds.length; i++) {
    const userId = `usr-s${i + 1}`;
    for (const notif of sampleNotifications) {
      execute(db, `
        INSERT INTO notifications (recipient_user_id, title, message, type, creation_date, is_read)
        VALUES (?, ?, ?, ?, ?, 0)
      `, [userId, notif.title, notif.message, notif.type, notif.date]);
    }
  }

  // 9. Activity Logs
  const activityLogs = [
    { action: 'COURSE_SETUP', actor: 'Prof. Alan Turing', role: 'teacher', timestamp: '2026-09-01 09:00:00', details: 'Initialized CS101 and MATH201 syllabus and assessment rubrics.', ref: 'SUB-CS101' },
    { action: 'ATTENDANCE_RECORDED', actor: 'Dr. Rosalind Franklin', role: 'teacher', timestamp: '2026-10-20 10:15:00', details: 'Marked morning attendance for Organic Chemistry Lecture 14.', ref: 'SUB-CHEM105' },
    { action: 'ASSIGNMENT_GRADED', actor: 'Prof. Alan Turing', role: 'teacher', timestamp: '2026-10-21 15:30:00', details: 'Evaluated 12 student submissions for Binary Search Trees.', ref: 'ASN-CS101-02' },
    { action: 'ASSIGNMENT_SUBMITTED', actor: 'Sophia Chen', role: 'student', timestamp: '2026-10-22 18:20:00', details: 'Submitted written analysis and source code for CS101 assignment.', ref: 'STU-2026-002' }
  ];

  for (const log of activityLogs) {
    execute(db, `
      INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [log.action, log.actor, log.role, log.timestamp, log.details, log.ref]);
  }

  saveDb();
  console.log('[EduNexa Seeder] Seeding completed successfully. All 25 students, 3 teachers, 5 subjects, and sample records persisted.');
}
