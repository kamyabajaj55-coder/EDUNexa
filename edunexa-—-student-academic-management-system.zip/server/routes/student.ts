import { Router, Request, Response } from 'express';
import { getDb, queryAll, queryOne, execute } from '../db.js';
import { authenticate, requireRole } from '../auth.js';

const router = Router();

// Guard all student routes
router.use(authenticate, requireRole('student'));

// Helper for letter grade
function calculateGrade(percentage: number): string {
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B';
  if (percentage >= 60) return 'C';
  if (percentage >= 50) return 'D';
  return 'F';
}

function gradeToGpa(grade: string): number {
  switch (grade) {
    case 'A+': return 4.0;
    case 'A': return 3.8;
    case 'B': return 3.0;
    case 'C': return 2.0;
    case 'D': return 1.0;
    default: return 0.0;
  }
}

// ----------------------------------------------------
// Student Profile
// ----------------------------------------------------
router.get('/profile', async (req: Request, res: Response) => {
  const db = await getDb();
  const studentId = req.user!.profileId;

  const student = queryOne(db, 'SELECT * FROM students WHERE student_id = ?', [studentId]);
  if (!student) {
    return res.status(404).json({ error: 'Student record not found.' });
  }

  const enrolments = queryAll(db, `
    SELECT s.subject_id, s.subject_name, s.subject_code, s.maximum_marks, t.name as teacher_name, t.email as teacher_email
    FROM enrolments e
    JOIN subjects s ON e.subject_id = s.subject_id
    JOIN teachers t ON s.teacher_id = t.teacher_id
    WHERE e.student_id = ?
  `, [studentId]);

  return res.json({ student, enrolments });
});

// Update allowed profile fields only (phone, address, bio, guardian_phone)
router.put('/profile', async (req: Request, res: Response) => {
  const db = await getDb();
  const studentId = req.user!.profileId;
  const { phone, address, bio, guardianPhone } = req.body;

  execute(db, `
    UPDATE students
    SET phone = ?, address = ?, bio = ?, guardian_phone = ?
    WHERE student_id = ?
  `, [phone, address, bio, guardianPhone, studentId]);

  return res.json({ message: 'Personal profile updated successfully.' });
});

// ----------------------------------------------------
// Attendance
// ----------------------------------------------------
router.get('/attendance', async (req: Request, res: Response) => {
  const db = await getDb();
  const studentId = req.user!.profileId;

  // All attendance records
  const history = queryAll<any>(db, `
    SELECT a.*, s.subject_name, s.subject_code, t.name as recorded_by_teacher
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.subject_id
    JOIN teachers t ON a.recorded_by_teacher_id = t.teacher_id
    WHERE a.student_id = ?
    ORDER BY a.date DESC
  `, [studentId]);

  let present = 0, late = 0, absent = 0, excused = 0;
  history.forEach(r => {
    if (r.status === 'Present') present++;
    else if (r.status === 'Late') late++;
    else if (r.status === 'Absent') absent++;
    else if (r.status === 'Excused') excused++;
  });

  const total = history.length;
  const eligible = total - excused;
  const overallPercentage = eligible > 0
    ? Math.round(((present + late * 0.5) / eligible) * 1000) / 10
    : 100;

  // Subject-wise attendance breakdown
  const subjectBreakdown = queryAll<any>(db, `
    SELECT s.subject_id, s.subject_name, s.subject_code,
           COUNT(a.id) as total_sessions,
           SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count,
           SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) as late_count,
           SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent_count,
           SUM(CASE WHEN a.status = 'Excused' THEN 1 ELSE 0 END) as excused_count
    FROM enrolments e
    JOIN subjects s ON e.subject_id = s.subject_id
    LEFT JOIN attendance a ON s.subject_id = a.subject_id AND a.student_id = ?
    WHERE e.student_id = ?
    GROUP BY s.subject_id
  `, [studentId, studentId]);

  const subjectsWithPercentages = subjectBreakdown.map(sb => {
    const denom = sb.total_sessions - sb.excused_count;
    const pct = denom > 0
      ? Math.round(((sb.present_count + sb.late_count * 0.5) / denom) * 1000) / 10
      : 100;
    return {
      ...sb,
      percentage: pct,
      isLow: pct < 75
    };
  });

  return res.json({
    summary: {
      total,
      present,
      late,
      absent,
      excused,
      overallPercentage,
      isLowAttendanceWarning: overallPercentage < 75,
      calculationFormula: "((Present + 0.5 * Late) / (Total Sessions - Excused)) * 100"
    },
    subjectBreakdown: subjectsWithPercentages,
    history
  });
});

// ----------------------------------------------------
// Academic Results / Grades
// ----------------------------------------------------
router.get('/grades', async (req: Request, res: Response) => {
  const db = await getDb();
  const studentId = req.user!.profileId;

  const grades = queryAll<any>(db, `
    SELECT g.*, asm.assessment_name, asm.maximum_marks, asm.weightage, asm.date, asm.term,
           s.subject_id, s.subject_name, s.subject_code, t.name as teacher_name
    FROM grades g
    JOIN assessments asm ON g.assessment_id = asm.assessment_id
    JOIN subjects s ON asm.subject_id = s.subject_id
    JOIN teachers t ON s.teacher_id = t.teacher_id
    WHERE g.student_id = ?
    ORDER BY asm.date DESC
  `, [studentId]);

  // Calculate overall performance
  let totalObtained = 0;
  let totalMax = 0;
  let gpaSum = 0;

  grades.forEach(g => {
    totalObtained += g.obtained_marks;
    totalMax += g.maximum_marks;
    gpaSum += gradeToGpa(g.grade);
  });

  const overallPercentage = totalMax > 0 ? Math.round((totalObtained / totalMax) * 1000) / 10 : 0;
  const cumulativeGpa = grades.length > 0 ? Math.round((gpaSum / grades.length) * 100) / 100 : 0;
  const overallGrade = calculateGrade(overallPercentage);

  // Group by subjects
  const enrolledSubjects = queryAll<any>(db, `
    SELECT s.subject_id, s.subject_name, s.subject_code
    FROM enrolments e
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.student_id = ?
  `, [studentId]);

  const subjectSummary = enrolledSubjects.map(sub => {
    const subGrades = grades.filter(g => g.subject_id === sub.subject_id);
    let sObtained = 0, sMax = 0;
    subGrades.forEach(g => {
      sObtained += g.obtained_marks;
      sMax += g.maximum_marks;
    });
    const pct = sMax > 0 ? Math.round((sObtained / sMax) * 1000) / 10 : 0;
    return {
      ...sub,
      assessmentsCount: subGrades.length,
      obtainedMarks: sObtained,
      maximumMarks: sMax,
      percentage: pct,
      grade: calculateGrade(pct),
      grades: subGrades
    };
  });

  return res.json({
    summary: {
      totalAssessments: grades.length,
      totalObtainedMarks: Math.round(totalObtained * 10) / 10,
      totalMaximumMarks: totalMax,
      overallPercentage,
      cumulativeGpa,
      overallGrade,
      calculationFormula: "(Total Obtained Marks / Total Maximum Marks) * 100"
    },
    subjectSummary,
    grades
  });
});

// ----------------------------------------------------
// Assignments
// ----------------------------------------------------
router.get('/assignments', async (req: Request, res: Response) => {
  const db = await getDb();
  const studentId = req.user!.profileId;

  // Get assignments published for student's enrolled subjects
  const assignments = queryAll<any>(db, `
    SELECT a.*, s.subject_name, s.subject_code, t.name as teacher_name,
           sub.submission_id, sub.submission_date, sub.answer_text, sub.file_name, sub.file_url,
           sub.marks, sub.feedback, sub.graded_at, sub.graded_by,
           CASE
             WHEN sub.status IS NOT NULL THEN sub.status
             WHEN datetime('now') > datetime(a.due_date) THEN 'Overdue'
             ELSE 'Pending'
           END as current_status
    FROM enrolments e
    JOIN assignments a ON e.subject_id = a.subject_id
    JOIN subjects s ON a.subject_id = s.subject_id
    JOIN teachers t ON a.teacher_id = t.teacher_id
    LEFT JOIN submissions sub ON a.assignment_id = sub.assignment_id AND sub.student_id = ?
    WHERE e.student_id = ? AND a.publication_status = 'published'
    ORDER BY a.due_date ASC
  `, [studentId, studentId]);

  return res.json({ assignments });
});

// Submit assignment
router.post('/assignments/:assignmentId/submit', async (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const { answerText, fileName } = req.body;
  const studentId = req.user!.profileId;

  if (!answerText && !fileName) {
    return res.status(400).json({ error: 'Please provide either written answer text or attach a file.' });
  }

  const db = await getDb();

  // Verify assignment is published and student is enrolled
  const assignment = queryOne<any>(db, `
    SELECT a.*, e.student_id
    FROM assignments a
    JOIN enrolments e ON a.subject_id = e.subject_id
    WHERE a.assignment_id = ? AND e.student_id = ? AND a.publication_status = 'published'
  `, [assignmentId, studentId]);

  if (!assignment) {
    return res.status(404).json({ error: 'Assignment not found or you are not enrolled in this subject.' });
  }

  // Check if existing graded
  const existingSub = queryOne<any>(db, `
    SELECT * FROM submissions WHERE assignment_id = ? AND student_id = ?
  `, [assignmentId, studentId]);

  if (existingSub && existingSub.status === 'Graded') {
    return res.status(400).json({ error: 'This assignment has already been evaluated and cannot be resubmitted.' });
  }

  const isLate = new Date().toISOString() > new Date(assignment.due_date).toISOString();
  const status = isLate ? 'Late' : 'Submitted';
  const submissionId = existingSub ? existingSub.submission_id : `SUBM-${Date.now()}`;
  const fileUrl = fileName ? `/uploads/submissions/${assignmentId}_${studentId}_${fileName}` : null;

  execute(db, `
    INSERT INTO submissions (submission_id, assignment_id, student_id, submission_date, answer_text, file_name, file_url, status)
    VALUES (?, ?, ?, datetime('now'), ?, ?, ?, ?)
    ON CONFLICT(assignment_id, student_id)
    DO UPDATE SET
      submission_date = excluded.submission_date,
      answer_text = excluded.answer_text,
      file_name = excluded.file_name,
      file_url = excluded.file_url,
      status = excluded.status
  `, [submissionId, assignmentId, studentId, answerText || '', fileName || null, fileUrl, status]);

  // Log activity
  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('ASSIGNMENT_SUBMITTED', ?, 'student', datetime('now'), ?, ?)
  `, [req.user!.name, `Submitted solution for "${assignment.title}" (${status})`, submissionId]);

  return res.json({
    message: isLate ? 'Assignment submitted (marked Late due to deadline).' : 'Assignment submitted successfully.',
    submissionId,
    status
  });
});

// ----------------------------------------------------
// Notifications
// ----------------------------------------------------
router.get('/notifications', async (req: Request, res: Response) => {
  const db = await getDb();
  const userId = req.user!.userId;

  const notifications = queryAll(db, `
    SELECT * FROM notifications
    WHERE recipient_user_id = ?
    ORDER BY creation_date DESC
    LIMIT 30
  `, [userId]);

  const unreadCount = queryOne<{ count: number }>(db, `
    SELECT COUNT(*) as count FROM notifications
    WHERE recipient_user_id = ? AND is_read = 0
  `, [userId]);

  return res.json({
    notifications,
    unreadCount: unreadCount ? unreadCount.count : 0
  });
});

// Mark single notification read
router.put('/notifications/:id/read', async (req: Request, res: Response) => {
  const db = await getDb();
  const { id } = req.params;
  const userId = req.user!.userId;

  execute(db, 'UPDATE notifications SET is_read = 1 WHERE id = ? AND recipient_user_id = ?', [id, userId]);
  return res.json({ message: 'Notification marked as read.' });
});

// Mark all notifications read
router.post('/notifications/mark-all-read', async (req: Request, res: Response) => {
  const db = await getDb();
  const userId = req.user!.userId;

  execute(db, 'UPDATE notifications SET is_read = 1 WHERE recipient_user_id = ?', [userId]);
  return res.json({ message: 'All notifications marked as read.' });
});

export default router;
