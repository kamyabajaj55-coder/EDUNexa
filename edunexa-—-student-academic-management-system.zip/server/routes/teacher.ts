import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { getDb, queryAll, queryOne, execute, saveDb } from '../db.js';
import { authenticate, requireRole } from '../auth.js';

const router = Router();

// Guard all teacher routes
router.use(authenticate, requireRole('teacher'));

// Helper to determine letter grade
export function calculateGrade(percentage: number): string {
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B';
  if (percentage >= 60) return 'C';
  if (percentage >= 50) return 'D';
  return 'F';
}

// ----------------------------------------------------
// Analytics & Overview
// ----------------------------------------------------
router.get('/dashboard-stats', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;

  // Subjects taught by this teacher
  const subjects = queryAll<any>(db, 'SELECT * FROM subjects WHERE teacher_id = ?', [teacherId]);
  const subjectIds = subjects.map(s => s.subject_id);

  if (subjectIds.length === 0) {
    return res.json({
      totalStudents: 0,
      averageAttendance: 0,
      subjectAverages: [],
      attentionStudents: [],
      pendingSubmissionsCount: 0,
      recentActivity: []
    });
  }

  const inClause = subjectIds.map(() => '?').join(',');

  // Unique assigned students
  const studentsCount = queryOne<{ count: number }>(db, `
    SELECT COUNT(DISTINCT student_id) as count
    FROM enrolments
    WHERE subject_id IN (${inClause})
  `, subjectIds);

  // Attendance stats for this teacher's subjects
  const attendanceRows = queryAll<{ status: string }>(db, `
    SELECT status
    FROM attendance
    WHERE subject_id IN (${inClause})
  `, subjectIds);

  let presentCount = 0;
  let lateCount = 0;
  let excusedCount = 0;
  let totalSessions = attendanceRows.length;

  for (const row of attendanceRows) {
    if (row.status === 'Present') presentCount++;
    else if (row.status === 'Late') lateCount++;
    else if (row.status === 'Excused') excusedCount++;
  }

  const eligibleSessions = totalSessions - excusedCount;
  const overallAttendance = eligibleSessions > 0
    ? Math.round(((presentCount + lateCount * 0.5) / eligibleSessions) * 1000) / 10
    : 100;

  // Subject-wise grade averages
  const subjectAverages = queryAll<any>(db, `
    SELECT s.subject_id, s.subject_name, s.subject_code,
           ROUND(AVG(g.calculated_percentage), 1) as avg_percentage,
           COUNT(DISTINCT g.student_id) as graded_students
    FROM subjects s
    LEFT JOIN assessments a ON s.subject_id = a.subject_id
    LEFT JOIN grades g ON a.assessment_id = g.assessment_id
    WHERE s.teacher_id = ?
    GROUP BY s.subject_id
  `, [teacherId]);

  // Students requiring academic attention (<75% attendance or <60% average marks)
  const assignedStudents = queryAll<any>(db, `
    SELECT DISTINCT st.student_id, st.name, st.class, st.email, st.account_status
    FROM students st
    JOIN enrolments e ON st.student_id = e.student_id
    WHERE e.subject_id IN (${inClause})
  `, subjectIds);

  const attentionStudents: any[] = [];

  for (const st of assignedStudents) {
    // Student attendance in teacher's subjects
    const stAtt = queryAll<{ status: string }>(db, `
      SELECT status FROM attendance
      WHERE student_id = ? AND subject_id IN (${inClause})
    `, [st.student_id, ...subjectIds]);

    let stP = 0, stL = 0, stE = 0;
    stAtt.forEach(a => {
      if (a.status === 'Present') stP++;
      else if (a.status === 'Late') stL++;
      else if (a.status === 'Excused') stE++;
    });
    const stEligible = stAtt.length - stE;
    const attPct = stEligible > 0 ? Math.round(((stP + stL * 0.5) / stEligible) * 1000) / 10 : 100;

    // Student avg grades in teacher's subjects
    const gradeAvg = queryOne<{ avg_pct: number }>(db, `
      SELECT AVG(g.calculated_percentage) as avg_pct
      FROM grades g
      JOIN assessments a ON g.assessment_id = a.assessment_id
      WHERE g.student_id = ? AND a.subject_id IN (${inClause})
    `, [st.student_id, ...subjectIds]);

    const academicPct = gradeAvg && gradeAvg.avg_pct != null ? Math.round(gradeAvg.avg_pct * 10) / 10 : 0;

    if (attPct < 75 || (academicPct > 0 && academicPct < 60)) {
      attentionStudents.push({
        ...st,
        attendancePercentage: attPct,
        academicPercentage: academicPct,
        issues: [
          ...(attPct < 75 ? [`Low Attendance (${attPct}%)`] : []),
          ...(academicPct > 0 && academicPct < 60 ? [`At-Risk Grades (${academicPct}%)`] : [])
        ]
      });
    }
  }

  // Pending submissions
  const pendingCount = queryOne<{ count: number }>(db, `
    SELECT COUNT(*) as count
    FROM submissions sub
    JOIN assignments a ON sub.assignment_id = a.assignment_id
    WHERE a.teacher_id = ? AND sub.status IN ('Submitted', 'Late')
  `, [teacherId]);

  // Recent 30 days attendance trends
  const trendRows = queryAll<any>(db, `
    SELECT date,
           ROUND(100.0 * SUM(CASE WHEN status = 'Present' THEN 1 WHEN status = 'Late' THEN 0.5 ELSE 0 END) /
           MAX(1, SUM(CASE WHEN status != 'Excused' THEN 1 ELSE 0 END)), 1) as percentage
    FROM attendance
    WHERE subject_id IN (${inClause})
    GROUP BY date
    ORDER BY date ASC
    LIMIT 30
  `, subjectIds);

  // Recent activity logs
  const recentLogs = queryAll<any>(db, `
    SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 8
  `);

  return res.json({
    teacher: queryOne(db, 'SELECT * FROM teachers WHERE teacher_id = ?', [teacherId]),
    subjects,
    totalStudents: studentsCount ? studentsCount.count : 0,
    overallAttendance,
    subjectAverages,
    attentionStudents,
    pendingSubmissionsCount: pendingCount ? pendingCount.count : 0,
    attendanceTrend: trendRows,
    recentActivity: recentLogs
  });
});

// ----------------------------------------------------
// Subjects Taught
// ----------------------------------------------------
router.get('/subjects', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const subjects = queryAll<any>(db, `
    SELECT s.*, COUNT(e.student_id) as enrolled_count
    FROM subjects s
    LEFT JOIN enrolments e ON s.subject_id = e.subject_id
    WHERE s.teacher_id = ?
    GROUP BY s.subject_id
  `, [teacherId]);
  return res.json({ subjects });
});

// ----------------------------------------------------
// Student Management
// ----------------------------------------------------
router.get('/students', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const { search, classFilter, subjectId } = req.query;

  const teacherSubjects = queryAll<any>(db, 'SELECT subject_id FROM subjects WHERE teacher_id = ?', [teacherId]);
  const allowedSubIds = teacherSubjects.map(s => s.subject_id);

  if (allowedSubIds.length === 0) {
    return res.json({ students: [] });
  }

  const inClause = allowedSubIds.map(() => '?').join(',');
  let query = `
    SELECT DISTINCT st.*
    FROM students st
    JOIN enrolments e ON st.student_id = e.student_id
    WHERE e.subject_id IN (${inClause})
  `;
  const params: any[] = [...allowedSubIds];

  if (subjectId && allowedSubIds.includes(String(subjectId))) {
    query += ` AND e.subject_id = ?`;
    params.push(String(subjectId));
  }

  if (classFilter && classFilter !== 'all') {
    query += ` AND st.class = ?`;
    params.push(String(classFilter));
  }

  if (search) {
    query += ` AND (LOWER(st.name) LIKE ? OR LOWER(st.student_id) LIKE ? OR LOWER(st.email) LIKE ?)`;
    const term = `%${String(search).toLowerCase()}%`;
    params.push(term, term, term);
  }

  query += ` ORDER BY st.name ASC`;
  const students = queryAll<any>(db, query, params);

  // Attach quick metrics (attendance and academic %) to each student
  const studentsWithMetrics = students.map(st => {
    // Attendance
    const attRows = queryAll<{ status: string }>(db, `
      SELECT status FROM attendance WHERE student_id = ? AND subject_id IN (${inClause})
    `, [st.student_id, ...allowedSubIds]);

    let p = 0, l = 0, e = 0;
    attRows.forEach(a => {
      if (a.status === 'Present') p++;
      else if (a.status === 'Late') l++;
      else if (a.status === 'Excused') e++;
    });
    const denom = attRows.length - e;
    const attPct = denom > 0 ? Math.round(((p + l * 0.5) / denom) * 1000) / 10 : 100;

    // Grades
    const gAvg = queryOne<{ avg_pct: number }>(db, `
      SELECT AVG(g.calculated_percentage) as avg_pct
      FROM grades g
      JOIN assessments a ON g.assessment_id = a.assessment_id
      WHERE g.student_id = ? AND a.subject_id IN (${inClause})
    `, [st.student_id, ...allowedSubIds]);

    const gradePct = gAvg && gAvg.avg_pct != null ? Math.round(gAvg.avg_pct * 10) / 10 : null;

    return {
      ...st,
      attendancePercentage: attPct,
      academicPercentage: gradePct,
      gradeLetter: gradePct !== null ? calculateGrade(gradePct) : 'N/A'
    };
  });

  return res.json({ students: studentsWithMetrics });
});

// Single student profile with all academic history
router.get('/students/:studentId', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const { studentId } = req.params;

  // Verify permission: student must be in one of the teacher's classes/subjects
  const enrolment = queryOne(db, `
    SELECT e.student_id
    FROM enrolments e
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.student_id = ? AND s.teacher_id = ?
  `, [studentId, teacherId]);

  if (!enrolment) {
    return res.status(403).json({ error: 'You are not authorized to view this student profile.' });
  }

  const student = queryOne(db, 'SELECT * FROM students WHERE student_id = ?', [studentId]);
  if (!student) {
    return res.status(404).json({ error: 'Student not found.' });
  }

  // Enrolled subjects taught by this teacher
  const subjects = queryAll(db, `
    SELECT s.*
    FROM subjects s
    JOIN enrolments e ON s.subject_id = e.subject_id
    WHERE e.student_id = ? AND s.teacher_id = ?
  `, [studentId, teacherId]);

  // Attendance breakdown
  const attendance = queryAll(db, `
    SELECT a.*, s.subject_name, s.subject_code
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.student_id = ? AND s.teacher_id = ?
    ORDER BY a.date DESC
  `, [studentId, teacherId]);

  // Grades breakdown
  const grades = queryAll(db, `
    SELECT g.*, asm.assessment_name, asm.maximum_marks, asm.weightage, asm.date, s.subject_name, s.subject_code
    FROM grades g
    JOIN assessments asm ON g.assessment_id = asm.assessment_id
    JOIN subjects s ON asm.subject_id = s.subject_id
    WHERE g.student_id = ? AND s.teacher_id = ?
    ORDER BY asm.date DESC
  `, [studentId, teacherId]);

  // Submissions breakdown
  const submissions = queryAll(db, `
    SELECT sub.*, a.title as assignment_title, a.total_marks, a.due_date, s.subject_name
    FROM submissions sub
    JOIN assignments a ON sub.assignment_id = a.assignment_id
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE sub.student_id = ? AND a.teacher_id = ?
    ORDER BY sub.submission_date DESC
  `, [studentId, teacherId]);

  return res.json({
    student,
    subjects,
    attendance,
    grades,
    submissions
  });
});

// Add student
router.post('/students', async (req: Request, res: Response) => {
  const { name, email, studentId, class: className, subjectId, phone, guardianName, guardianPhone, address } = req.body;
  const teacherId = req.user!.profileId;

  if (!name || !email || !studentId || !className || !subjectId) {
    return res.status(400).json({ error: 'Name, email, student ID, class, and subject are required.' });
  }

  const db = await getDb();

  // Validate teacher owns subject
  const subject = queryOne(db, 'SELECT * FROM subjects WHERE subject_id = ? AND teacher_id = ?', [subjectId, teacherId]);
  if (!subject) {
    return res.status(403).json({ error: 'Subject is not assigned to your account.' });
  }

  // Check unique constraints
  const existingStudent = queryOne(db, 'SELECT * FROM students WHERE student_id = ? OR email = ?', [studentId, email]);
  if (existingStudent) {
    return res.status(400).json({ error: 'A student with this ID or email already exists.' });
  }

  const username = email.split('@')[0].toLowerCase().replace(/[^a-z0-9.]/g, '');
  const existingUser = queryOne(db, 'SELECT * FROM users WHERE username = ?', [username]);
  const finalUsername = existingUser ? `${username}.${Math.floor(100 + Math.random() * 900)}` : username;
  const userId = `usr-gen-${Date.now()}`;
  const defaultPasswordHash = bcrypt.hashSync('Student@123', 10);

  // Insert user
  execute(db, `
    INSERT INTO users (user_id, username, password_hash, role, account_status, created_at)
    VALUES (?, ?, ?, 'student', 'active', datetime('now'))
  `, [userId, finalUsername, defaultPasswordHash]);

  // Insert student
  execute(db, `
    INSERT INTO students (student_id, user_id, name, email, class, enrollment_date, phone, address, guardian_name, guardian_phone, bio, account_status)
    VALUES (?, ?, ?, ?, ?, date('now'), ?, ?, ?, ?, 'Newly registered undergraduate student.', 'active')
  `, [studentId, userId, name, email, className, phone || null, address || null, guardianName || null, guardianPhone || null]);

  // Enroll in subject
  execute(db, `
    INSERT INTO enrolments (student_id, subject_id, class, academic_session, status)
    VALUES (?, ?, ?, '2026-2027', 'enrolled')
  `, [studentId, subjectId, className]);

  // Log activity
  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('STUDENT_ENROLLED', ?, 'teacher', datetime('now'), ?, ?)
  `, [req.user!.name, `Registered new student ${name} (${studentId}) into ${subject.subject_name}`, studentId]);

  return res.status(201).json({
    message: 'Student registered successfully',
    studentId,
    username: finalUsername,
    defaultPassword: 'Student@123'
  });
});

// Edit student permitted fields
router.put('/students/:studentId', async (req: Request, res: Response) => {
  const { studentId } = req.params;
  const { name, email, class: className, phone, address, guardianName, guardianPhone, bio } = req.body;
  const teacherId = req.user!.profileId;

  const db = await getDb();

  // Verify permission
  const enrolment = queryOne(db, `
    SELECT e.student_id FROM enrolments e
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE e.student_id = ? AND s.teacher_id = ?
  `, [studentId, teacherId]);

  if (!enrolment) {
    return res.status(403).json({ error: 'You are not authorized to edit this student.' });
  }

  // Update
  execute(db, `
    UPDATE students
    SET name = ?, email = ?, class = ?, phone = ?, address = ?, guardian_name = ?, guardian_phone = ?, bio = ?
    WHERE student_id = ?
  `, [name, email, className, phone, address, guardianName, guardianPhone, bio, studentId]);

  return res.json({ message: 'Student record updated successfully.' });
});

// Deactivate student account without destroying academic records
router.post('/students/:studentId/toggle-status', async (req: Request, res: Response) => {
  const { studentId } = req.params;
  const { status } = req.body; // 'active' or 'deactivated'
  const teacherId = req.user!.profileId;

  if (!['active', 'deactivated'].includes(status)) {
    return res.status(400).json({ error: 'Status must be active or deactivated.' });
  }

  const db = await getDb();
  const student = queryOne<any>(db, `
    SELECT st.* FROM students st
    JOIN enrolments e ON st.student_id = e.student_id
    JOIN subjects s ON e.subject_id = s.subject_id
    WHERE st.student_id = ? AND s.teacher_id = ?
  `, [studentId, teacherId]);

  if (!student) {
    return res.status(403).json({ error: 'Unauthorized to change account status for this student.' });
  }

  execute(db, 'UPDATE students SET account_status = ? WHERE student_id = ?', [status, studentId]);
  execute(db, 'UPDATE users SET account_status = ? WHERE user_id = ?', [status, student.user_id]);

  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('STUDENT_STATUS_CHANGED', ?, 'teacher', datetime('now'), ?, ?)
  `, [req.user!.name, `Changed account status of ${student.name} to ${status}`, studentId]);

  return res.json({ message: `Student account ${status === 'active' ? 'activated' : 'deactivated'} successfully.` });
});

// ----------------------------------------------------
// Attendance Management
// ----------------------------------------------------
router.get('/attendance', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const { subjectId, date } = req.query;

  if (!subjectId || !date) {
    return res.status(400).json({ error: 'Subject ID and date are required.' });
  }

  // Verify subject
  const subject = queryOne<any>(db, 'SELECT * FROM subjects WHERE subject_id = ? AND teacher_id = ?', [subjectId, teacherId]);
  if (!subject) {
    return res.status(403).json({ error: 'Subject not assigned to this teacher.' });
  }

  // Get enrolled students
  const enrolledStudents = queryAll<any>(db, `
    SELECT st.student_id, st.name, st.class, st.email, st.account_status,
           att.status as attendance_status, att.remarks as attendance_remarks
    FROM enrolments e
    JOIN students st ON e.student_id = st.student_id
    LEFT JOIN attendance att ON st.student_id = att.student_id AND att.subject_id = ? AND att.date = ?
    WHERE e.subject_id = ? AND st.account_status = 'active'
    ORDER BY st.name ASC
  `, [subjectId, date, subjectId]);

  return res.json({
    subject,
    date,
    students: enrolledStudents
  });
});

// Save batch attendance
router.post('/attendance', async (req: Request, res: Response) => {
  const { subjectId, date, sessionName, records } = req.body;
  const teacherId = req.user!.profileId;

  if (!subjectId || !date || !Array.isArray(records)) {
    return res.status(400).json({ error: 'subjectId, date, and records array are required.' });
  }

  const db = await getDb();
  const subject = queryOne<any>(db, 'SELECT * FROM subjects WHERE subject_id = ? AND teacher_id = ?', [subjectId, teacherId]);
  if (!subject) {
    return res.status(403).json({ error: 'Unauthorized subject access.' });
  }

  const session = sessionName || 'Morning Session';

  for (const rec of records) {
    const { studentId, status, remarks } = rec;
    if (!['Present', 'Absent', 'Late', 'Excused'].includes(status)) {
      continue;
    }

    // Upsert attendance
    execute(db, `
      INSERT INTO attendance (student_id, subject_id, class, date, session_name, status, recorded_by_teacher_id, remarks)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(student_id, subject_id, date, session_name)
      DO UPDATE SET status = excluded.status, remarks = excluded.remarks, recorded_by_teacher_id = excluded.recorded_by_teacher_id
    `, [studentId, subjectId, subject.class, date, session, status, teacherId, remarks || null]);
  }

  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('ATTENDANCE_RECORDED', ?, 'teacher', datetime('now'), ?, ?)
  `, [req.user!.name, `Saved attendance records for ${records.length} students in ${subject.subject_name} on ${date}`, subjectId]);

  return res.json({ message: 'Attendance records saved successfully.' });
});

// ----------------------------------------------------
// Marks & Grade Management
// ----------------------------------------------------
router.get('/assessments', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const { subjectId } = req.query;

  let query = `
    SELECT a.*, s.subject_name, s.subject_code,
           COUNT(g.student_id) as graded_count,
           ROUND(AVG(g.obtained_marks), 1) as avg_marks,
           ROUND(AVG(g.calculated_percentage), 1) as avg_percentage
    FROM assessments a
    JOIN subjects s ON a.subject_id = s.subject_id
    LEFT JOIN grades g ON a.assessment_id = g.assessment_id
    WHERE s.teacher_id = ?
  `;
  const params: any[] = [teacherId];

  if (subjectId) {
    query += ` AND a.subject_id = ?`;
    params.push(String(subjectId));
  }

  query += ` GROUP BY a.assessment_id ORDER BY a.date DESC`;
  const assessments = queryAll(db, query, params);
  return res.json({ assessments });
});

// Create new assessment
router.post('/assessments', async (req: Request, res: Response) => {
  const { assessmentName, subjectId, date, maximumMarks, weightage, term } = req.body;
  const teacherId = req.user!.profileId;

  if (!assessmentName || !subjectId || !date || !maximumMarks) {
    return res.status(400).json({ error: 'Assessment name, subject, date, and maximum marks are required.' });
  }

  const db = await getDb();
  const subject = queryOne(db, 'SELECT * FROM subjects WHERE subject_id = ? AND teacher_id = ?', [subjectId, teacherId]);
  if (!subject) {
    return res.status(403).json({ error: 'Unauthorized subject access.' });
  }

  const assessmentId = `ASM-${Date.now()}`;
  execute(db, `
    INSERT INTO assessments (assessment_id, assessment_name, subject_id, date, maximum_marks, weightage, term)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [assessmentId, assessmentName, subjectId, date, Number(maximumMarks), Number(weightage) || 20, term || 'Fall 2026']);

  return res.status(201).json({ message: 'Assessment created successfully', assessmentId });
});

// Get enrolled students & existing marks for an assessment
router.get('/assessments/:assessmentId/marks', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const { assessmentId } = req.params;

  const assessment = queryOne<any>(db, `
    SELECT a.*, s.subject_name, s.subject_code
    FROM assessments a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.assessment_id = ? AND s.teacher_id = ?
  `, [assessmentId, teacherId]);

  if (!assessment) {
    return res.status(404).json({ error: 'Assessment not found or unauthorized.' });
  }

  const students = queryAll<any>(db, `
    SELECT st.student_id, st.name, st.class, st.email,
           g.obtained_marks, g.calculated_percentage, g.grade, g.teacher_remarks, g.updated_at
    FROM enrolments e
    JOIN students st ON e.student_id = st.student_id
    LEFT JOIN grades g ON st.student_id = g.student_id AND g.assessment_id = ?
    WHERE e.subject_id = ? AND st.account_status = 'active'
    ORDER BY st.name ASC
  `, [assessmentId, assessment.subject_id]);

  return res.json({ assessment, students });
});

// Batch update marks
router.post('/assessments/:assessmentId/marks', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;
  const { assessmentId } = req.params;
  const { marks } = req.body; // array of { studentId, obtainedMarks, remarks }

  if (!Array.isArray(marks)) {
    return res.status(400).json({ error: 'Marks must be an array of student grade objects.' });
  }

  const assessment = queryOne<any>(db, `
    SELECT a.*, s.subject_name
    FROM assessments a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.assessment_id = ? AND s.teacher_id = ?
  `, [assessmentId, teacherId]);

  if (!assessment) {
    return res.status(404).json({ error: 'Assessment not found or unauthorized.' });
  }

  for (const m of marks) {
    const { studentId, obtainedMarks, remarks } = m;
    if (obtainedMarks === null || obtainedMarks === undefined || obtainedMarks === '') continue;

    const numMarks = Number(obtainedMarks);
    if (isNaN(numMarks) || numMarks < 0 || numMarks > assessment.maximum_marks) {
      return res.status(400).json({
        error: `Marks for ${studentId} must be a number between 0 and ${assessment.maximum_marks}.`
      });
    }

    const calculatedPct = Math.round((numMarks / assessment.maximum_marks) * 1000) / 10;
    const gradeLetter = calculateGrade(calculatedPct);

    execute(db, `
      INSERT INTO grades (student_id, assessment_id, obtained_marks, calculated_percentage, grade, teacher_remarks, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(student_id, assessment_id)
      DO UPDATE SET
        obtained_marks = excluded.obtained_marks,
        calculated_percentage = excluded.calculated_percentage,
        grade = excluded.grade,
        teacher_remarks = excluded.teacher_remarks,
        updated_at = excluded.updated_at
    `, [studentId, assessmentId, numMarks, calculatedPct, gradeLetter, remarks || null]);
  }

  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('GRADES_UPDATED', ?, 'teacher', datetime('now'), ?, ?)
  `, [req.user!.name, `Updated grades for ${marks.length} students on ${assessment.assessment_name}`, assessmentId]);

  return res.json({ message: 'Grades saved and calculated successfully.' });
});

// ----------------------------------------------------
// Assignment Management
// ----------------------------------------------------
router.get('/assignments', async (req: Request, res: Response) => {
  const db = await getDb();
  const teacherId = req.user!.profileId;

  const assignments = queryAll<any>(db, `
    SELECT a.*, s.subject_name, s.subject_code,
           COUNT(sub.submission_id) as total_submissions,
           SUM(CASE WHEN sub.status = 'Graded' THEN 1 ELSE 0 END) as graded_count,
           SUM(CASE WHEN sub.status IN ('Submitted', 'Late') THEN 1 ELSE 0 END) as pending_count
    FROM assignments a
    JOIN subjects s ON a.subject_id = s.subject_id
    LEFT JOIN submissions sub ON a.assignment_id = sub.assignment_id
    WHERE a.teacher_id = ?
    GROUP BY a.assignment_id
    ORDER BY a.creation_date DESC
  `, [teacherId]);

  return res.json({ assignments });
});

// Create assignment
router.post('/assignments', async (req: Request, res: Response) => {
  const { title, description, subjectId, totalMarks, dueDate, publicationStatus } = req.body;
  const teacherId = req.user!.profileId;

  if (!title || !description || !subjectId || !dueDate || !totalMarks) {
    return res.status(400).json({ error: 'Title, description, subject, total marks, and due date are required.' });
  }

  const db = await getDb();
  const subject = queryOne(db, 'SELECT * FROM subjects WHERE subject_id = ? AND teacher_id = ?', [subjectId, teacherId]);
  if (!subject) {
    return res.status(403).json({ error: 'Unauthorized subject access.' });
  }

  const assignmentId = `ASN-${Date.now()}`;
  const status = publicationStatus || 'published';

  execute(db, `
    INSERT INTO assignments (assignment_id, title, description, subject_id, teacher_id, creation_date, due_date, total_marks, publication_status)
    VALUES (?, ?, ?, ?, ?, datetime('now'), ?, ?, ?)
  `, [assignmentId, title, description, subjectId, teacherId, dueDate, Number(totalMarks), status]);

  // If published, notify enrolled students
  if (status === 'published') {
    const enrolledStudents = queryAll<{ user_id: string }>(db, `
      SELECT st.user_id
      FROM enrolments e
      JOIN students st ON e.student_id = st.student_id
      WHERE e.subject_id = ?
    `, [subjectId]);

    for (const st of enrolledStudents) {
      execute(db, `
        INSERT INTO notifications (recipient_user_id, title, message, type, creation_date, is_read)
        VALUES (?, ?, ?, 'assignment', datetime('now'), 0)
      `, [st.user_id, `New Assignment: ${title}`, `Assignment has been posted. Due on ${dueDate}.`]);
    }
  }

  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('ASSIGNMENT_CREATED', ?, 'teacher', datetime('now'), ?, ?)
  `, [req.user!.name, `Created assignment "${title}"`, assignmentId]);

  return res.status(201).json({ message: 'Assignment created successfully', assignmentId });
});

// Edit assignment
router.put('/assignments/:assignmentId', async (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const { title, description, totalMarks, dueDate, publicationStatus } = req.body;
  const teacherId = req.user!.profileId;

  const db = await getDb();
  const assignment = queryOne(db, 'SELECT * FROM assignments WHERE assignment_id = ? AND teacher_id = ?', [assignmentId, teacherId]);
  if (!assignment) {
    return res.status(404).json({ error: 'Assignment not found or unauthorized.' });
  }

  execute(db, `
    UPDATE assignments
    SET title = ?, description = ?, total_marks = ?, due_date = ?, publication_status = ?
    WHERE assignment_id = ?
  `, [title, description, Number(totalMarks), dueDate, publicationStatus, assignmentId]);

  return res.json({ message: 'Assignment updated successfully.' });
});

// Delete assignment safely
router.delete('/assignments/:assignmentId', async (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const teacherId = req.user!.profileId;

  const db = await getDb();
  const assignment = queryOne(db, 'SELECT * FROM assignments WHERE assignment_id = ? AND teacher_id = ?', [assignmentId, teacherId]);
  if (!assignment) {
    return res.status(404).json({ error: 'Assignment not found or unauthorized.' });
  }

  execute(db, 'DELETE FROM submissions WHERE assignment_id = ?', [assignmentId]);
  execute(db, 'DELETE FROM assignments WHERE assignment_id = ?', [assignmentId]);

  return res.json({ message: 'Assignment and related submissions deleted successfully.' });
});

// View submissions for an assignment
router.get('/assignments/:assignmentId/submissions', async (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const teacherId = req.user!.profileId;

  const db = await getDb();
  const assignment = queryOne<any>(db, `
    SELECT a.*, s.subject_name
    FROM assignments a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.assignment_id = ? AND a.teacher_id = ?
  `, [assignmentId, teacherId]);

  if (!assignment) {
    return res.status(404).json({ error: 'Assignment not found or unauthorized.' });
  }

  // List all enrolled students with their submission status
  const submissions = queryAll<any>(db, `
    SELECT st.student_id, st.name, st.class, st.email,
           sub.submission_id, sub.submission_date, sub.answer_text, sub.file_name, sub.file_url,
           COALESCE(sub.status, 'Pending') as submission_status,
           sub.marks, sub.feedback, sub.graded_at, sub.graded_by
    FROM enrolments e
    JOIN students st ON e.student_id = st.student_id
    LEFT JOIN submissions sub ON e.student_id = sub.student_id AND sub.assignment_id = ?
    WHERE e.subject_id = ? AND st.account_status = 'active'
    ORDER BY st.name ASC
  `, [assignmentId, assignment.subject_id]);

  return res.json({ assignment, submissions });
});

// Grade an individual submission
router.post('/submissions/:submissionId/grade', async (req: Request, res: Response) => {
  const { submissionId } = req.params;
  const { marks, feedback } = req.body;
  const teacherId = req.user!.profileId;

  const db = await getDb();
  const submission = queryOne<any>(db, `
    SELECT sub.*, a.total_marks, a.title as assignment_title, a.teacher_id, st.user_id, st.name as student_name
    FROM submissions sub
    JOIN assignments a ON sub.assignment_id = a.assignment_id
    JOIN students st ON sub.student_id = st.student_id
    WHERE sub.submission_id = ? AND a.teacher_id = ?
  `, [submissionId, teacherId]);

  if (!submission) {
    return res.status(404).json({ error: 'Submission not found or unauthorized.' });
  }

  const numMarks = Number(marks);
  if (isNaN(numMarks) || numMarks < 0 || numMarks > submission.total_marks) {
    return res.status(400).json({ error: `Marks must be between 0 and ${submission.total_marks}.` });
  }

  execute(db, `
    UPDATE submissions
    SET marks = ?, feedback = ?, status = 'Graded', graded_at = datetime('now'), graded_by = ?
    WHERE submission_id = ?
  `, [numMarks, feedback || '', req.user!.name, submissionId]);

  // Send notification to student
  execute(db, `
    INSERT INTO notifications (recipient_user_id, title, message, type, creation_date, is_read)
    VALUES (?, ?, ?, 'grade', datetime('now'), 0)
  `, [
    submission.user_id,
    `Evaluated: ${submission.assignment_title}`,
    `Your assignment was graded by ${req.user!.name}: ${numMarks}/${submission.total_marks}. Feedback: "${feedback || 'Good work'}"`
  ]);

  execute(db, `
    INSERT INTO activity_logs (action, actor_name, actor_role, timestamp, details, record_ref)
    VALUES ('SUBMISSION_GRADED', ?, 'teacher', datetime('now'), ?, ?)
  `, [req.user!.name, `Graded ${submission.student_name}'s submission for ${submission.assignment_title}`, submissionId]);

  return res.json({ message: 'Submission evaluated and returned to student.' });
});

// ----------------------------------------------------
// CSV Reports Export
// ----------------------------------------------------
router.get('/reports/csv', async (req: Request, res: Response) => {
  const { type, subjectId } = req.query;
  const teacherId = req.user!.profileId;
  const db = await getDb();

  if (type === 'students') {
    const students = queryAll<any>(db, `
      SELECT DISTINCT st.student_id, st.name, st.email, st.class, st.phone, st.guardian_name, st.account_status
      FROM students st
      JOIN enrolments e ON st.student_id = e.student_id
      JOIN subjects s ON e.subject_id = s.subject_id
      WHERE s.teacher_id = ?
      ORDER BY st.name ASC
    `, [teacherId]);

    let csv = 'Student ID,Name,Email,Class,Phone,Guardian Name,Status\n';
    students.forEach(s => {
      csv += `"${s.student_id}","${s.name}","${s.email}","${s.class}","${s.phone || ''}","${s.guardian_name || ''}","${s.account_status}"\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="edunexa_students.csv"');
    return res.send(csv);
  }

  if (type === 'grades') {
    const grades = queryAll<any>(db, `
      SELECT st.student_id, st.name, st.class, s.subject_name, asm.assessment_name, asm.maximum_marks,
             g.obtained_marks, g.calculated_percentage, g.grade, g.teacher_remarks
      FROM grades g
      JOIN assessments asm ON g.assessment_id = asm.assessment_id
      JOIN subjects s ON asm.subject_id = s.subject_id
      JOIN students st ON g.student_id = st.student_id
      WHERE s.teacher_id = ?
      ORDER BY s.subject_name, asm.assessment_name, st.name
    `, [teacherId]);

    let csv = 'Student ID,Student Name,Class,Subject,Assessment,Max Marks,Obtained Marks,Percentage,Grade,Remarks\n';
    grades.forEach(g => {
      csv += `"${g.student_id}","${g.name}","${g.class}","${g.subject_name}","${g.assessment_name}",${g.maximum_marks},${g.obtained_marks},${g.calculated_percentage},"${g.grade}","${g.teacher_remarks || ''}"\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="edunexa_grades_report.csv"');
    return res.send(csv);
  }

  if (type === 'attendance') {
    const attendance = queryAll<any>(db, `
      SELECT a.date, a.session_name, s.subject_name, st.student_id, st.name, st.class, a.status, a.remarks
      FROM attendance a
      JOIN subjects s ON a.subject_id = s.subject_id
      JOIN students st ON a.student_id = st.student_id
      WHERE s.teacher_id = ?
      ORDER BY a.date DESC, st.name ASC
    `, [teacherId]);

    let csv = 'Date,Session,Subject,Student ID,Student Name,Class,Status,Remarks\n';
    attendance.forEach(a => {
      csv += `"${a.date}","${a.session_name}","${a.subject_name}","${a.student_id}","${a.name}","${a.class}","${a.status}","${a.remarks || ''}"\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="edunexa_attendance_report.csv"');
    return res.send(csv);
  }

  return res.status(400).json({ error: 'Valid report type is required (students, grades, attendance).' });
});

export default router;
