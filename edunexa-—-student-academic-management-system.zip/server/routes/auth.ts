import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { getDb, queryOne, execute } from '../db.js';
import { generateToken, authenticate, AuthUser } from '../auth.js';

const router = Router();

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const db = await getDb();
  const cleanUsername = String(username).trim().toLowerCase();

  const userRecord = queryOne<{
    id: number;
    user_id: string;
    username: string;
    password_hash: string;
    role: 'teacher' | 'student';
    account_status: string;
  }>(db, 'SELECT * FROM users WHERE LOWER(username) = ?', [cleanUsername]);

  if (!userRecord) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  if (userRecord.account_status !== 'active') {
    return res.status(403).json({ error: 'This account has been deactivated. Contact administration.' });
  }

  const isPasswordValid = bcrypt.compareSync(password, userRecord.password_hash);
  if (!isPasswordValid) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  let profileId = '';
  let name = '';
  let email = '';
  let details: any = {};

  if (userRecord.role === 'teacher') {
    const teacher = queryOne<any>(db, 'SELECT * FROM teachers WHERE user_id = ?', [userRecord.user_id]);
    if (teacher) {
      profileId = teacher.teacher_id;
      name = teacher.name;
      email = teacher.email;
      details = {
        department: teacher.department,
        designation: teacher.designation,
        qualification: teacher.qualification
      };
    }
  } else {
    const student = queryOne<any>(db, 'SELECT * FROM students WHERE user_id = ?', [userRecord.user_id]);
    if (student) {
      profileId = student.student_id;
      name = student.name;
      email = student.email;
      details = {
        class: student.class,
        enrollment_date: student.enrollment_date,
        phone: student.phone
      };
    }
  }

  const authUser: AuthUser = {
    userId: userRecord.user_id,
    username: userRecord.username,
    role: userRecord.role,
    profileId,
    name: name || userRecord.username,
    email
  };

  const token = generateToken(authUser);

  // Set HTTP-only cookie for web browsers
  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000
  });

  return res.json({
    message: 'Login successful',
    token,
    user: {
      ...authUser,
      details
    }
  });
});

// POST /api/auth/logout
router.post('/logout', (req: Request, res: Response) => {
  res.clearCookie('token');
  return res.json({ message: 'Logged out successfully' });
});

// GET /api/auth/me
router.get('/me', authenticate, async (req: Request, res: Response) => {
  const db = await getDb();
  const user = req.user!;

  if (user.role === 'teacher') {
    const teacher = queryOne<any>(db, 'SELECT * FROM teachers WHERE teacher_id = ?', [user.profileId]);
    return res.json({
      user: {
        ...user,
        details: teacher
      }
    });
  } else {
    const student = queryOne<any>(db, 'SELECT * FROM students WHERE student_id = ?', [user.profileId]);
    return res.json({
      user: {
        ...user,
        details: student
      }
    });
  }
});

// POST /api/auth/change-password
router.post('/change-password', authenticate, async (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Current and new password are required.' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
  }

  const db = await getDb();
  const user = queryOne<any>(db, 'SELECT * FROM users WHERE user_id = ?', [req.user!.userId]);
  if (!user) {
    return res.status(404).json({ error: 'User record not found.' });
  }

  const matches = bcrypt.compareSync(currentPassword, user.password_hash);
  if (!matches) {
    return res.status(400).json({ error: 'Current password is incorrect.' });
  }

  const newHash = bcrypt.hashSync(newPassword, 10);
  execute(db, 'UPDATE users SET password_hash = ? WHERE user_id = ?', [newHash, req.user!.userId]);

  return res.json({ message: 'Password changed successfully.' });
});

// GET /api/auth/demo-accounts
// For seamless demonstration in college evaluations
router.get('/demo-accounts', async (req: Request, res: Response) => {
  const db = await getDb();
  const teachers = queryOne<any>(db, 'SELECT teacher_id, name, email FROM teachers LIMIT 3');
  return res.json({
    teachers: [
      { username: 'prof.turing', name: 'Prof. Alan Turing', role: 'teacher', department: 'Computer Science', defaultPassword: 'Teacher@123' },
      { username: 'dr.franklin', name: 'Dr. Rosalind Franklin', role: 'teacher', department: 'Chemistry & Biology', defaultPassword: 'Teacher@123' },
      { username: 'prof.feynman', name: 'Prof. Richard Feynman', role: 'teacher', department: 'Physics', defaultPassword: 'Teacher@123' }
    ],
    students: [
      { username: 'liam.davis', studentId: 'STU-2026-001', name: 'Liam Davis', class: 'Year 1 - Class A', defaultPassword: 'Student@123' },
      { username: 'sophia.chen', studentId: 'STU-2026-002', name: 'Sophia Chen', class: 'Year 1 - Class A', defaultPassword: 'Student@123' },
      { username: 'jackson.martinez', studentId: 'STU-2026-005', name: 'Jackson Martinez', class: 'Year 1 - Class A', defaultPassword: 'Student@123' },
      { username: 'harper.garcia', studentId: 'STU-2026-014', name: 'Harper Garcia', class: 'Year 1 - Class B', defaultPassword: 'Student@123' }
    ]
  });
});

export default router;
