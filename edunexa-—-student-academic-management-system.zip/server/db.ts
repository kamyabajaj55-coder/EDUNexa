import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'edunexa.sqlite');

let dbInstance: Database | null = null;

export async function getDb(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  const SQL = await initSqlJs();

  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      dbInstance = new SQL.Database(fileBuffer);
      console.log('[EduNexa Database] Loaded existing database from', DB_FILE);
    } catch (err) {
      console.error('[EduNexa Database] Failed to load existing file, creating fresh DB:', err);
      dbInstance = new SQL.Database();
    }
  } else {
    console.log('[EduNexa Database] Initializing fresh database file at', DB_FILE);
    dbInstance = new SQL.Database();
  }

  initSchema(dbInstance);
  saveDb();
  return dbInstance;
}

export function saveDb(): void {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('[EduNexa Database] Error persisting database to disk:', err);
  }
}

function initSchema(db: Database) {
  db.run(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT UNIQUE NOT NULL,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('teacher', 'student')),
      account_status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS teachers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id TEXT UNIQUE NOT NULL,
      user_id TEXT UNIQUE NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      department TEXT NOT NULL,
      designation TEXT,
      qualification TEXT,
      bio TEXT
    );

    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT UNIQUE NOT NULL,
      user_id TEXT UNIQUE NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      class TEXT NOT NULL,
      enrollment_date TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      guardian_name TEXT,
      guardian_phone TEXT,
      bio TEXT,
      account_status TEXT NOT NULL DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id TEXT UNIQUE NOT NULL,
      subject_name TEXT NOT NULL,
      subject_code TEXT UNIQUE NOT NULL,
      maximum_marks INTEGER NOT NULL DEFAULT 100,
      teacher_id TEXT NOT NULL REFERENCES teachers(teacher_id),
      class TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS enrolments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
      subject_id TEXT NOT NULL REFERENCES subjects(subject_id) ON DELETE CASCADE,
      class TEXT NOT NULL,
      academic_session TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'enrolled',
      UNIQUE(student_id, subject_id)
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
      subject_id TEXT NOT NULL REFERENCES subjects(subject_id) ON DELETE CASCADE,
      class TEXT NOT NULL,
      date TEXT NOT NULL,
      session_name TEXT NOT NULL DEFAULT 'Morning Session',
      status TEXT NOT NULL CHECK(status IN ('Present', 'Absent', 'Late', 'Excused')),
      recorded_by_teacher_id TEXT NOT NULL,
      remarks TEXT,
      UNIQUE(student_id, subject_id, date, session_name)
    );

    CREATE TABLE IF NOT EXISTS assessments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assessment_id TEXT UNIQUE NOT NULL,
      assessment_name TEXT NOT NULL,
      subject_id TEXT NOT NULL REFERENCES subjects(subject_id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      maximum_marks REAL NOT NULL DEFAULT 100,
      weightage REAL NOT NULL DEFAULT 20,
      term TEXT NOT NULL DEFAULT 'Fall 2026'
    );

    CREATE TABLE IF NOT EXISTS grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
      assessment_id TEXT NOT NULL REFERENCES assessments(assessment_id) ON DELETE CASCADE,
      obtained_marks REAL NOT NULL,
      calculated_percentage REAL NOT NULL,
      grade TEXT NOT NULL,
      teacher_remarks TEXT,
      updated_at TEXT NOT NULL,
      UNIQUE(student_id, assessment_id)
    );

    CREATE TABLE IF NOT EXISTS assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assignment_id TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      subject_id TEXT NOT NULL REFERENCES subjects(subject_id) ON DELETE CASCADE,
      teacher_id TEXT NOT NULL REFERENCES teachers(teacher_id),
      creation_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      total_marks REAL NOT NULL DEFAULT 100,
      publication_status TEXT NOT NULL CHECK(publication_status IN ('draft', 'published', 'archived')) DEFAULT 'published'
    );

    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      submission_id TEXT UNIQUE NOT NULL,
      assignment_id TEXT NOT NULL REFERENCES assignments(assignment_id) ON DELETE CASCADE,
      student_id TEXT NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
      submission_date TEXT NOT NULL,
      answer_text TEXT,
      file_name TEXT,
      file_url TEXT,
      status TEXT NOT NULL CHECK(status IN ('Submitted', 'Late', 'Graded', 'Pending')) DEFAULT 'Submitted',
      marks REAL,
      feedback TEXT,
      graded_at TEXT,
      graded_by TEXT,
      UNIQUE(assignment_id, student_id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      recipient_user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info',
      creation_date TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      details TEXT,
      record_ref TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
    CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);
    CREATE INDEX IF NOT EXISTS idx_grades_student ON grades(student_id);
    CREATE INDEX IF NOT EXISTS idx_submissions_assign ON submissions(assignment_id);
    CREATE INDEX IF NOT EXISTS idx_submissions_student ON submissions(student_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_user_id);
  `);
}

/**
 * Helper to query multiple rows and map to objects with column names
 */
export function queryAll<T = any>(db: Database, sql: string, params: any[] = []): T[] {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as unknown as T);
  }
  stmt.free();
  return rows;
}

/**
 * Helper to query a single row
 */
export function queryOne<T = any>(db: Database, sql: string, params: any[] = []): T | null {
  const rows = queryAll<T>(db, sql, params);
  return rows.length > 0 ? rows[0] : null;
}

/**
 * Helper to run DML / write statements and auto-save
 */
export function execute(db: Database, sql: string, params: any[] = []): void {
  db.run(sql, params);
  saveDb();
}
