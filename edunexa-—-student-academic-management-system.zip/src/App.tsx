import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { LoginPage } from './components/LoginPage';
import { DemoSwitcherModal } from './components/DemoSwitcherModal';
import { PasswordModal } from './components/PasswordModal';

// Teacher components
import { TeacherOverview } from './components/TeacherDashboard/TeacherOverview';
import { StudentDirectory } from './components/TeacherDashboard/StudentDirectory';
import { AttendanceManager } from './components/TeacherDashboard/AttendanceManager';
import { MarksManager } from './components/TeacherDashboard/MarksManager';
import { AssignmentManager } from './components/TeacherDashboard/AssignmentManager';
import { ReportsView } from './components/TeacherDashboard/ReportsView';
import { StudentFileModal } from './components/TeacherDashboard/StudentFileModal';

// Student components
import { StudentOverview } from './components/StudentDashboard/StudentOverview';
import { StudentAttendance } from './components/StudentDashboard/StudentAttendance';
import { StudentGrades } from './components/StudentDashboard/StudentGrades';
import { StudentAssignments } from './components/StudentDashboard/StudentAssignments';
import { StudentProfile } from './components/StudentDashboard/StudentProfile';

// Bento & Voice Orb showcase components
import { BentoView } from './components/BentoView';
import { VoiceOrbView } from './components/VoiceOrbView';

import { apiFetch } from './api';
import { Subject, Assignment } from './types';
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  Award,
  BookOpen,
  FileSpreadsheet,
  User,
  GraduationCap,
  Sparkles,
  BarChart3
} from 'lucide-react';

function EduNexaApp() {
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isDemoModalOpen, setIsDemoModalOpen] = useState<boolean>(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState<boolean>(false);

  // Selected student for detail file modal (Teacher view)
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);

  // Teacher data state
  const [teacherStats, setTeacherStats] = useState<any>(null);
  const [teacherSubjects, setTeacherSubjects] = useState<Subject[]>([]);

  // Student data state
  const [studentGradesData, setStudentGradesData] = useState<any>(null);
  const [studentAttendanceData, setStudentAttendanceData] = useState<any>(null);
  const [studentAssignments, setStudentAssignments] = useState<Assignment[]>([]);

  // Fetch teacher data
  const loadTeacherData = async () => {
    if (!user || user.role !== 'teacher') return;
    const [statsRes, subsRes] = await Promise.all([
      apiFetch('/api/teacher/dashboard-stats'),
      apiFetch<{ subjects: Subject[] }>('/api/teacher/subjects')
    ]);
    if (statsRes.data) setTeacherStats(statsRes.data);
    if (subsRes.data) setTeacherSubjects(subsRes.data.subjects || []);
  };

  // Fetch student data
  const loadStudentData = async () => {
    if (!user || user.role !== 'student') return;
    const [gradesRes, attRes, asnsRes] = await Promise.all([
      apiFetch('/api/student/grades'),
      apiFetch('/api/student/attendance'),
      apiFetch<{ assignments: Assignment[] }>('/api/student/assignments')
    ]);
    if (gradesRes.data) setStudentGradesData(gradesRes.data);
    if (attRes.data) setStudentAttendanceData(attRes.data);
    if (asnsRes.data) setStudentAssignments(asnsRes.data.assignments || []);
  };

  useEffect(() => {
    if (user) {
      if (user.role === 'teacher') {
        setActiveTab('overview');
        loadTeacherData();
      } else {
        setActiveTab('dashboard');
        loadStudentData();
      }
    }
  }, [user]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-white space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center animate-spin">
          <GraduationCap className="w-6 h-6" />
        </div>
        <p className="text-xs text-slate-400 font-mono">Initializing EduNexa Academic System...</p>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  // Teacher Navigation Tabs
  const teacherNav = [
    { id: 'overview', label: 'Overview & Analytics', icon: LayoutDashboard },
    { id: 'students', label: 'Student Directory', icon: Users },
    { id: 'attendance', label: 'Attendance Management', icon: CalendarCheck },
    { id: 'marks', label: 'Marks & Gradebook', icon: Award },
    { id: 'assignments', label: 'Course Assignments', icon: BookOpen },
    { id: 'reports', label: 'Reports & Export', icon: FileSpreadsheet },
  ];

  // Student Navigation Tabs
  const studentNav = [
    { id: 'dashboard', label: 'My Academic Dashboard', icon: LayoutDashboard },
    { id: 'attendance', label: 'Attendance Log', icon: CalendarCheck },
    { id: 'grades', label: 'Grades & Transcript', icon: Award },
    { id: 'assignments', label: 'My Assignments', icon: BookOpen },
    { id: 'profile', label: 'Student Profile', icon: User },
  ];

  const currentTabs = user.role === 'teacher' ? teacherNav : studentNav;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Primary Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDemoSwitcher={() => setIsDemoModalOpen(true)}
        onOpenPasswordModal={() => setIsPasswordModalOpen(true)}
      />

      {/* Secondary Role Tab Navigation */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center overflow-x-auto scrollbar-none gap-2 py-2">
            {currentTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                    isActive
                      ? user.role === 'teacher'
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Bento Integration View */}
        {activeTab === 'bento' && (
          <BentoView
            onBack={() => setActiveTab(user.role === 'teacher' ? 'overview' : 'dashboard')}
          />
        )}

        {/* Voice Orb Integration View */}
        {activeTab === 'voice-orb' && (
          <VoiceOrbView
            onBack={() => setActiveTab(user.role === 'teacher' ? 'overview' : 'dashboard')}
          />
        )}

        {/* Teacher Role Views */}
        {user.role === 'teacher' && activeTab !== 'bento' && activeTab !== 'voice-orb' && (
          <>
            {activeTab === 'overview' && (
              <TeacherOverview
                stats={teacherStats}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onViewStudent={(studentId) => setSelectedStudentId(studentId)}
              />
            )}
            {activeTab === 'students' && (
              <StudentDirectory
                subjects={teacherSubjects}
                onSelectStudent={(studentId) => setSelectedStudentId(studentId)}
              />
            )}
            {activeTab === 'attendance' && (
              <AttendanceManager
                subjects={teacherSubjects}
              />
            )}
            {activeTab === 'marks' && (
              <MarksManager
                subjects={teacherSubjects}
              />
            )}
            {activeTab === 'assignments' && (
              <AssignmentManager
                subjects={teacherSubjects}
              />
            )}
            {activeTab === 'reports' && (
              <ReportsView
                subjects={teacherSubjects}
              />
            )}
          </>
        )}

        {/* Student Role Views */}
        {user.role === 'student' && activeTab !== 'bento' && activeTab !== 'voice-orb' && (
          <>
            {activeTab === 'dashboard' && (
              <StudentOverview
                gradesData={studentGradesData}
                attendanceData={studentAttendanceData}
                assignmentsData={studentAssignments}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}
            {activeTab === 'attendance' && (
              <StudentAttendance
                data={studentAttendanceData}
              />
            )}
            {activeTab === 'grades' && (
              <StudentGrades
                data={studentGradesData}
              />
            )}
            {activeTab === 'assignments' && (
              <StudentAssignments
                assignments={studentAssignments}
                onRefresh={loadStudentData}
              />
            )}
            {activeTab === 'profile' && (
              <StudentProfile
                onRefresh={loadStudentData}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">EduNexa Academic System</span>
            <span>•</span>
            <span>Connected to Persistent SQLite Relational Database</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsDemoModalOpen(true)}
              className="text-indigo-600 hover:text-indigo-800 font-semibold"
            >
              Demo Accounts
            </button>
            <button
              onClick={() => setActiveTab('voice-orb')}
              className="text-slate-600 hover:text-slate-900 font-semibold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Voice Orb</span>
            </button>
            <button
              onClick={() => setActiveTab('bento')}
              className="text-slate-600 hover:text-slate-900 font-semibold flex items-center gap-1"
            >
              <BarChart3 className="w-3.5 h-3.5 text-lime-600" />
              <span>Bento Component</span>
            </button>
            <span>College Academic Project</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <DemoSwitcherModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
      />

      <PasswordModal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
      />

      {/* Student Dossier Modal */}
      {selectedStudentId && (
        <StudentFileModal
          studentId={selectedStudentId}
          onClose={() => setSelectedStudentId(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <EduNexaApp />
    </AuthProvider>
  );
}
