import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api';
import { Subject, Assessment } from '../../types';
import {
  Award,
  Plus,
  Save,
  CheckCircle2,
  AlertTriangle,
  Info,
  Calendar,
  X,
  TrendingUp,
  BarChart2
} from 'lucide-react';

interface MarksManagerProps {
  subjects: Subject[];
}

interface StudentGradeInput {
  student_id: string;
  name: string;
  class: string;
  email: string;
  obtained_marks?: number | null;
  calculated_percentage?: number | null;
  grade?: string | null;
  teacher_remarks?: string | null;
}

export const MarksManager: React.FC<MarksManagerProps> = ({ subjects }) => {
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.subject_id || '');
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<string>('');
  const [currentAssessment, setCurrentAssessment] = useState<Assessment | null>(null);
  const [students, setStudents] = useState<StudentGradeInput[]>([]);
  const [marksState, setMarksState] = useState<Record<string, { marks: string; remarks: string }>>({});
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const [isLoadingAssessments, setIsLoadingAssessments] = useState(false);
  const [isLoadingStudents, setIsLoadingStudents] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // New Assessment Modal state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newAsmName, setNewAsmName] = useState('');
  const [newAsmMaxMarks, setNewAsmMaxMarks] = useState('100');
  const [newAsmWeightage, setNewAsmWeightage] = useState('25');
  const [newAsmDate, setNewAsmDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newAsmTerm, setNewAsmTerm] = useState('Fall 2026');

  // Fetch assessments for selected subject
  const fetchAssessments = async () => {
    if (!selectedSubjectId) return;
    setIsLoadingAssessments(true);
    const res = await apiFetch<{ assessments: Assessment[] }>(`/api/teacher/assessments?subjectId=${encodeURIComponent(selectedSubjectId)}`);
    if (res.data) {
      const list = res.data.assessments || [];
      setAssessments(list);
      if (list.length > 0) {
        setSelectedAssessmentId(list[0].assessment_id);
      } else {
        setSelectedAssessmentId('');
        setCurrentAssessment(null);
        setStudents([]);
      }
    }
    setIsLoadingAssessments(false);
  };

  useEffect(() => {
    fetchAssessments();
  }, [selectedSubjectId]);

  // Fetch student roster and existing grades for selected assessment
  const fetchMarks = async () => {
    if (!selectedAssessmentId) return;
    setIsLoadingStudents(true);
    setSaveStatus(null);
    setValidationErrors({});

    const res = await apiFetch<{
      assessment: Assessment;
      students: StudentGradeInput[];
    }>(`/api/teacher/assessments/${selectedAssessmentId}/marks`);

    if (res.data) {
      setCurrentAssessment(res.data.assessment);
      setStudents(res.data.students || []);

      const initialMap: Record<string, { marks: string; remarks: string }> = {};
      res.data.students.forEach(st => {
        initialMap[st.student_id] = {
          marks: st.obtained_marks !== null && st.obtained_marks !== undefined ? String(st.obtained_marks) : '',
          remarks: st.teacher_remarks || ''
        };
      });
      setMarksState(initialMap);
    }
    setIsLoadingStudents(false);
  };

  useEffect(() => {
    if (selectedAssessmentId) {
      fetchMarks();
    }
  }, [selectedAssessmentId]);

  // Helper grading formula
  const getGradeInfo = (obtainedStr: string, maxMarks: number) => {
    if (obtainedStr === '') return { percentage: null, grade: '—' };
    const num = parseFloat(obtainedStr);
    if (isNaN(num)) return { percentage: null, grade: 'Invalid' };
    const pct = Math.round((num / maxMarks) * 1000) / 10;
    let grade = 'F';
    if (pct >= 90) grade = 'A+';
    else if (pct >= 80) grade = 'A';
    else if (pct >= 70) grade = 'B';
    else if (pct >= 60) grade = 'C';
    else if (pct >= 50) grade = 'D';
    return { percentage: pct, grade };
  };

  const handleMarkChange = (studentId: string, val: string) => {
    setMarksState(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        marks: val
      }
    }));

    if (!currentAssessment) return;

    if (val === '') {
      setValidationErrors(prev => {
        const next = { ...prev };
        delete next[studentId];
        return next;
      });
      return;
    }

    const num = parseFloat(val);
    if (isNaN(num)) {
      setValidationErrors(prev => ({ ...prev, [studentId]: 'Must be a number' }));
    } else if (num < 0) {
      setValidationErrors(prev => ({ ...prev, [studentId]: 'Cannot be negative' }));
    } else if (num > currentAssessment.maximum_marks) {
      setValidationErrors(prev => ({
        ...prev,
        [studentId]: `Cannot exceed max (${currentAssessment.maximum_marks})`
      }));
    } else {
      setValidationErrors(prev => {
        const next = { ...prev };
        delete next[studentId];
        return next;
      });
    }
  };

  const handleRemarksChange = (studentId: string, val: string) => {
    setMarksState(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        remarks: val
      }
    }));
  };

  const handleSaveMarks = async () => {
    if (Object.keys(validationErrors).length > 0) {
      setSaveStatus({ type: 'error', message: 'Please resolve invalid mark errors before saving.' });
      return;
    }

    setIsSaving(true);
    setSaveStatus(null);

    const marksPayload = Object.entries(marksState).map(([studentId, val]) => ({
      studentId,
      obtainedMarks: val.marks !== '' ? parseFloat(val.marks) : null,
      remarks: val.remarks
    }));

    const res = await apiFetch(`/api/teacher/assessments/${selectedAssessmentId}/marks`, {
      method: 'POST',
      body: JSON.stringify({ marks: marksPayload })
    });

    setIsSaving(false);
    if (res.error) {
      setSaveStatus({ type: 'error', message: res.error });
    } else {
      setSaveStatus({ type: 'success', message: 'Marks, percentages, and letter grades calculated and saved.' });
      fetchMarks();
      setTimeout(() => setSaveStatus(null), 4000);
    }
  };

  const handleCreateAssessment = async (e: React.FormEvent) => {
    e.preventDefault();
    const maxM = parseFloat(newAsmMaxMarks);
    if (isNaN(maxM) || maxM <= 0) {
      alert('Maximum marks must be greater than 0.');
      return;
    }

    const res = await apiFetch('/api/teacher/assessments', {
      method: 'POST',
      body: JSON.stringify({
        assessmentName: newAsmName,
        subjectId: selectedSubjectId,
        date: newAsmDate,
        maximumMarks: maxM,
        weightage: parseFloat(newAsmWeightage) || 20,
        term: newAsmTerm
      })
    });

    if (res.error) {
      alert(res.error);
    } else {
      setIsCreateModalOpen(false);
      setNewAsmName('');
      await fetchAssessments();
    }
  };

  // Live Statistics Calculations
  const maxMarks = currentAssessment?.maximum_marks || 100;
  let enteredCount = 0;
  let totalScore = 0;
  let highestScore = 0;
  let lowestScore = maxMarks;

  students.forEach(st => {
    const entered = marksState[st.student_id]?.marks;
    if (entered !== undefined && entered !== '') {
      const num = parseFloat(entered);
      if (!isNaN(num) && num >= 0 && num <= maxMarks) {
        enteredCount++;
        totalScore += num;
        if (num > highestScore) highestScore = num;
        if (num < lowestScore) lowestScore = num;
      }
    }
  });

  const classAverage = enteredCount > 0 ? Math.round((totalScore / enteredCount) * 10) / 10 : 0;
  const classAvgPercentage = Math.round((classAverage / maxMarks) * 1000) / 10;

  return (
    <div className="space-y-6">
      {/* Configuration & Selection Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-600" />
              Academic Marks & Gradebook Entry
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter assessment marks, validate numeric thresholds, and compute letter grades
            </p>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl text-xs font-bold transition-colors shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>New Examination / Assessment</span>
          </button>
        </div>

        {/* Dropdowns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Select Course Subject
            </label>
            <select
              value={selectedSubjectId}
              onChange={e => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500"
            >
              {subjects.map(s => (
                <option key={s.subject_id} value={s.subject_id}>
                  {s.subject_code} - {s.subject_name} ({s.class})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Select Assessment
            </label>
            <select
              value={selectedAssessmentId}
              onChange={e => setSelectedAssessmentId(e.target.value)}
              disabled={assessments.length === 0}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              {assessments.length === 0 ? (
                <option value="">No assessments created for this course</option>
              ) : (
                assessments.map(a => (
                  <option key={a.assessment_id} value={a.assessment_id}>
                    {a.assessment_name} (Max {a.maximum_marks} pts · {a.date})
                  </option>
                ))
              )}
            </select>
          </div>
        </div>

        {/* Statistics Bar for Selected Assessment */}
        {currentAssessment && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Max Points</span>
              <p className="text-lg font-mono font-extrabold text-slate-900 mt-0.5">{currentAssessment.maximum_marks}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Class Average</span>
              <p className="text-lg font-mono font-extrabold text-indigo-700 mt-0.5">
                {classAverage} <span className="text-xs font-semibold text-slate-500">({classAvgPercentage}%)</span>
              </p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Highest Score</span>
              <p className="text-lg font-mono font-extrabold text-emerald-600 mt-0.5">{enteredCount > 0 ? highestScore : '—'}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Evaluated Count</span>
              <p className="text-lg font-mono font-extrabold text-slate-800 mt-0.5">
                {enteredCount} / {students.length}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Save Notification */}
      {saveStatus && (
        <div className={`p-4 rounded-xl text-xs font-medium flex items-center gap-2 ${
          saveStatus.type === 'success'
            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            : 'bg-rose-50 text-rose-800 border border-rose-200'
        }`}>
          {saveStatus.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{saveStatus.message}</span>
        </div>
      )}

      {/* Marks Entry Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 text-sm">
              Gradebook Matrix: {currentAssessment?.assessment_name || 'Assessment'}
            </h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
              {students.length} students
            </span>
          </div>

          <button
            onClick={handleSaveMarks}
            disabled={isSaving || students.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs disabled:opacity-50 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Calculating...' : 'Save & Calculate Grades'}</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                <th className="py-3 px-6">Student ID</th>
                <th className="py-3 px-6">Student Name</th>
                <th className="py-3 px-6 w-36">
                  Marks Obtained (/{maxMarks})
                </th>
                <th className="py-3 px-6">Percentage</th>
                <th className="py-3 px-6">Letter Grade</th>
                <th className="py-3 px-6">Teacher Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {isLoadingStudents ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Loading student grade records...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    No assessments or students found.
                  </td>
                </tr>
              ) : (
                students.map(st => {
                  const currentVal = marksState[st.student_id]?.marks ?? '';
                  const currentRemarks = marksState[st.student_id]?.remarks ?? '';
                  const error = validationErrors[st.student_id];
                  const { percentage, grade } = getGradeInfo(currentVal, maxMarks);

                  return (
                    <tr key={st.student_id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-6 font-mono font-bold text-slate-800">
                        {st.student_id}
                      </td>

                      <td className="py-3 px-6">
                        <span className="font-bold text-slate-900 block">{st.name}</span>
                        <span className="text-[11px] text-slate-400">{st.class}</span>
                      </td>

                      <td className="py-3 px-6">
                        <div className="relative">
                          <input
                            type="number"
                            step="0.5"
                            min="0"
                            max={maxMarks}
                            value={currentVal}
                            onChange={e => handleMarkChange(st.student_id, e.target.value)}
                            placeholder="0.0"
                            className={`w-28 px-3 py-1.5 border rounded-lg text-xs font-mono font-bold focus:outline-hidden ${
                              error
                                ? 'border-rose-500 bg-rose-50 text-rose-900 focus:ring-2 focus:ring-rose-500'
                                : 'border-slate-300 focus:ring-2 focus:ring-indigo-500'
                            }`}
                          />
                          {error && (
                            <span className="block text-[10px] font-bold text-rose-600 mt-0.5">
                              {error}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-6 font-mono font-bold text-slate-800">
                        {percentage !== null ? `${percentage}%` : '—'}
                      </td>

                      <td className="py-3 px-6">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-extrabold ${
                          grade === 'A+' || grade === 'A'
                            ? 'bg-emerald-100 text-emerald-800'
                            : grade === 'B'
                            ? 'bg-indigo-100 text-indigo-800'
                            : grade === 'C'
                            ? 'bg-amber-100 text-amber-800'
                            : grade === 'D'
                            ? 'bg-orange-100 text-orange-800'
                            : grade === 'F'
                            ? 'bg-rose-100 text-rose-800'
                            : 'text-slate-400'
                        }`}>
                          {grade}
                        </span>
                      </td>

                      <td className="py-3 px-6">
                        <input
                          type="text"
                          value={currentRemarks}
                          onChange={e => handleRemarksChange(st.student_id, e.target.value)}
                          placeholder="Teacher feedback / remarks..."
                          className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <Info className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>Grading Scale: A+ (≥90%), A (≥80%), B (≥70%), C (≥60%), D (≥50%), F (&lt;50%)</span>
          </div>
          <button
            onClick={handleSaveMarks}
            disabled={isSaving || students.length === 0}
            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors"
          >
            {isSaving ? 'Saving...' : 'Save Gradebook'}
          </button>
        </div>
      </div>

      {/* Create New Assessment Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">Create New Assessment</h3>
              </div>
              <button onClick={() => setIsCreateModalOpen(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAssessment} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Assessment Name *</label>
                <input
                  type="text"
                  required
                  value={newAsmName}
                  onChange={e => setNewAsmName(e.target.value)}
                  placeholder="e.g. End-Term Comprehensive Exam"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Max Marks *</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={newAsmMaxMarks}
                    onChange={e => setNewAsmMaxMarks(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Weightage (%)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="100"
                    value={newAsmWeightage}
                    onChange={e => setNewAsmWeightage(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={newAsmDate}
                    onChange={e => setNewAsmDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Term</label>
                  <input
                    type="text"
                    value={newAsmTerm}
                    onChange={e => setNewAsmTerm(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Create Assessment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
