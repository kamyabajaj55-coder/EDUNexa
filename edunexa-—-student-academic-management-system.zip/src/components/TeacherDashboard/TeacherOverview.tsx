import React from 'react';
import {
  Users,
  CheckCircle2,
  GraduationCap,
  Clock,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  FileCheck,
  CalendarCheck,
  Award
} from 'lucide-react';

interface TeacherOverviewProps {
  stats: any;
  onNavigateTab: (tab: string, filterData?: any) => void;
  onViewStudent: (studentId: string) => void;
}

export const TeacherOverview: React.FC<TeacherOverviewProps> = ({
  stats,
  onNavigateTab,
  onViewStudent
}) => {
  if (!stats) return null;

  const {
    totalStudents = 0,
    overallAttendance = 0,
    subjectAverages = [],
    attentionStudents = [],
    pendingSubmissionsCount = 0,
    attendanceTrend = [],
    recentActivity = []
  } = stats;

  return (
    <div className="space-y-6">
      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Assigned Students</p>
            <h3 className="text-3xl font-extrabold text-slate-900 mt-1">{totalStudents}</h3>
            <p className="text-xs text-indigo-600 font-semibold mt-1">Across all assigned courses</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Average Attendance</p>
            <h3 className="text-3xl font-extrabold text-slate-900 mt-1">{overallAttendance}%</h3>
            <p className={`text-xs font-semibold mt-1 ${overallAttendance >= 75 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {overallAttendance >= 75 ? 'Meets institutional policy' : 'Below 75% threshold'}
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <CalendarCheck className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Pending Evaluations</p>
            <h3 className="text-3xl font-extrabold text-slate-900 mt-1">{pendingSubmissionsCount}</h3>
            <button
              onClick={() => onNavigateTab('assignments')}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold mt-1 flex items-center gap-1"
            >
              Grade submissions <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Academic Attention</p>
            <h3 className="text-3xl font-extrabold text-rose-600 mt-1">{attentionStudents.length}</h3>
            <p className="text-xs text-rose-500 font-semibold mt-1">Requires intervention</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Grid: Attendance Trend & Subject Averages */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Trend Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" />
                Attendance Trend (Past 30 Days)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Classroom presence calculated dynamically from database sessions
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg">
              Threshold: 75%
            </span>
          </div>

          {attendanceTrend.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-xs text-slate-400">
              No attendance records recorded yet.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="h-44 flex items-end gap-1.5 pt-6 pb-2 px-2 border-b border-slate-100 overflow-x-auto">
                {attendanceTrend.map((t: any, idx: number) => {
                  const pct = Math.min(100, Math.max(0, t.percentage));
                  const isLow = pct < 75;
                  return (
                    <div
                      key={idx}
                      className="flex-1 min-w-[18px] flex flex-col items-center group relative cursor-pointer"
                    >
                      <div
                        style={{ height: `${pct}%` }}
                        className={`w-full rounded-t-sm transition-all group-hover:opacity-80 ${
                          isLow ? 'bg-rose-400 group-hover:bg-rose-500' : 'bg-indigo-500 group-hover:bg-indigo-600'
                        }`}
                      />
                      {/* Tooltip on hover */}
                      <div className="absolute bottom-full mb-2 hidden group-hover:block z-20 bg-slate-900 text-white text-[10px] rounded px-2 py-1 shadow-md whitespace-nowrap pointer-events-none">
                        <span className="font-bold">{t.date}</span>: {pct}%
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono px-2">
                <span>{attendanceTrend[0]?.date}</span>
                <span className="font-sans font-medium text-slate-500 flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 bg-indigo-500 rounded-xs inline-block" /> ≥75% Compliant
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 bg-rose-400 rounded-xs inline-block" /> &lt;75% Alert
                  </span>
                </span>
                <span>{attendanceTrend[attendanceTrend.length - 1]?.date}</span>
              </div>
            </div>
          )}
        </div>

        {/* Subject Performance & Averages */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2 mb-4">
              <Award className="w-5 h-5 text-indigo-600" />
              Course Grade Averages
            </h3>
            <div className="space-y-4">
              {subjectAverages.map((sub: any) => {
                const avg = sub.avg_percentage || 0;
                return (
                  <div key={sub.subject_id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-800">{sub.subject_code}</span>
                      <span className="font-extrabold text-slate-900 font-mono">{avg}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          avg >= 80 ? 'bg-emerald-500' : avg >= 65 ? 'bg-indigo-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${Math.min(100, avg)}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span className="truncate max-w-[180px]">{sub.subject_name}</span>
                      <span>{sub.graded_students} students evaluated</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => onNavigateTab('attendance')}
              className="px-3 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-semibold transition-colors"
            >
              Take Attendance
            </button>
            <button
              onClick={() => onNavigateTab('marks')}
              className="px-3 py-1.5 bg-slate-900 text-white hover:bg-slate-800 rounded-lg text-xs font-semibold transition-colors"
            >
              Enter Marks
            </button>
          </div>
        </div>
      </div>

      {/* Attention List & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Students Requiring Academic Attention */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-rose-100 text-rose-700 rounded-lg">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-base text-slate-900">Academic Attention Alerts</h3>
            </div>
            <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
              {attentionStudents.length} Students
            </span>
          </div>

          {attentionStudents.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No students are currently falling below attendance or marks benchmarks.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {attentionStudents.map((st: any) => (
                <div key={st.student_id} className="py-3 flex items-center justify-between hover:bg-slate-50 px-2 rounded-lg transition-colors">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">{st.name}</span>
                      <span className="font-mono text-xs text-slate-400 font-semibold">{st.student_id}</span>
                      <span className="text-[11px] text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded font-medium">
                        {st.class}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      {st.issues.map((issue: string, i: number) => (
                        <span key={i} className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200/60">
                          {issue}
                        </span>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => onViewStudent(st.student_id)}
                    className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 rounded-lg flex items-center gap-1 transition-colors"
                  >
                    View File <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Activity Log */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-slate-500" />
              Recent Academic Activity
            </h3>
            <span className="text-xs text-slate-400">Audit trail</span>
          </div>

          <div className="space-y-3 max-h-72 overflow-y-auto">
            {recentActivity.map((log: any) => (
              <div key={log.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-800">{log.action.replace(/_/g, ' ')}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{log.timestamp.slice(0, 16)}</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{log.details}</p>
                  <span className="text-[10px] text-slate-400 mt-1 block">Actor: {log.actor_name} ({log.actor_role})</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
