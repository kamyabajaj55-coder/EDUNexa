import React from 'react';
import { Subject } from '../../types';
import {
  FileSpreadsheet,
  Download,
  FileText,
  Calculator,
  ShieldCheck,
  CheckCircle2,
  Info
} from 'lucide-react';

interface ReportsViewProps {
  subjects: Subject[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ subjects }) => {
  const handleDownload = (type: string) => {
    const token = localStorage.getItem('edunexa_token');
    // Direct link with authorization cookie or direct stream
    window.location.href = `/api/teacher/reports/csv?type=${type}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
          Academic Reports & Database Exports
        </h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Generate live CSV spreadsheets and verify documented institutional calculation formulas
        </p>
      </div>

      {/* Export Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Student Roster Export */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900">Student Master Directory</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export complete student profiles including IDs, enrolled classes, contact information, and guardian details.
            </p>
          </div>
          <button
            onClick={() => handleDownload('students')}
            className="w-full py-2.5 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download Students CSV</span>
          </button>
        </div>

        {/* Gradebook Export */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900">Official Gradebook Report</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export subject-wise exam scores, calculated percentages, letter grades (A+ to F), and written teacher remarks.
            </p>
          </div>
          <button
            onClick={() => handleDownload('grades')}
            className="w-full py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download Gradebook CSV</span>
          </button>
        </div>

        {/* Attendance Export */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900">Attendance Session Logs</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export full chronological 30-day attendance history with session timestamps, status codes, and absence reasons.
            </p>
          </div>
          <button
            onClick={() => handleDownload('attendance')}
            className="w-full py-2.5 px-3 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download Attendance CSV</span>
          </button>
        </div>
      </div>

      {/* Formula Documentation Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Calculator className="w-5 h-5 text-indigo-600" />
          <h4 className="font-bold text-base text-slate-900">Documented Academic Calculation Rules</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-600 leading-relaxed">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
            <div className="flex items-center gap-2 text-indigo-900 font-bold">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Attendance Calculation Formula</span>
            </div>
            <p>
              In EduNexa, attendance percentage is calculated using the institutional formula:
            </p>
            <div className="p-2.5 bg-white font-mono font-bold text-indigo-800 rounded border border-indigo-100 text-[11px]">
              Percentage = ((Present + (Late × 0.5)) / (Total Sessions - Excused)) × 100
            </div>
            <p className="text-slate-500 text-[11px]">
              • <strong>Excused:</strong> Medical/formal leaves are excluded from the denominator.
              <br />
              • <strong>Threshold Warning:</strong> Any student with attendance below 75% receives an automatic system warning flag.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
            <div className="flex items-center gap-2 text-emerald-900 font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Assessment & Grade Thresholds</span>
            </div>
            <p>
              Percentage and grade calculation uses uniform linear thresholding:
            </p>
            <div className="p-2.5 bg-white font-mono font-bold text-emerald-800 rounded border border-emerald-100 text-[11px]">
              Assessment % = (Marks Obtained / Maximum Marks) × 100
            </div>
            <div className="grid grid-cols-3 gap-1 pt-1 text-[11px] font-mono">
              <span className="p-1 bg-white rounded border border-slate-200">A+ : ≥ 90%</span>
              <span className="p-1 bg-white rounded border border-slate-200">A : ≥ 80%</span>
              <span className="p-1 bg-white rounded border border-slate-200">B : ≥ 70%</span>
              <span className="p-1 bg-white rounded border border-slate-200">C : ≥ 60%</span>
              <span className="p-1 bg-white rounded border border-slate-200">D : ≥ 50%</span>
              <span className="p-1 bg-white rounded border border-slate-200">F : &lt; 50%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
