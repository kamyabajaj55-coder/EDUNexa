import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api';
import { Student, Subject } from '../../types';
import {
  Search,
  Filter,
  Plus,
  Eye,
  Edit2,
  UserX,
  UserCheck,
  X,
  AlertCircle,
  CheckCircle2,
  GraduationCap,
  Mail,
  Phone,
  MapPin,
  Calendar,
  AlertTriangle
} from 'lucide-react';

interface StudentDirectoryProps {
  subjects: Subject[];
  onSelectStudent: (studentId: string) => void;
  selectedStudentId?: string | null;
}

export const StudentDirectory: React.FC<StudentDirectoryProps> = ({
  subjects,
  onSelectStudent
}) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Form states for Add Student
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newStudentId, setNewStudentId] = useState('');
  const [newClass, setNewClass] = useState('Year 1 - Class A');
  const [newSubjectId, setNewSubjectId] = useState(subjects[0]?.subject_id || '');
  const [newPhone, setNewPhone] = useState('');
  const [newGuardianName, setNewGuardianName] = useState('');
  const [newGuardianPhone, setNewGuardianPhone] = useState('');
  const [newAddress, setNewAddress] = useState('');

  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  const fetchStudents = async () => {
    setIsLoading(true);
    let url = `/api/teacher/students?`;
    if (search) url += `search=${encodeURIComponent(search)}&`;
    if (classFilter !== 'all') url += `classFilter=${encodeURIComponent(classFilter)}&`;
    if (subjectFilter !== 'all') url += `subjectId=${encodeURIComponent(subjectFilter)}&`;

    const res = await apiFetch<{ students: Student[] }>(url);
    if (res.data) {
      setStudents(res.data.students || []);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchStudents();
  }, [search, classFilter, subjectFilter]);

  const handleOpenAddModal = () => {
    // Generate next student ID suggestion based on count
    const nextNum = String(students.length + 1).padStart(3, '0');
    setNewStudentId(`STU-2026-${nextNum}`);
    setNewName('');
    setNewEmail('');
    setNewPhone('');
    setNewGuardianName('');
    setNewGuardianPhone('');
    setNewAddress('');
    setNewClass('Year 1 - Class A');
    setNewSubjectId(subjects[0]?.subject_id || '');
    setFormError(null);
    setFormSuccess(null);
    setIsAddModalOpen(true);
  };

  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);

    const res = await apiFetch('/api/teacher/students', {
      method: 'POST',
      body: JSON.stringify({
        name: newName,
        email: newEmail,
        studentId: newStudentId,
        class: newClass,
        subjectId: newSubjectId,
        phone: newPhone,
        guardianName: newGuardianName,
        guardianPhone: newGuardianPhone,
        address: newAddress
      })
    });

    if (res.error) {
      setFormError(res.error);
    } else {
      setFormSuccess('Student enrolled and user credentials created successfully.');
      fetchStudents();
      setTimeout(() => {
        setIsAddModalOpen(false);
        setFormSuccess(null);
      }, 1500);
    }
  };

  const handleOpenEditModal = (student: Student) => {
    setEditingStudent(student);
    setFormError(null);
    setFormSuccess(null);
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    setFormError(null);

    const res = await apiFetch(`/api/teacher/students/${editingStudent.student_id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: editingStudent.name,
        email: editingStudent.email,
        class: editingStudent.class,
        phone: editingStudent.phone,
        address: editingStudent.address,
        guardianName: editingStudent.guardian_name,
        guardianPhone: editingStudent.guardian_phone,
        bio: editingStudent.bio
      })
    });

    if (res.error) {
      setFormError(res.error);
    } else {
      setFormSuccess('Student profile updated successfully.');
      fetchStudents();
      setTimeout(() => {
        setIsEditModalOpen(false);
        setFormSuccess(null);
      }, 1200);
    }
  };

  const handleToggleStatus = async (student: Student) => {
    const nextStatus = student.account_status === 'active' ? 'deactivated' : 'active';
    const confirmMessage = nextStatus === 'deactivated'
      ? `Are you sure you want to deactivate ${student.name}'s account? All existing attendance, marks, and submissions will be safely preserved.`
      : `Reactivate account for ${student.name}?`;

    if (!window.confirm(confirmMessage)) return;

    const res = await apiFetch(`/api/teacher/students/${student.student_id}/toggle-status`, {
      method: 'POST',
      body: JSON.stringify({ status: nextStatus })
    });

    if (res.error) {
      alert(res.error);
    } else {
      fetchStudents();
    }
  };

  return (
    <div className="space-y-6">
      {/* Top action and filter bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-1 flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by student name, ID or email..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          {/* Class Filter */}
          <select
            value={classFilter}
            onChange={e => setClassFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 bg-white focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Classes</option>
            <option value="Year 1 - Class A">Year 1 - Class A</option>
            <option value="Year 1 - Class B">Year 1 - Class B</option>
          </select>

          {/* Subject Filter */}
          <select
            value={subjectFilter}
            onChange={e => setSubjectFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 bg-white focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Assigned Subjects</option>
            {subjects.map(s => (
              <option key={s.subject_id} value={s.subject_id}>
                {s.subject_code} ({s.subject_name})
              </option>
            ))}
          </select>
        </div>

        {/* Add Student Button */}
        <button
          onClick={handleOpenAddModal}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Enroll New Student</span>
        </button>
      </div>

      {/* Students Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 text-sm">Assigned Student Roster</h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
              {students.length} students
            </span>
          </div>
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">
            Click &apos;View File&apos; for academic transcript and attendance breakdown
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                <th className="py-3.5 px-6">Student ID</th>
                <th className="py-3.5 px-6">Full Name & Email</th>
                <th className="py-3.5 px-6">Class Section</th>
                <th className="py-3.5 px-6">Attendance %</th>
                <th className="py-3.5 px-6">Academic Score</th>
                <th className="py-3.5 px-6">Status</th>
                <th className="py-3.5 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Loading student records from database...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    No students found matching your criteria.
                  </td>
                </tr>
              ) : (
                students.map(st => {
                  const attPct = st.attendancePercentage ?? 100;
                  const isLowAtt = attPct < 75;
                  const gradePct = st.academicPercentage;

                  return (
                    <tr
                      key={st.student_id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        st.account_status === 'deactivated' ? 'opacity-60 bg-slate-50/30' : ''
                      }`}
                    >
                      <td className="py-4 px-6 font-mono font-bold text-slate-800">
                        {st.student_id}
                      </td>

                      <td className="py-4 px-6">
                        <div className="font-bold text-slate-900">{st.name}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{st.email}</div>
                      </td>

                      <td className="py-4 px-6">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700">
                          {st.class}
                        </span>
                      </td>

                      <td className="py-4 px-6">
                        <div className="flex items-center gap-1.5">
                          <span className={`font-bold font-mono ${isLowAtt ? 'text-rose-600' : 'text-slate-800'}`}>
                            {attPct}%
                          </span>
                          {isLowAtt && (
                            <span className="p-0.5 bg-rose-100 text-rose-700 rounded-full" title="Below 75% attendance threshold">
                              <AlertTriangle className="w-3 h-3" />
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-4 px-6">
                        {gradePct !== null && gradePct !== undefined ? (
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold font-mono text-slate-800">{gradePct}%</span>
                            <span className={`px-1.5 py-0.2 rounded text-[10px] font-extrabold ${
                              st.gradeLetter === 'A+' || st.gradeLetter === 'A'
                                ? 'bg-emerald-100 text-emerald-800'
                                : st.gradeLetter === 'B'
                                ? 'bg-indigo-100 text-indigo-800'
                                : st.gradeLetter === 'C'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              {st.gradeLetter}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">No grades yet</span>
                        )}
                      </td>

                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                          st.account_status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-200 text-slate-700'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${st.account_status === 'active' ? 'bg-emerald-500' : 'bg-slate-500'}`} />
                          {st.account_status}
                        </span>
                      </td>

                      <td className="py-4 px-6 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => onSelectStudent(st.student_id)}
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="View Complete Academic File"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(st)}
                            className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                            title="Edit Student Details"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleToggleStatus(st)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              st.account_status === 'active'
                                ? 'text-amber-600 hover:bg-amber-50'
                                : 'text-emerald-600 hover:bg-emerald-50'
                            }`}
                            title={st.account_status === 'active' ? 'Deactivate Student Account' : 'Reactivate Student Account'}
                          >
                            {st.account_status === 'active' ? (
                              <UserX className="w-4 h-4" />
                            ) : (
                              <UserCheck className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">Enroll New Student</h3>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateStudent} className="mt-4 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}
              {formSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                    placeholder="e.g. Jordan Miller"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Student ID *</label>
                  <input
                    type="text"
                    required
                    value={newStudentId}
                    onChange={e => setNewStudentId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                    placeholder="e.g. STU-2026-026"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Institutional Email *</label>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={e => setNewEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  placeholder="e.g. jordan.miller@student.edunexa.edu"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Class Cohort *</label>
                  <select
                    value={newClass}
                    onChange={e => setNewClass(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="Year 1 - Class A">Year 1 - Class A</option>
                    <option value="Year 1 - Class B">Year 1 - Class B</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Primary Course *</label>
                  <select
                    value={newSubjectId}
                    onChange={e => setNewSubjectId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  >
                    {subjects.map(s => (
                      <option key={s.subject_id} value={s.subject_id}>
                        {s.subject_code} - {s.subject_name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={newPhone}
                    onChange={e => setNewPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                    placeholder="+1 (555) 234-9999"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Guardian Name</label>
                  <input
                    type="text"
                    value={newGuardianName}
                    onChange={e => setNewGuardianName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                    placeholder="Parent / Guardian"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
                <input
                  type="text"
                  value={newAddress}
                  onChange={e => setNewAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  placeholder="Street, City, State"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Save & Enroll Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Student Modal */}
      {isEditModalOpen && editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">Edit Student Record</h3>
              </div>
              <button onClick={() => setIsEditModalOpen(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-4 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}
              {formSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Student ID (Immutable)</label>
                <input
                  type="text"
                  disabled
                  value={editingStudent.student_id}
                  className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-lg text-xs font-mono text-slate-500 cursor-not-allowed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.name}
                    onChange={e => setEditingStudent({ ...editingStudent, name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Class Section</label>
                  <input
                    type="text"
                    required
                    value={editingStudent.class}
                    onChange={e => setEditingStudent({ ...editingStudent, class: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Institutional Email</label>
                <input
                  type="email"
                  required
                  value={editingStudent.email}
                  onChange={e => setEditingStudent({ ...editingStudent, email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone</label>
                  <input
                    type="text"
                    value={editingStudent.phone || ''}
                    onChange={e => setEditingStudent({ ...editingStudent, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Guardian Name</label>
                  <input
                    type="text"
                    value={editingStudent.guardian_name || ''}
                    onChange={e => setEditingStudent({ ...editingStudent, guardian_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
                <input
                  type="text"
                  value={editingStudent.address || ''}
                  onChange={e => setEditingStudent({ ...editingStudent, address: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Profile Bio</label>
                <textarea
                  rows={2}
                  value={editingStudent.bio || ''}
                  onChange={e => setEditingStudent({ ...editingStudent, bio: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
