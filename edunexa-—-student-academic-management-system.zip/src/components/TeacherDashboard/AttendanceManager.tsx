import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api';
import { Subject } from '../../types';
import {
  Calendar,
  Check,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Save,
  Users,
  Info,
  CalendarCheck,
  RotateCcw
} from 'lucide-react';

interface AttendanceManagerProps {
  subjects: Subject[];
}

interface StudentAttendanceRow {
  student_id: string;
  name: string;
  class: string;
  email: string;
  attendance_status?: 'Present' | 'Absent' | 'Late' | 'Excused' | null;
  attendance_remarks?: string | null;
}

export const AttendanceManager: React.FC<AttendanceManagerProps> = ({ subjects }) => {
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.subject_id || '');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [sessionName, setSessionName] = useState<string>('Morning Lecture');
  const [students, setStudents] = useState<StudentAttendanceRow[]>([]);
  const [attendanceMap, setAttendanceMap] = useState<Record<string, { status: 'Present' | 'Absent' | 'Late' | 'Excused'; remarks: string }>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchAttendance = async () => {
    if (!selectedSubjectId || !selectedDate) return;
    setIsLoading(true);
    setSaveMessage(null);

    const res = await apiFetch<{
      students: StudentAttendanceRow[];
      subject: Subject;
      date: string;
    }>(`/api/teacher/attendance?subjectId=${encodeURIComponent(selectedSubjectId)}&date=${encodeURIComponent(selectedDate)}`);

    if (res.data) {
      setStudents(res.data.students || []);
      // Pre-fill local state
      const initialMap: Record<string, { status: 'Present' | 'Absent' | 'Late' | 'Excused'; remarks: string }> = {};
      res.data.students.forEach(st => {
        initialMap[st.student_id] = {
          status: (st.attendance_status as any) || 'Present',
          remarks: st.attendance_remarks || ''
        };
      });
      setAttendanceMap(initialMap);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchAttendance();
  }, [selectedSubjectId, selectedDate]);

  const handleStatusChange = (studentId: string, status: 'Present' | 'Absent' | 'Late' | 'Excused') => {
    setAttendanceMap(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
  };

  const handleRemarksChange = (studentId: string, remarks: string) => {
    setAttendanceMap(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        remarks
      }
    }));
  };

  const handleMarkAll = (status: 'Present' | 'Absent') => {
    setAttendanceMap(prev => {
      const next = { ...prev };
      students.forEach(st => {
        next[st.student_id] = {
          ...next[st.student_id],
          status
        };
      });
      return next;
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveMessage(null);

    const records = Object.entries(attendanceMap).map(([studentId, val]) => ({
      studentId,
      status: val.status,
      remarks: val.remarks
    }));

    const res = await apiFetch('/api/teacher/attendance', {
      method: 'POST',
      body: JSON.stringify({
        subjectId: selectedSubjectId,
        date: selectedDate,
        sessionName,
        records
      })
    });

    setIsSaving(false);
    if (res.error) {
      setSaveMessage({ type: 'error', text: res.error });
    } else {
      setSaveMessage({ type: 'success', text: `Attendance recorded for ${records.length} students on ${selectedDate}.` });
      setTimeout(() => setSaveMessage(null), 4000);
    }
  };

  // Quick stats for current session
  const counts = {
    present: 0,
    late: 0,
    absent: 0,
    excused: 0
  };
  Object.values(attendanceMap).forEach(v => {
    if (v.status === 'Present') counts.present++;
    else if (v.status === 'Late') counts.late++;
    else if (v.status === 'Absent') counts.absent++;
    else if (v.status === 'Excused') counts.excused++;
  });

  return (
    <div className="space-y-6">
      {/* Session Configuration Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <CalendarCheck className="w-5 h-5 text-indigo-600" />
              Attendance Management & Verification
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Record daily lecture presence, handle medical slips, and monitor compliance
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleMarkAll('Present')}
              className="px-3 py-1.5 text-xs font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg border border-emerald-200/60 transition-colors"
            >
              Mark All Present
            </button>
            <button
              onClick={() => handleMarkAll('Absent')}
              className="px-3 py-1.5 text-xs font-semibold bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-lg border border-rose-200/60 transition-colors"
            >
              Mark All Absent
            </button>
          </div>
        </div>

        {/* Filters Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Select Course
            </label>
            <select
              value={selectedSubjectId}
              onChange={e => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500"
            >
              {subjects.map(s => (
                <option key={s.subject_id} value={s.subject_id}>
                  {s.subject_code} - {s.subject_name} ({s.class})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Session Date
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Lecture Session
            </label>
            <select
              value={sessionName}
              onChange={e => setSessionName(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium bg-white focus:ring-2 focus:ring-indigo-500"
            >
              <option value="Morning Lecture">Morning Lecture (09:00 - 10:30)</option>
              <option value="Afternoon Session">Afternoon Session (13:00 - 14:30)</option>
              <option value="Laboratory Practical">Laboratory Practical (15:00 - 17:00)</option>
              <option value="Special Review Lecture">Special Review Lecture</option>
            </select>
          </div>
        </div>

        {/* Live Counters */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <span className="text-xs font-semibold text-slate-500">Session Summary:</span>
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
            Present: {counts.present}
          </span>
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200/60">
            Late (0.5 weight): {counts.late}
          </span>
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200/60">
            Absent: {counts.absent}
          </span>
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200/60" title="Excused records are excluded from calculation denominator">
            Excused (Excluded): {counts.excused}
          </span>
        </div>
      </div>

      {/* Save Notification */}
      {saveMessage && (
        <div className={`p-4 rounded-xl text-xs font-medium flex items-center gap-2 ${
          saveMessage.type === 'success'
            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            : 'bg-rose-50 text-rose-800 border border-rose-200'
        }`}>
          {saveMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{saveMessage.text}</span>
        </div>
      )}

      {/* Attendance Roster Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 text-sm">Student Attendance Roster</h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
              {students.length} students enrolled
            </span>
          </div>

          <button
            onClick={handleSave}
            disabled={isSaving || students.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs disabled:opacity-50 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save & Publish Attendance'}</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                <th className="py-3 px-6">Roll / Student ID</th>
                <th className="py-3 px-6">Student Name</th>
                <th className="py-3 px-6">Class Section</th>
                <th className="py-3 px-6">Attendance Status</th>
                <th className="py-3 px-6">Remarks / Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    Loading enrolled students...
                  </td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    No students currently enrolled in this subject cohort.
                  </td>
                </tr>
              ) : (
                students.map(st => {
                  const current = attendanceMap[st.student_id] || { status: 'Present', remarks: '' };

                  return (
                    <tr key={st.student_id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-6 font-mono font-bold text-slate-800">
                        {st.student_id}
                      </td>

                      <td className="py-3.5 px-6">
                        <span className="font-bold text-slate-900 block">{st.name}</span>
                        <span className="text-[11px] text-slate-400">{st.email}</span>
                      </td>

                      <td className="py-3.5 px-6">
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                          {st.class}
                        </span>
                      </td>

                      <td className="py-3.5 px-6">
                        <div className="inline-flex p-1 bg-slate-100 rounded-xl gap-1">
                          {(['Present', 'Late', 'Absent', 'Excused'] as const).map(status => {
                            const isSelected = current.status === status;
                            return (
                              <button
                                key={status}
                                type="button"
                                onClick={() => handleStatusChange(st.student_id, status)}
                                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all ${
                                  isSelected
                                    ? status === 'Present'
                                      ? 'bg-emerald-600 text-white shadow-xs'
                                      : status === 'Late'
                                      ? 'bg-amber-600 text-white shadow-xs'
                                      : status === 'Absent'
                                      ? 'bg-rose-600 text-white shadow-xs'
                                      : 'bg-blue-600 text-white shadow-xs'
                                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                                }`}
                              >
                                {status}
                              </button>
                            );
                          })}
                        </div>
                      </td>

                      <td className="py-3.5 px-6">
                        <input
                          type="text"
                          value={current.remarks}
                          onChange={e => handleRemarksChange(st.student_id, e.target.value)}
                          placeholder={current.status === 'Excused' ? 'e.g. Medical excuse slip #402' : 'Optional teacher note...'}
                          className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                        />
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <Info className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>Attendance Policy Formula: ((Present + 0.5 * Late) / (Total - Excused)) * 100</span>
          </div>
          <button
            onClick={handleSave}
            disabled={isSaving || students.length === 0}
            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors"
          >
            {isSaving ? 'Saving...' : 'Save Attendance'}
          </button>
        </div>
      </div>
    </div>
  );
};
