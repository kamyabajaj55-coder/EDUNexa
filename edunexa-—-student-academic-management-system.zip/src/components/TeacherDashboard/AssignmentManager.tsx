import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api';
import { Subject, Assignment, Submission } from '../../types';
import {
  BookOpen,
  Plus,
  Eye,
  Trash2,
  Edit2,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  X,
  FileText,
  Send,
  Download,
  Users
} from 'lucide-react';

interface AssignmentManagerProps {
  subjects: Subject[];
}

export const AssignmentManager: React.FC<AssignmentManagerProps> = ({ subjects }) => {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Create Assignment Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subjectId, setSubjectId] = useState(subjects[0]?.subject_id || '');
  const [totalMarks, setTotalMarks] = useState('50');
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return `${d.toISOString().split('T')[0]} 23:59:00`;
  });
  const [publicationStatus, setPublicationStatus] = useState<'published' | 'draft'>('published');
  const [createError, setCreateError] = useState<string | null>(null);

  // Submissions Drawer
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [isLoadingSubmissions, setIsLoadingSubmissions] = useState(false);

  // Grade Submission Modal / Form
  const [evaluatingSubmission, setEvaluatingSubmission] = useState<Submission | null>(null);
  const [gradeMarks, setGradeMarks] = useState('');
  const [gradeFeedback, setGradeFeedback] = useState('');
  const [gradeError, setGradeError] = useState<string | null>(null);
  const [isSubmittingGrade, setIsSubmittingGrade] = useState(false);

  const fetchAssignments = async () => {
    setIsLoading(true);
    const res = await apiFetch<{ assignments: Assignment[] }>('/api/teacher/assignments');
    if (res.data) {
      setAssignments(res.data.assignments || []);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchAssignments();
  }, []);

  const handleCreateAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);

    const res = await apiFetch('/api/teacher/assignments', {
      method: 'POST',
      body: JSON.stringify({
        title,
        description,
        subjectId,
        totalMarks: parseFloat(totalMarks),
        dueDate,
        publicationStatus
      })
    });

    if (res.error) {
      setCreateError(res.error);
    } else {
      setIsCreateModalOpen(false);
      setTitle('');
      setDescription('');
      fetchAssignments();
    }
  };

  const handleDeleteAssignment = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete "${name}"? All student submissions for this assignment will also be removed.`)) {
      return;
    }

    const res = await apiFetch(`/api/teacher/assignments/${id}`, { method: 'DELETE' });
    if (res.error) {
      alert(res.error);
    } else {
      fetchAssignments();
    }
  };

  const handleOpenSubmissions = async (asn: Assignment) => {
    setSelectedAssignment(asn);
    setIsLoadingSubmissions(true);
    const res = await apiFetch<{ assignment: Assignment; submissions: Submission[] }>(
      `/api/teacher/assignments/${asn.assignment_id}/submissions`
    );
    if (res.data) {
      setSubmissions(res.data.submissions || []);
    }
    setIsLoadingSubmissions(false);
  };

  const handleStartEvaluate = (sub: Submission) => {
    setEvaluatingSubmission(sub);
    setGradeMarks(sub.marks !== null && sub.marks !== undefined ? String(sub.marks) : '');
    setGradeFeedback(sub.feedback || '');
    setGradeError(null);
  };

  const handleSaveEvaluation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!evaluatingSubmission || !selectedAssignment) return;
    setGradeError(null);

    const num = parseFloat(gradeMarks);
    if (isNaN(num) || num < 0 || num > selectedAssignment.total_marks) {
      setGradeError(`Marks must be a valid number between 0 and ${selectedAssignment.total_marks}.`);
      return;
    }

    setIsSubmittingGrade(true);
    const res = await apiFetch(`/api/teacher/submissions/${evaluatingSubmission.submission_id}/grade`, {
      method: 'POST',
      body: JSON.stringify({
        marks: num,
        feedback: gradeFeedback
      })
    });
    setIsSubmittingGrade(false);

    if (res.error) {
      setGradeError(res.error);
    } else {
      setEvaluatingSubmission(null);
      handleOpenSubmissions(selectedAssignment);
      fetchAssignments();
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Course Assignment Management
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Publish academic assignments, track student turn-ins, and return evaluated coursework
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Publish New Assignment</span>
        </button>
      </div>

      {/* Assignment List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {isLoading ? (
          <div className="col-span-2 py-16 text-center text-xs text-slate-400">
            Loading course assignments...
          </div>
        ) : assignments.length === 0 ? (
          <div className="col-span-2 py-16 text-center text-xs text-slate-400">
            No assignments created yet. Click &apos;Publish New Assignment&apos; to begin.
          </div>
        ) : (
          assignments.map(asn => {
            const isDraft = asn.publication_status === 'draft';
            const isDuePassed = new Date().toISOString() > new Date(asn.due_date).toISOString();

            return (
              <div
                key={asn.assignment_id}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-slate-300 transition-colors"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                      {asn.subject_code}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isDraft
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {asn.publication_status}
                      </span>
                      <button
                        onClick={() => handleDeleteAssignment(asn.assignment_id, asn.title)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                        title="Delete Assignment"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 leading-snug">{asn.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {asn.description}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Max Score</span>
                      <p className="font-mono font-bold text-slate-800">{asn.total_marks} Points</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Submission Deadline</span>
                      <p className={`font-mono font-semibold ${isDuePassed ? 'text-rose-600' : 'text-slate-700'}`}>
                        {asn.due_date.slice(0, 16)}
                      </p>
                    </div>
                  </div>

                  {/* Submission Statistics Bar */}
                  <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-700">{asn.total_submissions || 0} Submissions</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-emerald-700 font-semibold">{asn.graded_count || 0} Graded</span>
                      {asn.pending_count ? (
                        <>
                          <span className="text-slate-400">·</span>
                          <span className="text-amber-700 font-bold">{asn.pending_count} Needs Review</span>
                        </>
                      ) : null}
                    </div>

                    <button
                      onClick={() => handleOpenSubmissions(asn)}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs flex items-center gap-1 shadow-2xs transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Review</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Create Assignment Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">Publish New Assignment</h3>
              </div>
              <button onClick={() => setIsCreateModalOpen(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAssignment} className="mt-4 space-y-4">
              {createError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{createError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Assignment Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Lab Project: Dynamic Programming Algorithms"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Target Course *</label>
                <select
                  value={subjectId}
                  onChange={e => setSubjectId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                >
                  {subjects.map(s => (
                    <option key={s.subject_id} value={s.subject_id}>
                      {s.subject_code} - {s.subject_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Detailed Instructions *</label>
                <textarea
                  rows={4}
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Provide rubrics, expectations, formatting standards, and criteria..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Maximum Marks *</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={totalMarks}
                    onChange={e => setTotalMarks(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Publication Status</label>
                  <select
                    value={publicationStatus}
                    onChange={e => setPublicationStatus(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="published">Publish Immediately</option>
                    <option value="draft">Save as Draft</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Due Date & Time *</label>
                <input
                  type="text"
                  required
                  value={dueDate}
                  onChange={e => setDueDate(e.target.value)}
                  placeholder="YYYY-MM-DD HH:MM:SS"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Create & Post Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Submissions Review Drawer / Modal */}
      {selectedAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                  {selectedAssignment.subject_code}
                </span>
                <h3 className="font-extrabold text-base text-slate-900 mt-1">
                  Submissions: {selectedAssignment.title}
                </h3>
                <p className="text-xs text-slate-500">
                  Total Marks: {selectedAssignment.total_marks} pts · Deadline: {selectedAssignment.due_date}
                </p>
              </div>
              <button
                onClick={() => setSelectedAssignment(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List */}
            <div className="p-6 overflow-y-auto flex-1 bg-slate-50/50">
              {isLoadingSubmissions ? (
                <div className="py-16 text-center text-xs text-slate-400">
                  Loading student submissions...
                </div>
              ) : submissions.length === 0 ? (
                <div className="py-16 text-center text-xs text-slate-400">
                  No submissions recorded for this assignment.
                </div>
              ) : (
                <div className="space-y-3">
                  {submissions.map((sub: any) => {
                    const isPending = sub.submission_status === 'Pending';
                    const isGraded = sub.submission_status === 'Graded';

                    return (
                      <div
                        key={sub.student_id}
                        className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-2 hover:border-slate-300 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900">{sub.name}</span>
                            <span className="font-mono text-xs text-slate-400 font-semibold">{sub.student_id}</span>
                            <span className="text-[11px] text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded font-medium">
                              {sub.class}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              isGraded
                                ? 'bg-emerald-100 text-emerald-800'
                                : sub.submission_status === 'Late'
                                ? 'bg-amber-100 text-amber-800'
                                : isPending
                                ? 'bg-slate-100 text-slate-600'
                                : 'bg-indigo-100 text-indigo-800'
                            }`}>
                              {sub.submission_status}
                            </span>

                            {!isPending && (
                              <button
                                onClick={() => handleStartEvaluate(sub)}
                                className="px-3 py-1 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-bold transition-colors"
                              >
                                {isGraded ? 'Edit Grade' : 'Grade Submission'}
                              </button>
                            )}
                          </div>
                        </div>

                        {!isPending ? (
                          <>
                            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs text-slate-700 leading-relaxed font-sans">
                              {sub.answer_text || 'File attachment submitted without accompanying text body.'}
                            </div>

                            <div className="flex flex-wrap items-center justify-between text-xs pt-1 border-t border-slate-100 text-slate-500">
                              <span className="font-mono text-[11px]">Submitted: {sub.submission_date}</span>
                              {sub.file_name && (
                                <span className="inline-flex items-center gap-1 text-indigo-600 font-semibold">
                                  <FileText className="w-3.5 h-3.5" />
                                  <span>{sub.file_name}</span>
                                </span>
                              )}
                              {isGraded && (
                                <span className="font-bold text-emerald-700">
                                  Awarded: {sub.marks} / {selectedAssignment.total_marks} pts
                                </span>
                              )}
                            </div>

                            {sub.feedback && (
                              <div className="text-xs text-indigo-900 bg-indigo-50/70 p-2.5 rounded-lg border border-indigo-100 font-medium">
                                Written Faculty Feedback: &quot;{sub.feedback}&quot;
                              </div>
                            )}
                          </>
                        ) : (
                          <p className="text-xs text-slate-400 italic">
                            Student has not yet submitted a solution for this assignment.
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Grade Submission Modal */}
      {evaluatingSubmission && selectedAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-base text-slate-900">Evaluate Submission</h3>
                <p className="text-xs text-slate-500">
                  {evaluatingSubmission.name} ({evaluatingSubmission.student_id})
                </p>
              </div>
              <button onClick={() => setEvaluatingSubmission(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEvaluation} className="mt-4 space-y-4">
              {gradeError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{gradeError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Awarded Marks (Out of {selectedAssignment.total_marks}) *
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max={selectedAssignment.total_marks}
                  required
                  value={gradeMarks}
                  onChange={e => setGradeMarks(e.target.value)}
                  placeholder="e.g. 45"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Written Feedback & Recommendations
                </label>
                <textarea
                  rows={4}
                  value={gradeFeedback}
                  onChange={e => setGradeFeedback(e.target.value)}
                  placeholder="Provide constructive feedback, praise analytical strengths, and note points of improvement..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEvaluatingSubmission(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingGrade}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmittingGrade ? 'Publishing...' : 'Return Evaluated Grade'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
