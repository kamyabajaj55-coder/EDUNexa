import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api';
import {
  X,
  GraduationCap,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Clock,
  BookOpen,
  Mail,
  Phone,
  MapPin,
  Printer,
  Award
} from 'lucide-react';

interface StudentFileModalProps {
  studentId: string | null;
  onClose: () => void;
}

export const StudentFileModal: React.FC<StudentFileModalProps> = ({ studentId, onClose }) => {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'attendance' | 'grades' | 'assignments'>('profile');

  useEffect(() => {
    if (!studentId) return;
    setIsLoading(true);
    apiFetch<any>(`/api/teacher/students/${studentId}`).then(res => {
      if (res.data) {
        setData(res.data);
      }
      setIsLoading(false);
    });
  }, [studentId]);

  if (!studentId) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-slate-900">
                  {data?.student ? data.student.name : 'Student File'}
                </h3>
                <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                  {studentId}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Official Academic Dossier & Records
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Print Student Record"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Print</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-200 px-6 bg-white gap-2">
          {(['profile', 'attendance', 'grades', 'assignments'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-3 px-3 text-xs font-bold capitalize border-b-2 transition-all ${
                activeTab === tab
                  ? 'border-indigo-600 text-indigo-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab === 'profile' ? 'Overview & Profile' : tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-50/50">
          {isLoading ? (
            <div className="py-16 text-center text-xs text-slate-400">
              Retrieving academic records from database...
            </div>
          ) : !data ? (
            <div className="py-16 text-center text-xs text-slate-400">
              Unable to load student dossier.
            </div>
          ) : (
            <>
              {/* Profile & Overview Tab */}
              {activeTab === 'profile' && (
                <div className="space-y-6">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Enrolled Class</span>
                      <p className="text-sm font-bold text-slate-800 mt-0.5">{data.student.class}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Enrollment Date</span>
                      <p className="text-sm font-bold text-slate-800 mt-0.5">{data.student.enrollment_date}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Institutional Email</span>
                      <p className="text-sm font-mono text-slate-700 mt-0.5">{data.student.email}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Contact Phone</span>
                      <p className="text-sm text-slate-700 mt-0.5">{data.student.phone || 'Not recorded'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Guardian Details</span>
                      <p className="text-sm text-slate-700 mt-0.5">
                        {data.student.guardian_name || 'N/A'} {data.student.guardian_phone ? `(${data.student.guardian_phone})` : ''}
                      </p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Account Status</span>
                      <p className="mt-0.5">
                        <span className={`inline-block px-2 py-0.5 text-xs font-bold rounded-full capitalize ${
                          data.student.account_status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                        }`}>
                          {data.student.account_status}
                        </span>
                      </p>
                    </div>
                    <div className="md:col-span-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Residential Address</span>
                      <p className="text-sm text-slate-700 mt-0.5">{data.student.address || 'Campus Residence'}</p>
                    </div>
                    <div className="md:col-span-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Academic Bio</span>
                      <p className="text-xs text-slate-600 mt-0.5 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                        {data.student.bio || 'Standard undergraduate registration.'}
                      </p>
                    </div>
                  </div>

                  {/* Enrolled Courses */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Enrolled Courses with Faculty
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {data.subjects?.map((s: any) => (
                        <div key={s.subject_id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
                          <span className="font-mono text-xs font-extrabold text-indigo-700">{s.subject_code}</span>
                          <h5 className="font-bold text-sm text-slate-900 mt-0.5">{s.subject_name}</h5>
                          <p className="text-[11px] text-slate-500 mt-1">Class Cohort: {s.class}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Attendance Tab */}
              {activeTab === 'attendance' && (
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">Attendance Log for this Student</h4>
                      <p className="text-[11px] text-slate-500">Calculated over recorded lectures and labs</p>
                    </div>
                    <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg">
                      {data.attendance?.length || 0} Total Sessions Recorded
                    </span>
                  </div>

                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-100 text-[11px] font-bold text-slate-500">
                        <tr>
                          <th className="py-2.5 px-4">Date</th>
                          <th className="py-2.5 px-4">Course</th>
                          <th className="py-2.5 px-4">Session</th>
                          <th className="py-2.5 px-4">Status</th>
                          <th className="py-2.5 px-4">Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {data.attendance?.map((a: any) => (
                          <tr key={a.id} className="hover:bg-slate-50">
                            <td className="py-2.5 px-4 font-mono font-semibold">{a.date}</td>
                            <td className="py-2.5 px-4 font-bold">{a.subject_code}</td>
                            <td className="py-2.5 px-4 text-slate-500">{a.session_name}</td>
                            <td className="py-2.5 px-4">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                a.status === 'Present' ? 'bg-emerald-100 text-emerald-800' :
                                a.status === 'Late' ? 'bg-amber-100 text-amber-800' :
                                a.status === 'Absent' ? 'bg-rose-100 text-rose-800' : 'bg-blue-100 text-blue-800'
                              }`}>
                                {a.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-4 text-slate-500 text-[11px]">{a.remarks || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Grades Tab */}
              {activeTab === 'grades' && (
                <div className="space-y-4">
                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-100 text-[11px] font-bold text-slate-500">
                        <tr>
                          <th className="py-2.5 px-4">Assessment</th>
                          <th className="py-2.5 px-4">Course</th>
                          <th className="py-2.5 px-4">Score</th>
                          <th className="py-2.5 px-4">Percentage</th>
                          <th className="py-2.5 px-4">Grade</th>
                          <th className="py-2.5 px-4">Faculty Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {data.grades?.map((g: any) => (
                          <tr key={g.id} className="hover:bg-slate-50">
                            <td className="py-3 px-4 font-bold text-slate-900">{g.assessment_name}</td>
                            <td className="py-3 px-4 font-semibold text-slate-600">{g.subject_code}</td>
                            <td className="py-3 px-4 font-mono font-bold">
                              {g.obtained_marks} / {g.maximum_marks}
                            </td>
                            <td className="py-3 px-4 font-mono font-bold text-indigo-700">{g.calculated_percentage}%</td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-indigo-50 text-indigo-800 border border-indigo-200">
                                {g.grade}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-slate-600 text-xs italic">{g.teacher_remarks || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Assignments Tab */}
              {activeTab === 'assignments' && (
                <div className="space-y-3">
                  {data.submissions?.length === 0 ? (
                    <div className="py-12 text-center text-xs text-slate-400">
                      No assignment submissions submitted yet.
                    </div>
                  ) : (
                    data.submissions?.map((sub: any) => (
                      <div key={sub.submission_id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-2">
                        <div className="flex items-center justify-between">
                          <h5 className="font-bold text-sm text-slate-900">{sub.assignment_title}</h5>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            sub.status === 'Graded' ? 'bg-emerald-100 text-emerald-800' : 'bg-indigo-100 text-indigo-800'
                          }`}>
                            {sub.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                          {sub.answer_text}
                        </p>
                        <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                          <span className="text-slate-400 font-mono text-[11px]">Submitted: {sub.submission_date}</span>
                          {sub.marks !== null && (
                            <span className="font-bold text-emerald-700">
                              Awarded: {sub.marks} / {sub.total_marks} pts
                            </span>
                          )}
                        </div>
                        {sub.feedback && (
                          <div className="text-xs text-indigo-900 bg-indigo-50/70 p-2 rounded border border-indigo-100 font-medium">
                            Feedback: {sub.feedback}
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
