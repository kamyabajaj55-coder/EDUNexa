import React, { useState } from 'react';
import { VoicePoweredOrb } from '@/components/ui/voice-powered-orb';
import { Button } from '@/components/ui/button';
import {
  Mic,
  MicOff,
  ArrowLeft,
  Sparkles,
  Sliders,
  Volume2,
  FolderTree,
  Code2,
  CheckCircle2,
  Info
} from 'lucide-react';

interface VoiceOrbViewProps {
  onBack: () => void;
}

export const VoiceOrbView: React.FC<VoiceOrbViewProps> = ({ onBack }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [voiceDetected, setVoiceDetected] = useState(false);
  const [hue, setHue] = useState(0);
  const [sensitivity, setSensitivity] = useState(1.5);
  const [maxRotation, setMaxRotation] = useState(1.2);

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 border border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base text-white">Voice-Powered Orb</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/30 text-indigo-300 border border-indigo-400/30">
                WebGL + Web Audio API
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Interactive WebGL visualizer with real-time RMS voice frequency analysis
            </p>
          </div>
        </div>

        <button
          onClick={onBack}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
        >
          Return to EduNexa Academic Portal
        </button>
      </div>

      {/* Main Interactive Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Orb Canvas Card */}
        <div className="lg:col-span-2 bg-radial from-slate-900 via-slate-950 to-black rounded-3xl p-8 border border-slate-800 shadow-2xl flex flex-col items-center justify-center relative overflow-hidden min-h-[480px]">
          {/* Subtle Ambient Background */}
          <div className="absolute inset-0 bg-indigo-500/5 blur-3xl pointer-events-none" />

          {/* Voice Detected Indicator */}
          <div className="absolute top-6 left-6 flex items-center gap-2 z-10">
            <span
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                voiceDetected
                  ? 'bg-emerald-400 shadow-[0_0_12px_#34d399] scale-125 animate-ping'
                  : isRecording
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-slate-600'
              }`}
            />
            <span className="text-xs font-mono text-slate-300">
              {voiceDetected
                ? 'Voice Input Active'
                : isRecording
                ? 'Listening for Voice...'
                : 'Microphone Inactive'}
            </span>
          </div>

          {/* 3D WebGL Orb */}
          <div className="w-80 h-80 sm:w-96 sm:h-96 relative z-0 flex items-center justify-center">
            <VoicePoweredOrb
              hue={hue}
              enableVoiceControl={isRecording}
              voiceSensitivity={sensitivity}
              maxRotationSpeed={maxRotation}
              className="rounded-2xl overflow-hidden"
              onVoiceDetected={setVoiceDetected}
            />
          </div>

          {/* Control Button */}
          <div className="mt-6 flex flex-col items-center gap-3 relative z-10">
            <Button
              onClick={toggleRecording}
              variant={isRecording ? 'destructive' : 'default'}
              size="lg"
              className={`px-8 py-3.5 rounded-xl text-sm font-bold shadow-lg transition-all ${
                isRecording
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-900/30'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-900/30'
              }`}
            >
              {isRecording ? (
                <>
                  <MicOff className="w-5 h-5 mr-2" />
                  <span>Stop Voice Control</span>
                </>
              ) : (
                <>
                  <Mic className="w-5 h-5 mr-2" />
                  <span>Enable Voice Control</span>
                </>
              )}
            </Button>
            <p className="text-slate-400 text-xs text-center max-w-sm">
              Click to grant microphone access. Speak to watch the orb react, rotate, and deform based on your vocal timbre and volume.
            </p>
          </div>
        </div>

        {/* Customization Controls Panel */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-6 flex flex-col justify-between">
          <div className="space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Sliders className="w-4 h-4 text-indigo-600" />
              <h4 className="font-bold text-sm text-slate-900">Orb Parameters</h4>
            </div>

            {/* Hue Slider */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>Color Spectrum (Hue)</span>
                <span className="font-mono text-indigo-600 font-bold">{hue}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                value={hue}
                onChange={e => setHue(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                <span>0° Violet</span>
                <span>120° Teal</span>
                <span>240° Amber</span>
                <span>360°</span>
              </div>
            </div>

            {/* Sensitivity Slider */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>Voice Sensitivity</span>
                <span className="font-mono text-indigo-600 font-bold">{sensitivity}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="4.0"
                step="0.1"
                value={sensitivity}
                onChange={e => setSensitivity(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                Controls vocal threshold required for ripple deformations.
              </span>
            </div>

            {/* Rotation Speed */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>Max Rotation Velocity</span>
                <span className="font-mono text-indigo-600 font-bold">{maxRotation}</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="3.0"
                step="0.1"
                value={maxRotation}
                onChange={e => setMaxRotation(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                Spin acceleration under active continuous speech.
              </span>
            </div>

            {/* Presets */}
            <div className="pt-2">
              <span className="text-xs font-semibold text-slate-700 block mb-2">Preset Palettes</span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setHue(0)}
                  className="px-2 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg transition-colors"
                >
                  Cosmic Blue
                </button>
                <button
                  onClick={() => setHue(140)}
                  className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs rounded-lg transition-colors"
                >
                  Emerald Glow
                </button>
                <button
                  onClick={() => setHue(290)}
                  className="px-2 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-lg transition-colors"
                >
                  Solar Flare
                </button>
              </div>
            </div>
          </div>

          {/* Academic Use Case Note */}
          <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs text-slate-600 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Volume2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>EduNexa Voice Companion</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500">
              Can be connected to speech recognition APIs to power hands-free lecture attendance dictation and oral examination quizzes.
            </p>
          </div>
        </div>
      </div>

      {/* Integration & Setup Documentation */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <FolderTree className="w-5 h-5 text-indigo-600" />
          <h4 className="font-bold text-sm text-slate-900">
            shadcn Component Structure &amp; Integration Guidelines
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-600">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block">Default Path: /components/ui</span>
            <p className="text-[11px] leading-relaxed text-slate-500">
              In shadcn CLI standards, <code>/components/ui</code> is designated for pure atomic UI primitives (e.g., <code>button.tsx</code>, <code>voice-powered-orb.tsx</code>). Keeping this distinct from feature-level components guarantees zero cyclical dependencies.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block">Installed Dependencies</span>
            <p className="text-[11px] leading-relaxed text-slate-500">
              Installed via NPM: <code>ogl</code> (minimal WebGL library), <code>@radix-ui/react-slot</code>, <code>class-variance-authority</code>, <code>clsx</code>, and <code>tailwind-merge</code>.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
            <span className="font-bold text-slate-800 block">Path Alias: @/components/ui</span>
            <p className="text-[11px] leading-relaxed text-slate-500">
              Both <code>tsconfig.json</code> and <code>vite.config.ts</code> configure <code>@/components/ui/*</code> and <code>@/lib/utils</code> for drop-in compatibility with shadcn components.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
