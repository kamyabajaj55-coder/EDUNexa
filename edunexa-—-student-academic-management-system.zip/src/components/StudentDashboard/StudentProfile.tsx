import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Save,
  CheckCircle2,
  AlertCircle,
  GraduationCap,
  ShieldCheck
} from 'lucide-react';

interface StudentProfileProps {
  onRefresh: () => void;
}

export const StudentProfile: React.FC<StudentProfileProps> = ({ onRefresh }) => {
  const [profile, setProfile] = useState<any>(null);
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [bio, setBio] = useState('');

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchProfile = async () => {
    setIsLoading(true);
    const res = await apiFetch<{ student: any; enrolments: any[] }>('/api/student/profile');
    if (res.data) {
      const st = res.data.student;
      setProfile(st);
      setPhone(st.phone || '');
      setAddress(st.address || '');
      setGuardianPhone(st.guardian_phone || '');
      setBio(st.bio || '');
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMessage(null);

    const res = await apiFetch('/api/student/profile', {
      method: 'PUT',
      body: JSON.stringify({
        phone,
        address,
        guardianPhone,
        bio
      })
    });
    setIsSaving(false);

    if (res.error) {
      setStatusMessage({ type: 'error', text: res.error });
    } else {
      setStatusMessage({ type: 'success', text: 'Personal profile updated successfully.' });
      onRefresh();
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  if (isLoading || !profile) {
    return (
      <div className="py-16 text-center text-xs text-slate-400">
        Loading student record...
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-extrabold text-base text-slate-900">{profile.name}</h3>
            <p className="text-xs text-slate-500 font-mono font-medium">
              Student ID: {profile.student_id} · {profile.class}
            </p>
          </div>
        </div>

        {statusMessage && (
          <div className={`mt-4 p-4 rounded-xl text-xs font-medium flex items-center gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}>
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="mt-6 space-y-4">
          {/* Read-Only Official Academic Attributes */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Immutable Academic Record (Managed by Registrar)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Student ID</span>
                <p className="font-mono font-bold text-slate-800 mt-0.5">{profile.student_id}</p>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Class Cohort</span>
                <p className="font-bold text-slate-800 mt-0.5">{profile.class}</p>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Registered Email</span>
                <p className="font-mono font-semibold text-slate-700 mt-0.5">{profile.email}</p>
              </div>
            </div>
          </div>

          {/* Editable Personal Contact Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Personal Contact Phone
              </label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Emergency Guardian Contact Phone
              </label>
              <input
                type="text"
                value={guardianPhone}
                onChange={e => setGuardianPhone(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Residential Address
            </label>
            <input
              type="text"
              value={address}
              onChange={e => setAddress(e.target.value)}
              placeholder="e.g. 104 University Heights, Apt 22"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Personal Academic Statement / Bio
            </label>
            <textarea
              rows={3}
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Describe your research interests and academic aspirations..."
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving Changes...' : 'Save Profile Changes'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
