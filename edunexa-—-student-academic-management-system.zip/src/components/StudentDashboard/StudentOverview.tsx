import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  GraduationCap,
  Award,
  CalendarCheck,
  BookOpen,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Clock,
  Sparkles
} from 'lucide-react';

interface StudentOverviewProps {
  gradesData: any;
  attendanceData: any;
  assignmentsData: any[];
  onNavigateTab: (tab: string) => void;
}

export const StudentOverview: React.FC<StudentOverviewProps> = ({
  gradesData,
  attendanceData,
  assignmentsData,
  onNavigateTab
}) => {
  const { user } = useAuth();

  const gpa = gradesData?.summary?.cumulativeGpa ?? '—';
  const overallAcademicPct = gradesData?.summary?.overallPercentage ?? 0;
  const overallGrade = gradesData?.summary?.overallGrade ?? '—';
  const attendancePct = attendanceData?.summary?.overallPercentage ?? 0;
  const isLowAttendance = attendanceData?.summary?.isLowAttendanceWarning ?? false;

  const pendingAssignments = assignmentsData.filter(
    a => a.current_status === 'Pending' || a.current_status === 'Overdue'
  );

  return (
    <div className="space-y-6">
      {/* Personalized Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Fall 2026 Academic Term</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.name}
            </h2>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
              <span className="font-mono bg-white/10 px-2 py-0.5 rounded">ID: {user?.profileId}</span>
              <span>•</span>
              <span>{user?.details?.class || 'Class 10-A'}</span>
              <span>•</span>
              <span>Registered Student</span>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-white/10 backdrop-blur p-4 rounded-2xl border border-white/10">
            <div className="text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-300 font-bold">Cumulative GPA</span>
              <p className="text-3xl font-extrabold font-mono text-emerald-400 mt-0.5">{gpa}</p>
              <span className="text-[10px] text-slate-400">4.0 Scale</span>
            </div>
            <div className="w-px h-12 bg-white/10" />
            <div className="text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-300 font-bold">Standing</span>
              <p className="text-3xl font-extrabold font-mono text-indigo-300 mt-0.5">{overallGrade}</p>
              <span className="text-[10px] text-slate-400">{overallAcademicPct}% Avg</span>
            </div>
          </div>
        </div>
      </div>

      {/* Attendance Warning if Applicable */}
      {isLowAttendance && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-rose-100 text-rose-700 rounded-xl">
              <AlertTriangle className="w-5 h-5 shrink-0" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-rose-900">Attendance Warning: Low Lecture Presence</h4>
              <p className="text-xs text-rose-700 mt-0.5 leading-relaxed">
                Your current attendance is <strong>{attendancePct}%</strong>, which is below the institutional 75% minimum threshold. Continued absence risks examination debarment.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('attendance')}
            className="shrink-0 px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-colors shadow-2xs"
          >
            Review Attendance
          </button>
        </div>
      )}

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div
          onClick={() => onNavigateTab('attendance')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 cursor-pointer transition-all flex items-center justify-between"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Attendance Rate</span>
            <h3 className={`text-3xl font-extrabold mt-1 font-mono ${attendancePct < 75 ? 'text-rose-600' : 'text-slate-900'}`}>
              {attendancePct}%
            </h3>
            <p className="text-xs text-indigo-600 font-semibold mt-1 flex items-center gap-1">
              View session log <ArrowRight className="w-3 h-3" />
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
            <CalendarCheck className="w-6 h-6" />
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('grades')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-300 cursor-pointer transition-all flex items-center justify-between"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Academic Grade</span>
            <h3 className="text-3xl font-extrabold text-slate-900 mt-1 font-mono">
              {overallGrade} <span className="text-sm font-semibold text-slate-500">({overallAcademicPct}%)</span>
            </h3>
            <p className="text-xs text-emerald-600 font-semibold mt-1 flex items-center gap-1">
              Official transcript <ArrowRight className="w-3 h-3" />
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <Award className="w-6 h-6" />
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('assignments')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-amber-300 cursor-pointer transition-all flex items-center justify-between"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Action Items</span>
            <h3 className="text-3xl font-extrabold text-slate-900 mt-1 font-mono">
              {pendingAssignments.length}
            </h3>
            <p className="text-xs text-amber-600 font-semibold mt-1 flex items-center gap-1">
              Due assignments <ArrowRight className="w-3 h-3" />
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
            <BookOpen className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Course Performance Breakdown */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">Enrolled Courses & Academic Standings</h3>
            <p className="text-xs text-slate-500">Performance calculated from verified faculty grades</p>
          </div>
          <button
            onClick={() => onNavigateTab('grades')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
          >
            View Full Transcript
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {gradesData?.subjectSummary?.map((sub: any) => (
            <div
              key={sub.subject_id}
              className="p-4 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-white hover:border-indigo-200 transition-all space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-extrabold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                  {sub.subject_code}
                </span>
                <span className="px-2 py-0.5 rounded text-xs font-extrabold bg-emerald-100 text-emerald-800">
                  {sub.grade}
                </span>
              </div>
              <h4 className="font-bold text-sm text-slate-900 truncate">{sub.subject_name}</h4>
              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span>Evaluated Score</span>
                <span className="font-mono font-bold text-slate-800">
                  {sub.obtainedMarks} / {sub.maximumMarks} pts ({sub.percentage}%)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
