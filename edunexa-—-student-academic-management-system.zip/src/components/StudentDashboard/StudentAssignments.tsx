import React, { useState } from 'react';
import { apiFetch } from '../../api';
import { Assignment } from '../../types';
import {
  BookOpen,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Upload,
  FileText,
  X,
  Send,
  MessageSquare,
  Award
} from 'lucide-react';

interface StudentAssignmentsProps {
  assignments: Assignment[];
  onRefresh: () => void;
}

export const StudentAssignments: React.FC<StudentAssignmentsProps> = ({
  assignments,
  onRefresh
}) => {
  const [filter, setFilter] = useState<'All' | 'Pending' | 'Submitted' | 'Graded' | 'Overdue'>('All');
  const [submittingAssignment, setSubmittingAssignment] = useState<Assignment | null>(null);
  const [answerText, setAnswerText] = useState('');
  const [fileName, setFileName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const filtered = assignments.filter(a => {
    if (filter === 'All') return true;
    return a.current_status === filter;
  });

  const handleOpenSubmitModal = (asn: Assignment) => {
    setSubmittingAssignment(asn);
    setAnswerText(asn.answer_text || '');
    setFileName('');
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  const handleSubmitSolution = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!submittingAssignment) return;
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!answerText.trim() && !fileName.trim()) {
      setErrorMsg('Please write your solution or provide a file attachment.');
      return;
    }

    setIsSubmitting(true);
    const res = await apiFetch(`/api/student/assignments/${submittingAssignment.assignment_id}/submit`, {
      method: 'POST',
      body: JSON.stringify({
        answerText,
        fileName: fileName.trim() ? fileName.trim() : null
      })
    });
    setIsSubmitting(false);

    if (res.error) {
      setErrorMsg(res.error);
    } else {
      setSuccessMsg(res.data?.message || 'Assignment submitted successfully.');
      onRefresh();
      setTimeout(() => {
        setSubmittingAssignment(null);
        setSuccessMsg(null);
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Filter Tabs */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Coursework Assignments & Submissions
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Turn in solutions, review deadlines, and read faculty grading evaluations
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
          {(['All', 'Pending', 'Submitted', 'Graded', 'Overdue'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                filter === tab
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Assignment Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-2 py-16 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200">
            No assignments match the &apos;{filter}&apos; filter.
          </div>
        ) : (
          filtered.map(asn => {
            const isGraded = asn.current_status === 'Graded';
            const isSubmitted = asn.current_status === 'Submitted' || asn.current_status === 'Late';
            const isOverdue = asn.current_status === 'Overdue';

            return (
              <div
                key={asn.assignment_id}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-slate-300 transition-colors"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                      {asn.subject_code} · {asn.subject_name}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      isGraded
                        ? 'bg-emerald-100 text-emerald-800'
                        : isSubmitted
                        ? 'bg-indigo-100 text-indigo-800'
                        : isOverdue
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {asn.current_status}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 leading-snug">{asn.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {asn.description}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Max Score</span>
                      <p className="font-mono font-bold text-slate-800">{asn.total_marks} Points</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Submission Deadline</span>
                      <p className={`font-mono font-semibold ${isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>
                        {asn.due_date.slice(0, 16)}
                      </p>
                    </div>
                  </div>

                  {/* Feedback Card if Graded */}
                  {isGraded && (
                    <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-100 space-y-1 text-xs">
                      <div className="flex items-center justify-between text-emerald-900 font-bold">
                        <span className="flex items-center gap-1">
                          <Award className="w-3.5 h-3.5" />
                          <span>Awarded Grade:</span>
                        </span>
                        <span className="text-sm font-mono">{asn.marks} / {asn.total_marks} pts</span>
                      </div>
                      {asn.feedback && (
                        <p className="text-emerald-800 text-[11px] leading-relaxed italic">
                          Faculty Feedback: &quot;{asn.feedback}&quot;
                        </p>
                      )}
                    </div>
                  )}

                  {/* Submit / Status Actions */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-400">Faculty: {asn.teacher_name}</span>

                    {!isGraded ? (
                      <button
                        onClick={() => handleOpenSubmitModal(asn)}
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors shadow-2xs flex items-center gap-1.5 ${
                          isSubmitted
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                            : isOverdue
                            ? 'bg-rose-600 hover:bg-rose-700 text-white'
                            : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                        }`}
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isSubmitted ? 'Resubmit Solution' : isOverdue ? 'Submit Late' : 'Submit Solution'}</span>
                      </button>
                    ) : (
                      <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Graded & Recorded
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Submission Modal */}
      {submittingAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-base text-slate-900">Submit Assignment</h3>
                <p className="text-xs text-slate-500 truncate max-w-xs">{submittingAssignment.title}</p>
              </div>
              <button onClick={() => setSubmittingAssignment(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitSolution} className="mt-4 space-y-4">
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}
              {successMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs text-slate-600 space-y-1">
                <span className="font-bold text-slate-800">Assignment Rubric & Description:</span>
                <p className="leading-relaxed">{submittingAssignment.description}</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Written Answer & Methodology *
                </label>
                <textarea
                  rows={5}
                  required
                  value={answerText}
                  onChange={e => setAnswerText(e.target.value)}
                  placeholder="Provide your detailed analytical answers, proofs, code snippets, and explanations..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Attachment / File Reference (Optional)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={fileName}
                    onChange={e => setFileName(e.target.value)}
                    placeholder="e.g. project_analysis_final.pdf or solution.py"
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                  <FileText className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Simulated secure attachment storage linked to this submission ID.
                </span>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSubmittingAssignment(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Uploading...' : 'Submit Solution'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
