import React, { useState } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Info,
  Search,
  Filter,
  Check,
  X
} from 'lucide-react';

interface StudentAttendanceProps {
  data: any;
}

export const StudentAttendance: React.FC<StudentAttendanceProps> = ({ data }) => {
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [searchDate, setSearchDate] = useState('');

  if (!data) {
    return (
      <div className="py-16 text-center text-xs text-slate-400">
        Loading attendance records from database...
      </div>
    );
  }

  const { summary = {}, subjectBreakdown = [], history = [] } = data;
  const isWarning = summary.isLowAttendanceWarning;

  const filteredHistory = history.filter((h: any) => {
    if (subjectFilter !== 'all' && h.subject_id !== subjectFilter) return false;
    if (searchDate && !h.date.includes(searchDate)) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & KPI */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <CalendarCheck className="w-5 h-5 text-indigo-600" />
              Verified Attendance Record & Lecture Logs
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Accredited classroom participation logs recorded directly by assigned course faculty
            </p>
          </div>

          <div className="text-right">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Cumulative Percentage
            </span>
            <span className={`text-4xl font-extrabold font-mono ${isWarning ? 'text-rose-600' : 'text-slate-900'}`}>
              {summary.overallPercentage}%
            </span>
          </div>
        </div>

        {/* Warning Alert if Low Attendance */}
        {isWarning && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-xs text-rose-900">Attendance Debarment Warning</h4>
              <p className="text-xs text-rose-700 mt-0.5 leading-relaxed">
                Your total attendance is currently at <strong>{summary.overallPercentage}%</strong>, below the mandatory 75% institutional requirement. Consult your faculty advisor immediately.
              </p>
            </div>
          </div>
        )}

        {/* Counters Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 bg-emerald-50/70 border border-emerald-100 rounded-xl">
            <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">Present</span>
            <p className="text-2xl font-mono font-extrabold text-emerald-900 mt-0.5">{summary.present}</p>
            <span className="text-[10px] text-emerald-600">Full lecture credit</span>
          </div>

          <div className="p-4 bg-amber-50/70 border border-amber-100 rounded-xl">
            <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">Late</span>
            <p className="text-2xl font-mono font-extrabold text-amber-900 mt-0.5">{summary.late}</p>
            <span className="text-[10px] text-amber-600">0.5 credit weighted</span>
          </div>

          <div className="p-4 bg-rose-50/70 border border-rose-100 rounded-xl">
            <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider">Absent</span>
            <p className="text-2xl font-mono font-extrabold text-rose-900 mt-0.5">{summary.absent}</p>
            <span className="text-[10px] text-rose-600">Unexcused absence</span>
          </div>

          <div className="p-4 bg-blue-50/70 border border-blue-100 rounded-xl">
            <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider">Excused</span>
            <p className="text-2xl font-mono font-extrabold text-blue-900 mt-0.5">{summary.excused}</p>
            <span className="text-[10px] text-blue-600">Excluded from denominator</span>
          </div>
        </div>

        {/* Formula documentation badge */}
        <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center gap-2 text-xs text-slate-600">
          <Info className="w-4 h-4 text-indigo-500 shrink-0" />
          <span>
            Institutional Formula: <strong>((Present + 0.5 × Late) / (Total Sessions - Excused)) × 100</strong>
          </span>
        </div>
      </div>

      {/* Subject Breakdown Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100">
          <h3 className="font-bold text-slate-900 text-sm">Course-by-Course Attendance Breakdown</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
              <tr>
                <th className="py-3 px-6">Course</th>
                <th className="py-3 px-6">Total Lectures</th>
                <th className="py-3 px-6">Present</th>
                <th className="py-3 px-6">Late</th>
                <th className="py-3 px-6">Absent</th>
                <th className="py-3 px-6">Excused</th>
                <th className="py-3 px-6">Subject Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {subjectBreakdown.map((sb: any) => (
                <tr key={sb.subject_id} className="hover:bg-slate-50/80">
                  <td className="py-3 px-6 font-bold text-slate-900">
                    <span className="font-mono text-indigo-700">{sb.subject_code}</span> · {sb.subject_name}
                  </td>
                  <td className="py-3 px-6 font-mono">{sb.total_sessions}</td>
                  <td className="py-3 px-6 font-mono text-emerald-700">{sb.present_count}</td>
                  <td className="py-3 px-6 font-mono text-amber-700">{sb.late_count}</td>
                  <td className="py-3 px-6 font-mono text-rose-700">{sb.absent_count}</td>
                  <td className="py-3 px-6 font-mono text-blue-700">{sb.excused_count}</td>
                  <td className="py-3 px-6">
                    <span className={`font-mono font-extrabold text-sm ${sb.isLow ? 'text-rose-600' : 'text-slate-900'}`}>
                      {sb.percentage}%
                    </span>
                    {sb.isLow && (
                      <span className="ml-1 text-[10px] text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded">
                        Warning
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Chronological Log Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="font-bold text-slate-900 text-sm">Chronological Session Log</h3>

          <div className="flex items-center gap-2">
            <select
              value={subjectFilter}
              onChange={e => setSubjectFilter(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-medium"
            >
              <option value="all">All Courses</option>
              {subjectBreakdown.map((sb: any) => (
                <option key={sb.subject_id} value={sb.subject_id}>{sb.subject_code}</option>
              ))}
            </select>

            <input
              type="text"
              placeholder="Search date (YYYY-MM)..."
              value={searchDate}
              onChange={e => setSearchDate(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs"
            />
          </div>
        </div>

        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100 sticky top-0 bg-slate-50">
              <tr>
                <th className="py-2.5 px-6">Date</th>
                <th className="py-2.5 px-6">Course</th>
                <th className="py-2.5 px-6">Session</th>
                <th className="py-2.5 px-6">Status</th>
                <th className="py-2.5 px-6">Faculty Verifier</th>
                <th className="py-2.5 px-6">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No sessions match the filter criteria.
                  </td>
                </tr>
              ) : (
                filteredHistory.map((h: any) => (
                  <tr key={h.id} className="hover:bg-slate-50/80">
                    <td className="py-2.5 px-6 font-mono font-bold">{h.date}</td>
                    <td className="py-2.5 px-6 font-bold text-slate-800">{h.subject_code}</td>
                    <td className="py-2.5 px-6 text-slate-600">{h.session_name}</td>
                    <td className="py-2.5 px-6">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        h.status === 'Present' ? 'bg-emerald-100 text-emerald-800' :
                        h.status === 'Late' ? 'bg-amber-100 text-amber-800' :
                        h.status === 'Absent' ? 'bg-rose-100 text-rose-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {h.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-6 text-slate-500">{h.recorded_by_teacher}</td>
                    <td className="py-2.5 px-6 text-slate-400 italic text-[11px]">{h.remarks || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
