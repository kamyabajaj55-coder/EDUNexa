import React from 'react';
import {
  Award,
  Printer,
  Calendar,
  CheckCircle2,
  TrendingUp,
  BookOpen,
  Info
} from 'lucide-react';

interface StudentGradesProps {
  data: any;
}

export const StudentGrades: React.FC<StudentGradesProps> = ({ data }) => {
  if (!data) {
    return (
      <div className="py-16 text-center text-xs text-slate-400">
        Loading official transcript records...
      </div>
    );
  }

  const { summary = {}, subjectSummary = [], grades = [] } = data;

  return (
    <div className="space-y-6">
      {/* Official Academic Standing Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-600" />
              Academic Gradebook & Cumulative Transcript
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified examination marks, continuous assessments, and grade point calculations
            </p>
          </div>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors shrink-0"
          >
            <Printer className="w-4 h-4" />
            <span>Print Official Transcript</span>
          </button>
        </div>

        {/* GPA & Performance KPI */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 bg-emerald-50/70 border border-emerald-100 rounded-xl">
            <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">Cumulative GPA</span>
            <p className="text-3xl font-mono font-extrabold text-emerald-900 mt-0.5">{summary.cumulativeGpa}</p>
            <span className="text-[10px] text-emerald-600">4.0 Scale Standard</span>
          </div>

          <div className="p-4 bg-indigo-50/70 border border-indigo-100 rounded-xl">
            <span className="text-[10px] font-bold text-indigo-800 uppercase tracking-wider">Overall Percentage</span>
            <p className="text-3xl font-mono font-extrabold text-indigo-900 mt-0.5">{summary.overallPercentage}%</p>
            <span className="text-[10px] text-indigo-600">Weighted Average</span>
          </div>

          <div className="p-4 bg-violet-50/70 border border-violet-100 rounded-xl">
            <span className="text-[10px] font-bold text-violet-800 uppercase tracking-wider">Standing Grade</span>
            <p className="text-3xl font-mono font-extrabold text-violet-900 mt-0.5">{summary.overallGrade}</p>
            <span className="text-[10px] text-violet-600">Honors Standing</span>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Evaluated Exams</span>
            <p className="text-3xl font-mono font-extrabold text-slate-800 mt-0.5">{summary.totalAssessments}</p>
            <span className="text-[10px] text-slate-400">Total Marks: {summary.totalObtainedMarks}/{summary.totalMaximumMarks}</span>
          </div>
        </div>

        {/* Formula */}
        <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center gap-2 text-xs text-slate-600">
          <Info className="w-4 h-4 text-indigo-500 shrink-0" />
          <span>
            Performance Rule: <strong>(Total Obtained Marks / Total Maximum Marks) × 100</strong>. Grade thresholds: A+ (≥90%), A (≥80%), B (≥70%), C (≥60%), D (≥50%), F (&lt;50%).
          </span>
        </div>
      </div>

      {/* Subject Summary Cards */}
      <div>
        <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
          Subject Performance Overview
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjectSummary.map((sub: any) => (
            <div key={sub.subject_id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-extrabold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/60">
                  {sub.subject_code}
                </span>
                <span className={`px-2.5 py-0.5 rounded text-xs font-extrabold ${
                  sub.grade === 'A+' || sub.grade === 'A'
                    ? 'bg-emerald-100 text-emerald-800'
                    : sub.grade === 'B'
                    ? 'bg-indigo-100 text-indigo-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  Grade {sub.grade}
                </span>
              </div>

              <div>
                <h5 className="font-bold text-sm text-slate-900">{sub.subject_name}</h5>
                <p className="text-xs text-slate-500 mt-0.5">{sub.assessmentsCount} examinations completed</p>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Subject Average</span>
                  <span className="font-mono font-bold text-slate-800">{sub.percentage}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full"
                    style={{ width: `${Math.min(100, sub.percentage)}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Comprehensive Assessment Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100">
          <h3 className="font-bold text-slate-900 text-sm">Detailed Assessment Results & Faculty Remarks</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-100">
              <tr>
                <th className="py-3 px-6">Date</th>
                <th className="py-3 px-6">Assessment Title</th>
                <th className="py-3 px-6">Course</th>
                <th className="py-3 px-6">Obtained / Max</th>
                <th className="py-3 px-6">Percentage</th>
                <th className="py-3 px-6">Grade</th>
                <th className="py-3 px-6">Faculty Feedback & Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {grades.map((g: any) => (
                <tr key={g.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-6 font-mono font-medium text-slate-500">{g.date}</td>
                  <td className="py-3.5 px-6 font-bold text-slate-900">{g.assessment_name}</td>
                  <td className="py-3.5 px-6 font-semibold text-slate-700">
                    <span className="font-mono text-indigo-700">{g.subject_code}</span>
                  </td>
                  <td className="py-3.5 px-6 font-mono font-bold text-slate-800">
                    {g.obtained_marks} / {g.maximum_marks}
                  </td>
                  <td className="py-3.5 px-6 font-mono font-bold text-indigo-700">{g.calculated_percentage}%</td>
                  <td className="py-3.5 px-6">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-extrabold ${
                      g.grade === 'A+' || g.grade === 'A'
                        ? 'bg-emerald-100 text-emerald-800'
                        : g.grade === 'B'
                        ? 'bg-indigo-100 text-indigo-800'
                        : g.grade === 'C'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {g.grade}
                    </span>
                  </td>
                  <td className="py-3.5 px-6 text-slate-600 text-xs italic leading-relaxed">
                    {g.teacher_remarks || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
