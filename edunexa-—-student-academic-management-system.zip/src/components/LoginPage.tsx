import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { GraduationCap, Lock, User, ArrowRight, ShieldCheck, CheckCircle2, AlertCircle, BookOpen, Clock, Award, Users } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login, quickLogin } = useAuth();
  const [username, setUsername] = useState('prof.turing');
  const [password, setPassword] = useState('Teacher@123');
  const [roleTab, setRoleTab] = useState<'teacher' | 'student'>('teacher');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsSubmitting(true);
    const res = await login(username, password);
    setIsSubmitting(false);
    if (!res.success) {
      setErrorMsg(res.error || 'Authentication failed. Please check credentials.');
    }
  };

  const handleRoleTabChange = (role: 'teacher' | 'student') => {
    setRoleTab(role);
    setErrorMsg(null);
    if (role === 'teacher') {
      setUsername('prof.turing');
      setPassword('Teacher@123');
    } else {
      setUsername('liam.davis');
      setPassword('Student@123');
    }
  };

  const demoAccounts = [
    { name: 'Prof. Alan Turing', username: 'prof.turing', role: 'teacher', pass: 'Teacher@123', tag: 'CS & Math Faculty' },
    { name: 'Dr. Rosalind Franklin', username: 'dr.franklin', role: 'teacher', pass: 'Teacher@123', tag: 'Bio & Chem Faculty' },
    { name: 'Liam Davis', username: 'liam.davis', role: 'student', pass: 'Student@123', tag: 'Class A (Normal)' },
    { name: 'Jackson Martinez', username: 'jackson.martinez', role: 'student', pass: 'Student@123', tag: 'Class A (Low Attendance Alert)' }
  ];

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background aesthetic blobs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white shadow-xl shadow-indigo-500/25 mb-4">
          <GraduationCap className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">
          EduNexa
        </h1>
        <p className="mt-1.5 text-sm text-slate-300 font-medium">
          Intelligent Student Academic Management System
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-lg relative z-10">
        <div className="bg-white/95 backdrop-blur rounded-3xl shadow-2xl border border-slate-100 p-8">
          {/* Role selector tabs */}
          <div className="flex p-1 bg-slate-100 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => handleRoleTabChange('teacher')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                roleTab === 'teacher'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Faculty / Teacher Portal
            </button>
            <button
              type="button"
              onClick={() => handleRoleTabChange('student')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                roleTab === 'student'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Student Portal
            </button>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username / Identifier
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  placeholder={roleTab === 'teacher' ? 'e.g. prof.turing' : 'e.g. liam.davis'}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Password
                </label>
                <span className="text-[11px] text-slate-400">
                  Default: {roleTab === 'teacher' ? 'Teacher@123' : 'Student@123'}
                </span>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  placeholder="Enter password"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-3 px-4 rounded-xl text-sm font-bold text-white shadow-md flex items-center justify-center gap-2 transition-all ${
                roleTab === 'teacher'
                  ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200'
                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200'
              } disabled:opacity-50`}
            >
              {isSubmitting ? (
                <span>Authenticating...</span>
              ) : (
                <>
                  <span>Sign In as {roleTab === 'teacher' ? 'Faculty' : 'Student'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* 1-Click Demo Evaluation Row */}
          <div className="mt-6 pt-5 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
                Instant Demo Evaluation (1-Click)
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {demoAccounts.map(demo => (
                <button
                  key={demo.username}
                  type="button"
                  onClick={() => {
                    setUsername(demo.username);
                    setPassword(demo.pass);
                    quickLogin(demo.username, demo.pass);
                  }}
                  className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-indigo-50/60 hover:border-indigo-300 text-left transition-all group"
                >
                  <p className="text-xs font-bold text-slate-800 group-hover:text-indigo-600 truncate">
                    {demo.name}
                  </p>
                  <span className="text-[10px] text-slate-500 block truncate mt-0.5">
                    {demo.tag}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Feature Highlights beneath */}
        <div className="mt-6 grid grid-cols-3 gap-3 text-center text-slate-400 text-xs">
          <div className="p-2 rounded-xl bg-slate-800/40 border border-slate-800">
            <Clock className="w-4 h-4 mx-auto text-indigo-400 mb-1" />
            <span className="font-medium text-slate-300">30-Day Attendance</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-800/40 border border-slate-800">
            <Award className="w-4 h-4 mx-auto text-amber-400 mb-1" />
            <span className="font-medium text-slate-300">Gradebook & GPA</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-800/40 border border-slate-800">
            <BookOpen className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
            <span className="font-medium text-slate-300">Assignment Lifecycle</span>
          </div>
        </div>
      </div>
    </div>
  );
};
