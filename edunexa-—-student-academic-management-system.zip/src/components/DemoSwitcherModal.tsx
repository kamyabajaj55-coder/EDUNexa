import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Users, GraduationCap, X, Check, ArrowRight, ShieldAlert, Sparkles } from 'lucide-react';

interface DemoSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DemoSwitcherModal: React.FC<DemoSwitcherModalProps> = ({ isOpen, onClose }) => {
  const { user, quickLogin } = useAuth();
  const [loadingUsername, setLoadingUsername] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const teachers = [
    {
      username: 'prof.turing',
      name: 'Prof. Alan Turing',
      role: 'teacher',
      department: 'Computer Science & Mathematics',
      subjects: 'CS101, MATH201',
      badge: 'Dept Head'
    },
    {
      username: 'dr.franklin',
      name: 'Dr. Rosalind Franklin',
      role: 'teacher',
      department: 'Life Sciences & Chemistry',
      subjects: 'CHEM105, BIO110',
      badge: 'Associate Professor'
    },
    {
      username: 'prof.feynman',
      name: 'Prof. Richard Feynman',
      role: 'teacher',
      department: 'Applied Physics',
      subjects: 'PHYS102 Mechanics',
      badge: 'Professor'
    }
  ];

  const students = [
    {
      username: 'liam.davis',
      studentId: 'STU-2026-001',
      name: 'Liam Davis',
      class: 'Year 1 - Class A',
      note: 'Normal attendance (~92%), completed assignments'
    },
    {
      username: 'sophia.chen',
      studentId: 'STU-2026-002',
      name: 'Sophia Chen',
      class: 'Year 1 - Class A',
      note: 'High academic performer (GPA ~3.9), active submissions'
    },
    {
      username: 'jackson.martinez',
      studentId: 'STU-2026-005',
      name: 'Jackson Martinez',
      class: 'Year 1 - Class A',
      note: 'Academic Warning Test: <75% attendance alert active!'
    },
    {
      username: 'harper.garcia',
      studentId: 'STU-2026-014',
      name: 'Harper Garcia',
      class: 'Year 1 - Class B',
      note: 'Class B track: enrolled in Organic Chem & Cellular Biology'
    },
    {
      username: 'aiden.rodriguez',
      studentId: 'STU-2026-017',
      name: 'Aiden Rodriguez',
      class: 'Year 1 - Class B',
      note: 'Academic Warning Test: low attendance & grade support flag'
    }
  ];

  const handleSwitch = async (username: string, role: string) => {
    setLoadingUsername(username);
    setErrorMsg(null);
    const password = role === 'teacher' ? 'Teacher@123' : 'Student@123';
    const res = await quickLogin(username, password);
    setLoadingUsername(null);
    if (res.success) {
      onClose();
    } else {
      setErrorMsg(res.error || 'Failed to switch user.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white/95 backdrop-blur px-6 py-4 border-b border-slate-100 flex items-center justify-between z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Demo Accounts & Quick Switch</h3>
              <p className="text-xs text-slate-500">1-click switch between preloaded faculty and student roles</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Teacher Accounts Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-indigo-600" />
                Teacher Accounts (Password: Teacher@123)
              </h4>
              <span className="text-[11px] font-medium text-slate-400">3 preloaded</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {teachers.map(t => {
                const isActive = user?.username === t.username;
                const isLoading = loadingUsername === t.username;

                return (
                  <div
                    key={t.username}
                    className={`relative p-3.5 rounded-xl border transition-all text-left flex flex-col justify-between ${
                      isActive
                        ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50/80'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800">
                          {t.badge}
                        </span>
                        {isActive && (
                          <span className="text-[10px] font-bold text-indigo-700 flex items-center gap-1">
                            <Check className="w-3 h-3" /> Current
                          </span>
                        )}
                      </div>
                      <h5 className="font-bold text-sm text-slate-900 mt-2">{t.name}</h5>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">{t.username}</p>
                      <p className="text-[11px] text-slate-600 mt-1.5 font-medium">{t.department}</p>
                      <div className="mt-2 text-[10px] font-semibold text-indigo-700 bg-white/80 px-2 py-1 rounded border border-indigo-100">
                        Courses: {t.subjects}
                      </div>
                    </div>

                    <button
                      onClick={() => handleSwitch(t.username, 'teacher')}
                      disabled={isLoading || isActive}
                      className={`mt-4 w-full py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                        isActive
                          ? 'bg-indigo-200/50 text-indigo-800 cursor-default'
                          : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs'
                      }`}
                    >
                      {isLoading ? (
                        <span>Switching...</span>
                      ) : isActive ? (
                        <span>Active Session</span>
                      ) : (
                        <>
                          <span>Login as Teacher</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Student Accounts Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-600" />
                Featured Student Accounts (Password: Student@123)
              </h4>
              <span className="text-[11px] font-medium text-slate-400">5 of 25 shown</span>
            </div>

            <div className="space-y-2">
              {students.map(s => {
                const isActive = user?.username === s.username;
                const isLoading = loadingUsername === s.username;

                return (
                  <div
                    key={s.username}
                    className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                      isActive
                        ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-600/20'
                        : 'border-slate-200 hover:border-emerald-300 hover:bg-slate-50/80'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        {s.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-bold text-sm text-slate-900">{s.name}</h5>
                          <span className="font-mono text-xs text-slate-500 font-semibold">{s.studentId}</span>
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                            {s.class}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5 font-medium flex items-center gap-1">
                          {s.note.includes('Warning') && <span className="text-amber-600 font-bold">⚠️</span>}
                          {s.note}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleSwitch(s.username, 'student')}
                      disabled={isLoading || isActive}
                      className={`shrink-0 py-1.5 px-3.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                        isActive
                          ? 'bg-emerald-200/50 text-emerald-800 cursor-default'
                          : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                      }`}
                    >
                      {isLoading ? (
                        <span>Switching...</span>
                      ) : isActive ? (
                        <span>Active Session</span>
                      ) : (
                        <>
                          <span>Login as Student</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 text-center text-xs text-slate-500 rounded-b-2xl">
          All 25 students and 3 teachers have permanent database records with attendance logs, assignments, and test grades.
        </div>
      </div>
    </div>
  );
};
