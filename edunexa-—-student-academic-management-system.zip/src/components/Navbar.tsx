import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../api';
import { NotificationItem } from '../types';
import {
  GraduationCap,
  Bell,
  LogOut,
  KeyRound,
  Users,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Sparkles,
  BarChart3,
  BookOpen
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenDemoSwitcher: () => void;
  onOpenPasswordModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenDemoSwitcher,
  onOpenPasswordModal
}) => {
  const { user, logout } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [showNotifications, setShowNotifications] = useState<boolean>(false);

  const fetchNotifications = async () => {
    if (!user) return;
    const endpoint = user.role === 'student' ? '/api/student/notifications' : '/api/teacher/dashboard-stats';
    if (user.role === 'student') {
      const res = await apiFetch<{ notifications: NotificationItem[]; unreadCount: number }>('/api/student/notifications');
      if (res.data) {
        setNotifications(res.data.notifications || []);
        setUnreadCount(res.data.unreadCount || 0);
      }
    }
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 15000);
    return () => clearInterval(interval);
  }, [user]);

  const handleMarkAllRead = async () => {
    if (user?.role === 'student') {
      await apiFetch('/api/student/notifications/mark-all-read', { method: 'POST' });
      setUnreadCount(0);
      setNotifications(prev => prev.map(n => ({ ...n, is_read: 1 })));
    }
  };

  const handleMarkSingleRead = async (id: number) => {
    if (user?.role === 'student') {
      await apiFetch(`/api/student/notifications/${id}/read`, { method: 'PUT' });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: 1 } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-200">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-slate-900 to-indigo-950 bg-clip-text text-transparent">
                  EduNexa
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                  Academic Portal
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block">
                Intelligent Student Academic Management System
              </p>
            </div>
          </div>

          {/* Navigation Controls */}
          {user && (
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Demo Account Switcher Button */}
              <button
                onClick={onOpenDemoSwitcher}
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300 hover:bg-amber-100 transition-colors shadow-2xs"
                title="Switch between Teacher and Student test accounts"
              >
                <Users className="w-3.5 h-3.5 text-amber-600" />
                <span>Demo Accounts</span>
                <span className="px-1.5 py-0.2 rounded-full bg-amber-200 text-amber-900 text-[10px] font-bold">
                  Quick Switch
                </span>
              </button>

              {/* Voice Powered Orb Toggle */}
              <button
                onClick={() => setActiveTab(activeTab === 'voice-orb' ? (user.role === 'teacher' ? 'overview' : 'dashboard') : 'voice-orb')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'voice-orb'
                    ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-sm'
                    : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200/60'
                }`}
                title="View interactive Voice-Powered Orb visualizer"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
                <span className="hidden sm:inline">Voice Orb</span>
              </button>

              {/* Bento Analytics Tab Toggle */}
              <button
                onClick={() => setActiveTab(activeTab === 'bento' ? (user.role === 'teacher' ? 'overview' : 'dashboard') : 'bento')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'bento'
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
                title="View integrated Finance Bento component"
              >
                <BarChart3 className="w-3.5 h-3.5 text-lime-400" />
                <span className="hidden sm:inline">Bento Analytics</span>
              </button>

              {/* Notifications Popover (especially for students) */}
              {user.role === 'student' && (
                <div className="relative">
                  <button
                    onClick={() => setShowNotifications(!showNotifications)}
                    className="relative p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                    aria-label="Notifications"
                  >
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                      <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                        {unreadCount}
                      </span>
                    )}
                  </button>

                  {showNotifications && (
                    <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-slate-800">Notifications</span>
                          {unreadCount > 0 && (
                            <span className="px-1.5 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-700">
                              {unreadCount} new
                            </span>
                          )}
                        </div>
                        {unreadCount > 0 && (
                          <button
                            onClick={handleMarkAllRead}
                            className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
                          >
                            Mark all read
                          </button>
                        )}
                      </div>

                      <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                        {notifications.length === 0 ? (
                          <div className="py-6 text-center text-xs text-slate-400">
                            No notifications yet
                          </div>
                        ) : (
                          notifications.map(n => (
                            <div
                              key={n.id}
                              onClick={() => handleMarkSingleRead(n.id)}
                              className={`p-3.5 hover:bg-slate-50 cursor-pointer transition-colors ${
                                !n.is_read ? 'bg-indigo-50/50' : ''
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <h4 className={`text-xs font-semibold ${!n.is_read ? 'text-indigo-900' : 'text-slate-700'}`}>
                                  {n.title}
                                </h4>
                                {!n.is_read && (
                                  <span className="w-2 h-2 rounded-full bg-indigo-600 shrink-0 mt-1" />
                                )}
                              </div>
                              <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                                {n.message}
                              </p>
                              <span className="text-[10px] text-slate-400 mt-1.5 block">
                                {n.creation_date}
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* User Identity Chip */}
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-bold text-slate-800 leading-tight">
                    {user.name}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">
                    {user.profileId}
                  </div>
                </div>

                <div className="relative group">
                  <button className="flex items-center gap-1.5 p-1 rounded-full border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-colors">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white ${
                      user.role === 'teacher' ? 'bg-indigo-600' : 'bg-emerald-600'
                    }`}>
                      {user.name.charAt(0)}
                    </div>
                  </button>

                  {/* Profile Dropdown */}
                  <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-lg border border-slate-200 py-1.5 hidden group-hover:block hover:block z-50">
                    <div className="px-3.5 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900">{user.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                      <span className={`inline-block mt-1 px-2 py-0.5 text-[10px] font-bold rounded capitalize ${
                        user.role === 'teacher' ? 'bg-indigo-100 text-indigo-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {user.role} Account
                      </span>
                    </div>

                    <button
                      onClick={onOpenDemoSwitcher}
                      className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 md:hidden"
                    >
                      <Users className="w-3.5 h-3.5 text-amber-600" />
                      <span>Switch Demo Account</span>
                    </button>

                    <button
                      onClick={onOpenPasswordModal}
                      className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                      <span>Change Password</span>
                    </button>

                    <button
                      onClick={logout}
                      className="w-full text-left px-3.5 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-medium"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-500" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
