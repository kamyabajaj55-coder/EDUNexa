export * from "../../../components/ui/voice-powered-orb";
export { default } from "../../../components/ui/voice-powered-orb";
