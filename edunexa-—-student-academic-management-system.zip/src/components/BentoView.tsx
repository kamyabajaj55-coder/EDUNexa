import React from 'react';
import { FinanceBento } from '@/components/ui/finance-bento';
import { ArrowLeft, CheckCircle2, FolderTree, Code, Sparkles, Layers } from 'lucide-react';

interface BentoViewProps {
  onBack: () => void;
}

// 36 months dataset for FinanceBento
const history = Array.from({ length: 36 }, (_, i) => {
  const t = i / 35;
  const d = new Date(2026, 9 - (35 - i), 1);
  const noise = (Math.sin(i * 12.9898 + 156.466) * 43758.5453) % 1;
  return {
    date: d.toISOString(),
    fiat: 14000 + t * 7000 + Math.sin(i * 0.9) * 900,
    stocks: 12000 + t * 19000 + Math.sin(i * 0.55) * 1600 + noise * 800,
    crypto: Math.max(2500, 4000 + t * 12000 + Math.sin(i * 0.8 + 1) * 3200 + Math.cos(i * 0.33) * 1400),
  };
});

const bentoData = {
  history,
  payments: [
    { name: "University Endowment Grant", date: "Nov 1", amount: 18000 },
    { name: "Department Lab Equipment", date: "Nov 3", amount: 5000 },
    { name: "Academic Software Licensing", date: "Nov 9", amount: 960 },
  ],
  goals: [
    { name: "Research Laboratory Fund", progress: 0.68, target: 120000 },
    { name: "Student Scholarships", progress: 0.82, target: 50000 },
  ],
  cashflow: {
    months: ["May", "Jun", "Jul", "Aug", "Sep", "Oct"],
    income: [[2.4, 3.6, 5.4, 6.4, 5.0, 3.4], [2.0, 3.0, 4.4, 5.2, 4.2, 2.8], [1.6, 2.4, 3.4, 4.0, 3.3, 2.2]],
    spending: [[1.2, 2.2, 3.8, 4.6, 3.4, 1.8], [1.0, 1.8, 3.0, 3.8, 2.8, 1.5], [0.8, 1.4, 2.4, 3.0, 2.2, 1.2]],
  },
  crypto: [
    { name: "Bitcoin", symbol: "BTC", share: 0.62, change: "+3.1%", ohlc: [[66.1, 67.0, 65.8, 66.8], [66.8, 67.6, 66.5, 67.4], [67.4, 67.9, 66.9, 67.1], [67.1, 68.2, 67.0, 68.0], [68.0, 68.9, 67.8, 68.7], [68.7, 69.1, 68.1, 68.4], [68.4, 69.6, 68.3, 69.4]] },
    { name: "Ethereum", symbol: "ETH", share: 0.26, change: "−0.8%", ohlc: [[3.52, 3.58, 3.44, 3.47], [3.47, 3.55, 3.4, 3.53], [3.53, 3.56, 3.38, 3.41], [3.41, 3.5, 3.36, 3.48], [3.48, 3.51, 3.39, 3.43], [3.43, 3.49, 3.37, 3.46], [3.46, 3.52, 3.42, 3.44]] },
    { name: "Solana", symbol: "SOL", share: 0.12, change: "+6.4%", ohlc: [[142, 149, 139, 147], [147, 151, 141, 143], [143, 156, 142, 154], [154, 158, 147, 149], [149, 162, 148, 160], [160, 166, 155, 157], [157, 171, 156, 168]] },
  ],
  stocks: { days: ["Mon", "Tue", "Wed", "Thu", "Fri"], values: [2.1, 1.2, 3.4, 1.9, 4.6] },
};

export const BentoView: React.FC<BentoViewProps> = ({ onBack }) => {
  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 border border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base text-white">Integrated Component: FinanceBento</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-lime-400 text-slate-950">
                Active in /components/ui/
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Integrated in <code>/components/ui/finance-bento.tsx</code> with shadcn path conventions &amp; Tailwind CSS.
            </p>
          </div>
        </div>

        <button
          onClick={onBack}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
        >
          Return to EduNexa Academic Portal
        </button>
      </div>

      {/* Integration Documentation Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs text-slate-600">
        <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
          <FolderTree className="w-4 h-4 text-indigo-600" />
          <span>Integration Summary &amp; Folder Conventions</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <span className="font-bold text-slate-800 block">Default Path: /components/ui</span>
            <p className="text-[11px] text-slate-500 mt-1">
              <code>/components/ui</code> is the standard directory created by shadcn CLI so reusable atomic primitives (buttons, modals, bentos) reside in a predictable namespace.
            </p>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <span className="font-bold text-slate-800 block">Path Alias: @/components/ui</span>
            <p className="text-[11px] text-slate-500 mt-1">
              Configured in <code>tsconfig.json</code> and <code>vite.config.ts</code> so imports like <code>import &#123; FinanceBento &#125; from &apos;@/components/ui/finance-bento&apos;</code> resolve cleanly.
            </p>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <span className="font-bold text-slate-800 block">Tailwind CSS &amp; TypeScript</span>
            <p className="text-[11px] text-slate-500 mt-1">
              Tailwind CSS v4 is configured in <code>src/index.css</code> and full strict TypeScript checking runs without errors.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Render of FinanceBento */}
      <div className="rounded-3xl overflow-hidden bg-black p-4 sm:p-6 shadow-2xl border border-slate-800">
        <FinanceBento
          className="mx-auto max-w-[1320px]"
          data={bentoData}
          title="Institutional Endowment & Bursar"
          subtitle="Academic Fiscal Year 2026-2027"
          avatar="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
          avatarAlt="Bursar Financial Director"
          credit={true}
        />
      </div>
    </div>
  );
};
