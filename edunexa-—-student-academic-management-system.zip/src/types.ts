export interface AuthUser {
  userId: string;
  username: string;
  role: 'teacher' | 'student';
  profileId: string;
  name: string;
  email: string;
  details?: any;
}

export interface Student {
  id: number;
  student_id: string;
  user_id: string;
  name: string;
  email: string;
  class: string;
  enrollment_date: string;
  phone?: string;
  address?: string;
  guardian_name?: string;
  guardian_phone?: string;
  bio?: string;
  account_status: 'active' | 'deactivated';
  attendancePercentage?: number;
  academicPercentage?: number | null;
  gradeLetter?: string;
}

export interface Teacher {
  id: number;
  teacher_id: string;
  user_id: string;
  name: string;
  email: string;
  department: string;
  designation?: string;
  qualification?: string;
  bio?: string;
}

export interface Subject {
  id: number;
  subject_id: string;
  subject_name: string;
  subject_code: string;
  maximum_marks: number;
  teacher_id: string;
  class: string;
  enrolled_count?: number;
}

export interface Assessment {
  id: number;
  assessment_id: string;
  assessment_name: string;
  subject_id: string;
  subject_name?: string;
  subject_code?: string;
  date: string;
  maximum_marks: number;
  weightage: number;
  term: string;
  graded_count?: number;
  avg_marks?: number;
  avg_percentage?: number;
}

export interface GradeRecord {
  id: number;
  student_id: string;
  assessment_id: string;
  obtained_marks: number;
  calculated_percentage: number;
  grade: string;
  teacher_remarks?: string;
  updated_at: string;
  assessment_name?: string;
  maximum_marks?: number;
  subject_name?: string;
  subject_code?: string;
  teacher_name?: string;
}

export interface Assignment {
  id: number;
  assignment_id: string;
  title: string;
  description: string;
  subject_id: string;
  subject_name?: string;
  subject_code?: string;
  teacher_id: string;
  teacher_name?: string;
  creation_date: string;
  due_date: string;
  total_marks: number;
  publication_status: 'draft' | 'published' | 'archived';
  total_submissions?: number;
  graded_count?: number;
  pending_count?: number;
  current_status?: 'Pending' | 'Submitted' | 'Late' | 'Graded' | 'Overdue';
  submission_id?: string;
  submission_date?: string;
  answer_text?: string;
  marks?: number;
  feedback?: string;
}

export interface Submission {
  id: number;
  submission_id: string;
  assignment_id: string;
  student_id: string;
  name?: string;
  class?: string;
  email?: string;
  submission_date: string;
  answer_text?: string;
  file_name?: string;
  file_url?: string;
  status: 'Submitted' | 'Late' | 'Graded' | 'Pending';
  marks?: number;
  feedback?: string;
  graded_at?: string;
  graded_by?: string;
}

export interface AttendanceRecord {
  id: number;
  student_id: string;
  subject_id: string;
  class: string;
  date: string;
  session_name: string;
  status: 'Present' | 'Absent' | 'Late' | 'Excused';
  recorded_by_teacher_id: string;
  remarks?: string;
  subject_name?: string;
  subject_code?: string;
  recorded_by_teacher?: string;
}

export interface NotificationItem {
  id: number;
  recipient_user_id: string;
  title: string;
  message: string;
  type: string;
  creation_date: string;
  is_read: number;
}
