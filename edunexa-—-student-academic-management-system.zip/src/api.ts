export async function apiFetch<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<{ data?: T; error?: string }> {
  const token = localStorage.getItem('edunexa_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const res = await fetch(endpoint, {
      ...options,
      headers
    });

    const contentType = res.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      const json = await res.json();
      if (!res.ok) {
        return { error: json.error || `HTTP error ${res.status}` };
      }
      return { data: json };
    }

    if (!res.ok) {
      return { error: `Server error: ${res.statusText}` };
    }

    return { data: (await res.text()) as unknown as T };
  } catch (err: any) {
    return { error: err.message || 'Network request failed' };
  }
}
